#!/bin/bash
# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either version 2 of the License, or any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
# --------------------------------------------------------------------------------------------------------------------#

# Disclaimer:   This script is intended for use only for private study or during an authorised pentest. The author bears no responsibility for malicious or illegal use.

#
#  Intro and Guidance:
#
#    Clients setting up a wifi connection with any wifi managing system, sometimes enter
#  the WPA key in the ESSID block by mistake. The wifi device then probes, looking for a
#  station using the WPA Key as the station name. In doing so it broadcasts the WPA key in
#  the clear. Furthermore, the incorrect setup is many times not deleted, as the client just
#  sets up a new connection. The wifi device then probes for both station names resulting
#  in the station name(essid) and WPA key being broadcast in the clear as a pair.
#    Another operator error is that the ESSID is loaded into the WPA key block instead of
#  a seperate WPA Key. 
#    When writing dump files with airodump-ng, csv files are written showing these probe
#  requests. Hence a WPA key sometimes can be found embedded in the syntax of these files
#    The ESSIDPROBEWPA.sh script strips the ESSIDs being probed for by stations and
#  loads them into two(2) text files. One(1) called essidprobesdic.txt can be use
#  with aircrack-ng. Each time you run ESSIDPROBEWPA.sh against any csv file it removes
#  duplicates and lengths less than 8, then sorts, and appends these probes requests into any #  existing essidprobesdic.txt file. This file can then be used as a wordlist with aircrack-ng,
#  pyrit and elcomsoft. If the ESSID name is being used at the WPA Key, this worldlist
#  contains all ESSID's seen together will any WPA keys broadcast in the clear by mistake. Old #  files are NOT erased. New data in appended into any exiting file of the same name. If you
#  wish to start a new file, rename the old one and a new file will be started by the program.
#
#    Sometimes determining which bssid/essid this code is paired with is unclear. To help
#  narrow the choices, one(1) reference files is written for study to help uncover the
#  pairing. The file is named essidrefhold.txt. You can the
#  text file in the  /root/PROBEESSID_DATA directory setup by this program.
#
#  Setup:  

#    Place ALL your csv files .csv files obtained thru airodump-ng scans in root and run the
#  script. You do not need to add files labeled kismet.csv. 
#
#  Dependencies:
#    The program was written in a kali-linux 1.09a environment and uses awk extensively.
#  We have made no attempt to support other linux distros. The program will look for an
#  awk installation near the beginning of the program.   

#    Strategies:

#    Use airodump-ng to constantly monitor and collect data anytime the computer is idle.
#  In short collect data, collect data, and collect more data. 
#
#    You can do wide channel scans:
#
#       airodump-ng -w dumpfile mon0
#
#    Or focus on a single channel:
#     
#       airodump-ng -c 1 -w dumpfile mon0
#
#    Best Targets are groups of stations having similiar names and many users inputing
#  data into their wifi managing software.

#    Combined Arms Operations:

#    If you are running reaver on a specific channel you can also run airodump-ng on the
#  same channel at the same time. If have set reaver to channel hop, airodump-ng can also
#  be run against all channels. DONOT try and set a single channel in airodump-ng with
#  the -c command and then tell reaver to channel hop. You will get an error as you are
#  instructing the wifi device to do two(2) different operations.
#
#    As might be seen:
#        Collect Data, Collect Data and Collect MORE Data

#    It is best you do not delete your csv files - use them - you might
#  just get lucky and find a WPA Key hiding in the text.
#
#  bash comments; Done This Way To Check Step = DTWTCS 
##############################################
# ANSI code routines from Vulpi author of
#              PwnStar9.0 
txtrst="\e[0m"      # Text reset 
warn="\e[1;31m"     # warning		   red         
info="\e[1;34m"     # info                 blue             
q="\e[1;32m"	    # questions            green
inp="\e[1;36m"	    # input variables      magenta
yel="\e[1;33m"      # typed keyboard entries
##############################################
cleanup()

{

rm -f  /tmp/tx

return $?

}

control_c()
{

echo " Ending program"
sleep 5
cleanup
exit $?

}

trap control_c SIGINT


clear

echo ""
echo "  ESSIDPROBEWPA1-5.sh"
echo " "
echo "                      A Musket Team WPA Password Finder"
echo "                        We Wish To Thank Liam Scheff"                    
echo "                         Author of Official Stories"
echo "                        For A Rare Clarity in Thought"
echo ""
echo "    Readers Note:  Help files are embedded in a comment section at the"
echo "  beginning of this script."
echo ""
echo "    Place your csv files in root prior to continuing..."
echo "    Once completed your wordlist and reference file are located"
echo "   as shown below:"
echo "                    /root/PROBEESSID_DATA/essidprobesdic.txt"
echo "                    /root/PROBEESSID_DATA/essidrefhold.txt"
echo ""     

while true

do
echo -e "$inp    When files are placed in /root/ press $yel(y/Y)$inp to continue...."
echo -e "  Press $yel(n/N)$inp to abort!!..Press any other key to try again:$txtrst"
  read CONFIRM
  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  You entered $CONFIRM.  Continuing ...$txtrst"

sleep 1


#### Setup Folders

CSVFILETEST=ZZZ

csvfile=(*.csv)

	if [[ ! -f "/root/$csvfile" ]]; then

		echo -e "$warn     There are no .csv files present in root."
		sleep 5
		echo ""
		echo -e "$info    Program is aborting. Place .csv files in root."
		echo ""
                echo -e "$info  and rerun the program."
		sleep 5
		exit

		fi



echo " Check for the installation of awk."
echo -ne "Awk............."
	if ! hash awk 2>/dev/null; then
		echo -e "$info Not installed$txtrst"
		echo -e "$warn Install awk before continuing!"
		sleep 5
                
	else

		echo -e "$yel OK!$txtrst"

	fi

sleep 1

PROBE_DIR="/tmp/ESSIDPROBE_DIR"

if [ ! -d "$PROBE_DIR" ]; then

	mkdir -p -m 700 $PROBE_DIR;

	fi

if [ ! -d "/root/PROBEESSID_DATA" ]; then

	mkdir -p -m 700 /root/PROBEESSID_DATA;

	fi

if [ ! -f "/root/PROBEESSID_DATA/essidprobesdic.txt" ]; then

	touch /root/PROBEESSID_DATA/essidprobesdic.txt

	fi

if [ ! -f "/root/PROBEESSID_DATA/essidrefhold.txt" ]; then

	touch /root/PROBEESSID_DATA/essidrefhold.txt

	fi


rm $PROBE_DIR/*

cp /root/*.csv $PROBE_DIR/

rm $PROBE_DIR/*.kismet.csv

cat $PROBE_DIR/*.csv >> $PROBE_DIR/allcsv.txt

cat < $PROBE_DIR/allcsv.txt | awk -F' ' '{ if((length($8) == 18 )) {$1=$2=$3=$4=$5=$6=$7=$8=""; print $0 }}' > $PROBE_DIR/hold01a.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $1 }' > $PROBE_DIR/holdfield01.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $2 }' > $PROBE_DIR/holdfield02.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $3 }' > $PROBE_DIR/holdfield03.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $4 }' > $PROBE_DIR/holdfield04.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $5 }' > $PROBE_DIR/holdfield05.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $6 }' > $PROBE_DIR/holdfield06.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $7 }' > $PROBE_DIR/holdfield07.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $8 }' > $PROBE_DIR/holdfield08.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $9 }' > $PROBE_DIR/holdfield09.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $10 }' > $PROBE_DIR/holdfield10.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $11 }' > $PROBE_DIR/holdfield11.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $12 }' > $PROBE_DIR/holdfield12.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $13 }' > $PROBE_DIR/holdfield13.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $14 }' > $PROBE_DIR/holdfield14.txt

cat < $PROBE_DIR/hold01a.txt | awk 'BEGIN { FS ="," } ; { print $15 }' > $PROBE_DIR/holdfield15.txt

cat $PROBE_DIR/holdfield*.txt >> $PROBE_DIR/holdfield16.txt

# Removes white spaces from left, limits length, sorts and removes duplicates
 
cat $PROBE_DIR/holdfield16.txt |  sed -e 's/^[ \t]*//' | awk 'length($0) > 7' | sort -u > $PROBE_DIR/essidprobesdichold01.txt

cp /root/PROBEESSID_DATA/essidprobesdic.txt $PROBE_DIR/essidprobesdichold02.txt

rm /root/PROBEESSID_DATA/essidprobesdic.txt

cat  $PROBE_DIR/essidprobesdichold01.txt $PROBE_DIR/essidprobesdichold02.txt > $PROBE_DIR/essidprobesdichold03.txt

cat $PROBE_DIR/essidprobesdichold03.txt |  sed -e 's/^[ \t]*//' | awk 'length($0) > 7' | sort -u > $PROBE_DIR/essidprobesdichold04.txt

cat $PROBE_DIR/essidprobesdichold04.txt | unix2dos > $PROBE_DIR/essidprobesdichold05.txt

cat $PROBE_DIR/essidprobesdichold05.txt | sort -u > /root/PROBEESSID_DATA/essidprobesdic.txt

### essidreference ###

cat < $PROBE_DIR/allcsv.txt | awk -F' ' '{ if((length($8) == 18 )) {$2=$3=$4=$5=$6=$7=""; print $0 }}' > $PROBE_DIR/essidrefhold01.txt

cat < $PROBE_DIR/essidrefhold01.txt | sort -u | uniq > $PROBE_DIR/essidrefhold01a.txt

cat < $PROBE_DIR/essidrefhold01a.txt | sed -r 's/[[:blank:]]+//1' > $PROBE_DIR/essidrefhold01b.txt

cat < $PROBE_DIR/essidrefhold01b.txt | awk 'BEGIN { FS=OFS=""} ;{ $19=" "$19} 1' > $PROBE_DIR/essidrefhold02.txt

cp /root/PROBEESSID_DATA/essidrefhold.txt $PROBE_DIR/essidrefhold03.txt
 
cat $PROBE_DIR/essidrefhold02.txt >> $PROBE_DIR/essidrefhold03.txt

rm /root/PROBEESSID_DATA/essidrefhold.txt

cat < $PROBE_DIR/essidrefhold03.txt | sort -u | uniq  >> /root/PROBEESSID_DATA/essidrefhold.txt

clear
echo ""
echo ""
echo "  A wordlist text file suitable for use with aircrack-ng is in the:"
echo "        /root/PROBEESSID_DATA/essidprobesdic.txt"
echo ""
echo "  A BSSID/ESSID file for study and reference is located in the:"
echo "        /root/PROBEESSID_DATA/essidrefhold.txt"

LPFILETEST=111111
until  [ $LPFILETEST -eq 3 ]; do

echo ""
echo -e "$inp    To open file with leafpad enter line number$yel (1, 2)"
echo -e "$inp  or enter$yel (3)$inp to exit program."
echo ""
echo ""
echo -e "$yel       (1)$info   essidprobesdic.txt"
echo ""
echo -e "$yel       (2)$info   essidrefhold.txt"
echo ""
echo -e "$yel       (3)$info   EXIT $txtrst"     

read LPFILETEST


	if [[ $LPFILETEST -eq 1 ]]; then

		leafpad /root/PROBEESSID_DATA/essidprobesdic.txt

		fi 

	if [[ $LPFILETEST -eq 2 ]]; then

		leafpad /root/PROBEESSID_DATA/essidrefhold.txt

		fi

	
		done         


echo "end"

sleep 5
